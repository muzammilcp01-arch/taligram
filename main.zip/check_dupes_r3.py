
import json
import os

files = {
    "accounts.json": "c:/Users/muzam/Videos/test/accounts.json",
    "levelup.json": "c:/Users/muzam/Videos/test/levelup.json",
    "spam.json": "c:/Users/muzam/Videos/test/spam.json"
}

data = {}
for name, path in files.items():
    if os.path.exists(path):
        with open(path, 'r') as f:
            try:
                data[name] = set(json.load(f).keys())
            except:
                data[name] = set()

# Check Intersections
acc = data.get("accounts.json", set())
lvl = data.get("levelup.json", set())
spm = data.get("spam.json", set())

acc_lvl = acc.intersection(lvl)
acc_spm = acc.intersection(spm)
lvl_spm = lvl.intersection(spm)

print(f"Accounts <-> Levelup ({len(acc_lvl)}): {list(acc_lvl)}")
print(f"Accounts <-> Spam    ({len(acc_spm)}): {list(acc_spm)}")
print(f"Levelup  <-> Spam    ({len(lvl_spm)}): {list(lvl_spm)}")
