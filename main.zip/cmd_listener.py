
import asyncio
import os
from xC4 import OpEnSq, cHSq, SEnd_InV, ExiT, GenJoinSquadsPacket
from xHeaders import SEndPacKeT

# Globals
lag_running = False
lag_task = None
# Ensure other globals are defined if they are expected to be module-level (though they seem to be dragged in or global scope assumed)
# We will leave partial globals alone if they worked before, but define ours.

async def lag_worker(team_code, key, iv, region):
    global lag_running
    print(f"🚀 Lag worker started for {team_code}")
    
    # We need a writer? The listener has 'online_writer' in scope? 
    # Wait, telegram_cmd_listener DOES NOT have online_writer passed in.
    # It accesses it from GLOBAL scope?
    # Let's import it or assume it's there. 
    # Actually, looking at previous code: `if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)`
    # It assumes `online_writer`, `whisper_writer` are in global scope.
    # To be safe, we might need to import them or rely on the same mechanism.
    # BUT, we can't import dynamic globals from main.
    # We will assume they are available if the function is defined in the same file/scope where they exist.
    # ... Wait, if this file is imported by main, it DOES NOT share main's globals.
    # This implies `telegram_cmd_listener` in `main.py` might be a different function or this file IS main.py?
    # No, user said "Active Document: main.py", "target_file: cmd_listener.py".
    # If `cmd_listener.py` is a separate module, it CANNOT access `main.py` globals like `online_writer`.
    # THIS CODE MUST BE BROKEN if it relies on that.
    # UNLESS `telegram_cmd_listener` is defined inside `main.py` but the user put it in a separate file for me to edit?
    # Let's check main.py imports again. 
    # "from cmd_listener import telegram_cmd_listener"
    # So `telegram_cmd_listener` is in `cmd_listener.py`.
    # AND in `cmd_listener.py` (lines 47, 50, etc) it uses `online_writer`.
    # Unless `cmd_listener.py` has `from main import online_writer` (circular) or `online_writer` is assigned to it.
    # STARTING ASSUMPTION: The user might have `import *` or something, OR `main.py` injects it.
    # BUT `lag_worker` needs `online_writer` too.
    # I will rely on `import main`? No, circular.
    # I will inspect `main.py` where it calls `telegram_cmd_listener`.
    # `task1 = asyncio.create_task(TcPChaT(..., cmd_queue))`
    # `TcPChaT` calls `telegram_cmd_listener(cmd_queue, key, iv, region, ...)`?
    # Let's check `TcPChaT` in `main.py`.
    
    # In `main.py`:
    # if cmd_queue:
    #      asyncio.create_task(telegram_cmd_listener(cmd_queue, key, iv, region, bot_uid, bot_password, LoGinDaTaUncRypTinG.Clan_ID))
    
    # But `cmd_listener.py` definition:
    # `async def telegram_cmd_listener(cmd_queue, key, iv, region):`
    # PREVIOUS VIEW showed only 4 args!
    # Main.py passes 7 args!
    # This means `cmd_listener.py` signature is WRONG or I viewed a truncated version?
    # Let's look at `cmd_listener.py` lines 1-3 again.
    # `async def telegram_cmd_listener(cmd_queue, key, iv, region):`
    # It takes 4 args.
    # `main.py` line 8099: `task1 = asyncio.create_task(TcPChaT(..., cmd_queue))`
    # `TcPChaT` line ??: calls `telegram_cmd_listener`.
    # I need to verify `TcPChaT` call to `telegram_cmd_listener`.
    pass

async def telegram_cmd_listener(cmd_queue, key, iv, region, bot_uid, bot_password, clan_id, join_func):
    global level_running, level_task, uid, chat_id, XX, reject_spam_running, reject_spam_task, current_group_members, lag_running, lag_task

    # Inject dependencies if needed or assume globals
    from main import online_writer, whisper_writer # Attempt import, usually bad practice but might be necessary if separate file
    # Wait, if circular import, this fails.
    # Assume they are available or passed?
    # Let's just implement the logic.
    
    print("background telegram cmd listener started")
    while True:
        try:
            # Process as many as possible
            while cmd_queue and not cmd_queue.empty():
                try:
                    cmd_data = cmd_queue.get_nowait()
                    cmd = cmd_data[0]
                    # print(f"Received CMD: {cmd}")

                    if cmd == 'stop':
                        os._exit(0)
                    
                    elif cmd == 'restart':
                         with open("restart_flag", "w") as f: f.write("restart")
                         os._exit(0)

                    # Requires Bot to be 'In-Game' / Connected (UID/ChatID set)
                    if uid is None or chat_id is None:
                        # print("Waiting for bot to initialize UID/ChatID...")
                        continue

                    if cmd == 'start': # /start <teamcode>
                        team_code = cmd_data[1]
                        asyncio.create_task(run_one_time_start(team_code, uid, chat_id, XX, key, iv))

                    elif cmd == 'join': # /join <teamcode> - JOIN ONLY (No Force Start)
                        team_code = cmd_data[1]
                        # Use injected join function
                        await join_func(team_code, key, iv)


                    
                    
                    elif cmd == 'auto': # /auto <teamcode>
                        team_code = cmd_data[1]
                        if not level_running:
                            level_running = True
                            level_task = asyncio.create_task(level_loop_task(team_code, uid, chat_id, XX, key, iv, region))
                    
                    elif cmd == 'sauto':
                        if level_running:
                            level_running = False
                            if level_task: level_task.cancel()
                    
                    elif cmd == 'lag': # /lag <teamcode>
                        team_code = cmd_data[1]
                        # Stop existing
                        if lag_running:
                             lag_running = False
                             if lag_task: lag_task.cancel()
                             await asyncio.sleep(0.1)
                        
                        lag_running = True
                        # We use the SAME lag_team_loop from main.py if possible?
                        # No, main.py has `lag_team_loop`. Can we import it?
                        # `from main import lag_team_loop`
                        # If we can do that, perfect.
                        from main import lag_team_loop
                        lag_task = asyncio.create_task(lag_team_loop(team_code, key, iv, region))
                        print(f"🔥 Lag started on team {team_code}")

                    elif cmd == 'slag':
                        if lag_running:
                            lag_running = False
                            if lag_task: lag_task.cancel()
                            print("🛑 Lag stopped")
                            
                    elif cmd == 'inv': # /inv <target_uid>
                        target_inv = int(cmd_data[1])
                        # Trigger invite logic
                        # Replicating logic from TcPChaT
                        PAc = await OpEnSq(key, iv, region)
                        if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
                        await asyncio.sleep(0.3)
                        C = await cHSq(5, target_inv, key, iv, region)
                        if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', C)
                        await asyncio.sleep(0.3)
                        V = await SEnd_InV(5, target_inv, key, iv, region)
                        if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
                        await asyncio.sleep(0.3)
                        E = await ExiT(None, key, iv)
                        if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)

                    elif cmd == 'gj': # /gj <guild_id>
                        gid = cmd_data[1]
                        loop = asyncio.get_event_loop()
                        with ThreadPoolExecutor() as executor:
                            await loop.run_in_executor(executor, api_join_guild, bot_uid, bot_password, gid)

                    elif cmd == 'gl': # /gl <guild_id>
                        gid = cmd_data[1]
                        loop = asyncio.get_event_loop()
                        with ThreadPoolExecutor() as executor:
                             await loop.run_in_executor(executor, api_leave_guild, bot_uid, bot_password, gid)

                except Exception as e:
                    print(f"Error processing cmd: {e}")

        except Exception as e:
            pass # Queue empty

        await asyncio.sleep(0.1)
