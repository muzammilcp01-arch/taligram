
import telebot
from telebot import types
import datetime
import requests
import logging

# CONFIG
BOT_TOKEN = "8598370793:AAHx3xUAXPhPKkao9kftjIHk7f-vrlGNPco"
YOUR_BOT_USERNAME = "@TCP_TOM_BOT"
DEVELOPER_NAME = "@THEROSHANCODEX07"
CREDIT = "@THEROSHANCODEX07"
OWNER_NAME = "@THEROSHANCODEX07"
OWNER_URL = "t.me/THEROSHANCODEX"

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="Markdown")

def create_promo_markup(add_me_button=False):
    markup = types.InlineKeyboardMarkup()
    markup.row(types.InlineKeyboardButton("JOIN GROUP", url=f"https://t.me/theroshancodex07chatgroup1"))
    markup.row(types.InlineKeyboardButton("JOIN CHANNEL", url=f"https://t.me/THEROSHANCODEX"))
    if add_me_button:
        username = YOUR_BOT_USERNAME.replace("@", "")
        markup.row(types.InlineKeyboardButton(text="➕ ADD ME TO YOUR GROUP", url=f"http://t.me/{username}?startgroup=start"))
    return markup

@bot.message_handler(commands=['start', 'help'])
def start_handler(message):
    print("DEBUG: /start or /help received!")
    chat_id = message.chat.id
    
    msg_parts = [
        "━━━━━━━━━━━━━━━━━━━━\n",
        "        🤖 𝐆𝐀𝐌𝐄 𝐁𝐎𝐓 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒\n",
        "━━━━━━━━━━━━━━━━━━━━\n\n",
        "🎮 𝐋𝐎𝐁𝐁𝐘 & 𝐓𝐄𝐀𝐌\n",
        "• `/start <teamcode>` - Force start a team once\n",
        "• `/auto <teamcode>` - Auto join/start/leave loop\n",
        "• `/sauto` - Stop auto start\n",
        "• `/inv <uid>` - Create squad & invite player\n",
        "• `/gj <guild_id>` - Join Guild (Admin)\n",
        "• `/gl <guild_id>` - Leave Guild (Admin)\n\n",
        "🎭 𝐄𝐌𝐎𝐓𝐄𝐒 & 𝐅𝐔𝐍\n",
        "• `/bundle <name>` - Send bundle (rampage, etc)\n",
        "• `/b1` - `/b11` - Shortcuts for bundles\n",
        "• `/evo_c <uids> <num> <time>` - Custom Evo Emote Spam\n",
        "• `/dance <uids>` - Send random dance emote\n",
        "• `/rnd <uids>` - Start ultimate dance party\n",
        "• `/srnd` - Stop dance party\n",
        "• `/max <uids>` - Send Max Evo Emotes\n",
        "• `/smax` - Stop Max Evo\n",
        "• `/loop <uids> <emote_num>` - Loop specific emote\n",
        "• `/jevo <teamcode> <uids> <emote>` - Join & Emote\n\n",
        "🛠 𝐀𝐃𝐌𝐈𝐍 & 𝐓𝐎𝐎𝐋𝐒\n",
        "• `/restart` - Restart all bots\n",
        "• `/stop` - Stop bot process\n",
        "• `/ban <uid>` - Ban user from bot\n",
        "• `/unban <uid>` - Unban user\n",
        "• `/mute <time>` - Mute bot (30s, 5m, 1h)\n",
        "• `/unmute` - Unmute bot\n",
        "• `/admin list` - List admins\n",
        "• `/bio <uid>` - Get user bio\n",
        "• `/likes <uid>` - Send likes\n",
        "• `/ms <msg>` - Team spam message\n\n",
        "━━━━━━━━━━━━━━━━━━━━\n",
        f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ: {DEVELOPER_NAME}\n",
        f"❤️ ᴄʀᴇᴅɪᴛ: {CREDIT}\n",
        "━━━━━━━━━━━━━━━━━━━━\n"
    ]
    
    try:
        bot.send_message(chat_id, "".join(msg_parts), reply_markup=create_promo_markup(add_me_button=True))
        print("DEBUG: Message sent (markdown)")
    except Exception as e:
        print(f"DEBUG: Failed Markdown: {e}")
        bot.send_message(chat_id, "".join(msg_parts), reply_markup=create_promo_markup(add_me_button=True), parse_mode=None)
        print("DEBUG: Message sent (text)")

if __name__ == '__main__':
    print("TEST BOT STARTING...")
    print("Please send /start to the bot now.")
    bot.infinity_polling()
