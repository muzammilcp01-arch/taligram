import requests , os , psutil , sys , jwt , pickle , json , binascii , time , urllib3 , base64 , datetime , re , socket , threading , ssl , pytz , aiohttp , logging , subprocess
from multiprocessing import Process
from protobuf_decoder.protobuf_decoder import Parser
from xC4 import * ; from xHeaders import *
from datetime import datetime
from google.protobuf.timestamp_pb2 import Timestamp
from concurrent.futures import ThreadPoolExecutor
from threading import Thread
from Pb2 import DEcwHisPErMsG_pb2 , MajoRLoGinrEs_pb2 , PorTs_pb2 , MajoRLoGinrEq_pb2 , sQ_pb2 , Team_msg_pb2
from cfonts import render, say
import asyncio
import multiprocessing
import signal
import sys
import json
import sqlite3 # Added for DB support
import random
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import telebot
from telebot import types
from html import escape 

# Multiple admin UIDs allowed
# ADMIN_UIDS no longer hardcoded for regular admins, but kept for migration if needed
# We will use OWNER_UID and dynamic persistence
OWNER_UIDS = ["924548792", "811821003"]
ADMIN_FILE = "admins.json"
admin_uids = []
server2 = "IND"
key2 = "TOM"
BYPASS_TOKEN = "your_bypass_token_here"
 

# VariabLes dyli 
#------------------------------------------#
online_writer = None
online_writers = {}
whisper_writer = None
spam_room = False
spammer_uid = None
spam_chat_id = None
spam_uid = None
Spy = False
Chat_Leave = False
fast_spam_running = False
fast_spam_task = None
custom_spam_running = False
custom_spam_task = None
spam_request_running = False
spam_request_task = None
evo_fast_spam_running = False
evo_fast_spam_task = None
# Auto-accept globals
insquad = None
joining_team = False

evo_custom_spam_running = False
evo_custom_spam_task = None
# Add with other global variables
reject_spam_running = False
reject_spam_task = None
lag_running = False
lag_task = None
# Add these with your other global variables at the top
reject_spam_running = False
reject_spam_task = None

# Level/sauto globals
level_running = False
level_task = None
PROMO_TEXT = "Instagram @ig._tom_"

evo_cycle_running = False
evo_cycle_task = None

lag_task = None
evos_running = False
SMAX_STOP = False
MAX_TASK = None
SRND_STOP = False
RND_TASK = None
RND_TASK = None
BADGE_SPAM_TASK = None   # asyncio.Task for /s1-/s5-/sm
BADGE_SPAM_STOP = False  # flag to ask the task to stop
reject_spam_running = False
reject_spam_task = None

# NEW: Store current group members
current_group_members = []
current_group_members = []
bot_uid = None
bot_password = None
chat_id = None
uid = None
XX = None
#------------------------------------------#
# 🚫 NEW: Ban system globals
BANNED_FILE = "banned_players.json"
banned_uids = []
bot_password = None
chat_id = None
uid = None
XX = None
# Global list of queues for broadcasting commands
# Global Dictionary of queues for broadcasting commands (UID -> Queue)
bot_queues = {}
# Global Dictionary to store writers for each bot
online_writers = {}
#------------------------------------------#
# 🔇 NEW: bot mute state
is_muted = False        # True = bot ignores commands from non-admins
mute_until = 0          # unix timestamp when mute expires
#------------------------------------------#
# 🚫 NEW: Reject Blocked UIDs
REJECT_BLOCKED_UIDS = set()
#------------------------------------------#
# 🔒 Bot Lock State
bot_locked = False

# 👥 Active Users Tracking (For Broadcast)
active_users = set()

def log_cmd(message):
    try:
        user_id = message.from_user.id
        content = message.text if message.text else str(message.content_type)
        print(f"📝 Activity: {content} | User: {user_id}")
        
        save_tg_user(user_id)     # Track persistent user (total)
    except Exception as e:
        print(f"❌ Error in log_cmd: {e}")
#------------------------------------------#

# ------------------------------------------#
COMMAND_BUTTONS_LAYOUT_USER_SPEC = [
    ["🛠 Full Menu"],
    ["👫 Group Menu", "⚠️ Attack Menu"],
    ["📈 Levelup Menu", "⚜️ Admin Menu"],
    ["⚡ Bot Speed", "📊 Statistics"],
    ["📞 Contact Owner"]
]

ADMIN_COMMAND_BUTTONS_LAYOUT_USER_SPEC = [
    ["🛠 Full Menu"],
    ["👫 Group Menu", "⚠️ Attack Menu"],
    ["📈 Levelup Menu", "⚜️ Admin Menu"],
    ["⚡ Bot Speed", "📊 Statistics"],
    ["🔒 Lock Bot", "📢 Broadcast"],
    ["👑 Admin Panel", "🔄 Restart"],
    ["📞 Contact Owner"]
]
# ------------------------------------------#

# Emote mapping for evo commands
EMOTE_MAP = {
    1: 909000063,
    2: 909000068,
    3: 909000075,
    4: 909000081,
    5: 909000085,
    6: 909000098,
    7: 909000090,
    8: 909033002,
    9: 909035007,
    10: 909033001,
    11: 909037011,
    12: 909035012,
    13: 909038010,
    14: 909039011,
    15: 909040010,
    16: 909041005,
    17: 909042008,
    18: 909045001,
    19: 909049010,
    20: 909038012,
    21: 909051003
}
# Badge values for s1 to s8 commands - using your exact values
BADGE_VALUES = {
    "s1": 1048576,    # Your first badge
    "s2": 32768,      # Your second badge  
    "s3": 2048,       # Your third badge
    "s4": 64,         # Your fourth badge
    "s5": 262144     # Your seventh badge
}

# Load General Emotes
GENERAL_EMOTES_MAP = {}
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EMOTES_FILE = os.path.join(BASE_DIR, 'emotes.json')
LEVELUP_FILE = os.path.join(BASE_DIR, 'levelup.json')
TEMBSAVE_FILE = os.path.join(BASE_DIR, 'tembsave.json')

# Global to track in-memory queues for dynamic workers
levelup_queues = {}
MAIN_ACCOUNT_UIDS = [] # Track UIDs from accounts.json for exclusive /join access
SPAM_ACCOUNT_UIDS = [] # Track UIDs from spam.json
active_spam_bots = set() # Track busy spam bots
SPAM_FILE = os.path.join(BASE_DIR, 'spam.json')
ADMIN_FILE = os.path.join(BASE_DIR, 'admins.json')
admin_uids = []

def load_admin_uids():
    global admin_uids
    try:
        if os.path.exists(ADMIN_FILE):
            with open(ADMIN_FILE, "r") as f: val = json.load(f)
            if isinstance(val, list): admin_uids = val
    except: pass

def is_admin(user_id):
    load_admin_uids() # Refresh on check or use cached? Better refresh or load once. XHOST loads into set.
    # For simplicity and to catch external edits, we can reload or just check list.
    # Let's rely on global list and maybe reload occasionally? 
    # The new callbacks update the file AND the list?
    # No, my added callbacks update the file. They didn't update the global list in memory!
    # Wait, process_add_admin in my new code: 
    #    with open(ADMIN_FILE, 'r') as f: admins = json.load(f) ... with open.. write
    # It interacts with file directly.
    # So is_admin should read the file or the global list if we keep it synced.
    # Let's make is_admin read the global list, and load_admin_uids populate it.
    # But my previous code (callbacks) didn't update the global `admin_uids`.
    # I should have `is_admin` just check the file or ensure sync.
    # Let's make is_admin clean:
    return str(user_id) in admin_uids or str(user_id) in OWNER_UIDS

def is_bot_locked_for_user(user_id):
    return bot_locked and not (is_admin(user_id) or str(user_id) in OWNER_UIDS)

# ------------------------------------------#
def load_banned_uids():
    global banned_uids
    fname = getattr(sys.modules[__name__], 'BANNED_FILE', 'banned_players.json')
    try:
        if os.path.exists(fname):
            with open(fname, "r") as f: val = json.load(f)
            if isinstance(val, list): banned_uids = val
    except: pass

def save_banned_uids():
    fname = getattr(sys.modules[__name__], 'BANNED_FILE', 'banned_players.json')
    try:
        with open(fname, "w") as f: json.dump(banned_uids, f)
    except Exception as e: print(f"Error saving banned uids: {e}")

load_banned_uids()

# 💾 NEW: TembSave Helpers (User <-> Bot Assignment)
def load_tembsave():
    try:
        if os.path.exists(TEMBSAVE_FILE):
             with open(TEMBSAVE_FILE, "r") as f:
                return json.load(f)
        return {}
    except: return {}

def save_tembsave(data):
    try:
        with open(TEMBSAVE_FILE, "w") as f:
            json.dump(data, f)
    except Exception as e:
        print(f"Error saving tembsave: {e}")

def assign_bot_to_user(user_id, bot_uid, team_code):
    data = load_tembsave()
    uid_str = str(user_id)
    if uid_str not in data: data[uid_str] = {"bots": []}
    
    # Avoid duplicate assignment
    current_bots = data[uid_str]["bots"]
    if not any(b['uid'] == str(bot_uid) for b in current_bots):
        data[uid_str]["bots"].append({
            "uid": str(bot_uid), 
            "team": team_code, 
            "ts": time.time()
        })
        save_tembsave(data)

def free_bot_from_user(user_id, bot_uid):
    data = load_tembsave()
    uid_str = str(user_id)
    if uid_str in data:
        current_bots = data[uid_str].get("bots", [])
        original_len = len(current_bots)
        
        # Filter out the specific bot
        new_bots = [b for b in current_bots if b["uid"] != str(bot_uid)]
        data[uid_str]["bots"] = new_bots
        
        # Check if changed
        if len(new_bots) < original_len:
            # If empty, remove user key
            if not new_bots:
                del data[uid_str]
            save_tembsave(data)
            return True
            
    return False

def check_user_limit(user_id):
    data = load_tembsave()
    bots = data.get(str(user_id), {}).get("bots", [])
    # Limit: Max 2 bots per user
    return len(bots) < 2

def find_reclaimable_bot():
    # Find a user with >= 2 bots to steal from
    data = load_tembsave()
    for uid, info in data.items():
        bots = info.get("bots", [])
        if len(bots) >= 2:
            return uid, bots[0]["uid"] # Return oldest bot
    return None, None

def get_bot_owner(bot_uid):
    data = load_tembsave()
    for uid, info in data.items():
        for b in info.get("bots", []):
            if b["uid"] == str(bot_uid):
                return uid
    return None

import threading
def cleanup_monitor():
    while True:
        try:
            data = load_tembsave()
            dirty = False
            now = time.time()
            to_remove_uids = []
            
            for uid, info in data.items():
                bots = info.get("bots", [])
                active_bots = []
                for b in bots:
                    # 10 minutes = 600 seconds
                    if now - b["ts"] < 600:
                        active_bots.append(b)
                    else:
                        dirty = True
                        print(f"♻️ Auto-reclaiming idle bot {b['uid']} from {uid}")
                        # Could trigger /solo logic here if needed, but for now just clearing record
                        # Ideally we should send a signal to stop the bot too
                        # For now, we just clear the ownership so others can take it
                        
                        # Trigger solo command equivalent in queue if possible? 
                        # Or just let 'join' take it later.
                        # If we just clear data, the bot process keeps running until someone else joins.
                        # User asked: "auto stop prosses and auto solo clear data"
                        if b['uid'] in bot_queues:
                            bot_queues[b['uid']].put(('solo',)) # Force solo
                
                data[uid]["bots"] = active_bots
                if not active_bots: to_remove_uids.append(uid)
            
            for u in to_remove_uids:
                del data[u]
                dirty = True
                
            if dirty: save_tembsave(data)
            
        except Exception as e:
            print(f"Cleanup Monitor Error: {e}")
        time.sleep(60) # Check every minute




# 📊 User Persistence (Restored for Statistics)
DATABASE_PATH = os.path.join(BASE_DIR, 'bot_data.db')
DB_LOCK = threading.Lock()

def init_db():
    try:
        conn = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS active_users
                     (user_id INTEGER PRIMARY KEY)''')
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"❌ DB Init Error: {e}")

def load_tg_users():
    global active_users 
    try:
        init_db()
        conn = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
        c = conn.cursor()
        
        # 🔄 Restored Migration: Import from JSON if DB is empty
        try:
            c.execute('SELECT COUNT(*) FROM active_users')
            if c.fetchone()[0] == 0:
                json_path = os.path.join(BASE_DIR, "tg_user.json")
                if os.path.exists(json_path):
                    print("🔄 Migrating old JSON users to DB...")
                    with open(json_path, 'r') as f:
                        old_data = json.load(f)
                        if isinstance(old_data, list):
                            for uid in old_data:
                                c.execute('INSERT OR IGNORE INTO active_users (user_id) VALUES (?)', (uid,))
                            conn.commit()
                    print("✅ Migration complete.")
        except Exception as mig_e: print(f"⚠️ Migration warning: {mig_e}")

        c.execute('SELECT user_id FROM active_users')
        loaded = set(row[0] for row in c.fetchall())
        active_users.update(loaded)
        conn.close()
        print(f"✅ Loaded {len(loaded)} users from DB.")
    except Exception as e:
        print(f"❌ Error loading from DB: {e}")

def add_active_user(user_id):
    if user_id in active_users: return
    active_users.add(user_id)
    with DB_LOCK:
        try:
            conn = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
            c = conn.cursor()
            c.execute('INSERT OR IGNORE INTO active_users (user_id) VALUES (?)', (user_id,))
            conn.commit()
            # print(f"✅ Added {user_id} to DB") # Silent success to avoid spam
            conn.close()
        except Exception as e:
            print(f"❌ Error saving to DB: {e}")

save_tg_user = add_active_user # Alias
load_tg_users()

def clear_tembsave():
    """Clear all assignments on startup"""
    save_tembsave({})
    print("✅ TembSave Cleared (Startup).")

import atexit 
atexit.register(clear_tembsave)

# Clear on startup
clear_tembsave()

def assign_bots_to_user(user_id, count=3):
    """Assign bots to user, freeing up oldest users if necessary"""
    user_id = str(user_id)
    data = load_tembsave()
    current_time = time.time()
    
    # 1. Check if user already has bots
    if user_id in data and data[user_id]:
        # Handle backward compatibility or new struct
        record = data[user_id]
        if isinstance(record, list): # Old format
             return record, []
        if isinstance(record, dict) and 'bots' in record:
             # EXTRACT UIDS from the dict objects
             return [b['uid'] for b in record['bots'] if isinstance(b, dict)] + [b for b in record['bots'] if isinstance(b, str)], []
        
    # 2. Find available bots
    assigned_bots = set()
    user_records = [] # (uid, time, bots)
    
    for uid, info in data.items():
        if isinstance(info, list): # Legacy
            for b in info: assigned_bots.add(b)
            user_records.append((uid, 0, info))
        elif isinstance(info, dict):
            # NEW: Handle list of dicts or strings
            current_bots = info.get('bots', [])
            extracted_uids = []
            for b in current_bots:
                if isinstance(b, dict):
                    assigned_bots.add(b['uid'])
                    extracted_uids.append(b['uid'])
                else:
                     assigned_bots.add(b)
                     extracted_uids.append(b)
            user_records.append((uid, info.get('time', 0), extracted_uids))

    available = [b for b in SPAM_ACCOUNT_UIDS if b not in assigned_bots and b not in active_spam_bots and b in bot_queues]
    
    kicked_bots = []
    
    # 3. If not enough, kick oldest users
    if len(available) < count:
        # Sort by time (oldest first)
        user_records.sort(key=lambda x: x[1])
        
        while len(available) < count and user_records:
            victim_uid, v_time, v_bots = user_records.pop(0)
            
            # Remove victim from data
            if victim_uid in data:
                del data[victim_uid]
            
            # Add victim's bots to available
            for b in v_bots:
                if b in active_spam_bots:
                    active_spam_bots.remove(b)
                available.append(b)
                kicked_bots.append(b)
                
            # print(f"⚠️ Kicked User {victim_uid} to free {len(v_bots)} bots.")

    if len(available) < count:
        return None, [] # Still not enough
        
    picked = random.sample(available, count)
    
    # 4. Assign to new user with timestamp
    data[user_id] = {
        "bots": picked,
        "time": current_time
    }
    save_tembsave(data)
    
    active_spam_bots.update(picked)
    
    return picked, kicked_bots

def release_user_bots(user_id):
    """Release bots assigned to user"""
    user_id = str(user_id)
    data = load_tembsave()
    
    bots = []
    if user_id in data:
        record = data[user_id]
        raw_bots = []
        if isinstance(record, list):
            raw_bots = record
        elif isinstance(record, dict):
            raw_bots = record.get('bots', [])
        
        # Extract UIDs
        for b in raw_bots:
            if isinstance(b, dict):
                bots.append(b.get('uid'))
            else:
                bots.append(b)
            
        del data[user_id]
        save_tembsave(data)
        
        for b in bots:
            if b in active_spam_bots:
                active_spam_bots.remove(b)
                
    return bots

def get_user_bots(user_id):
    data = load_tembsave()
    record = data.get(str(user_id))
    if not record: return []
    if isinstance(record, list): return record
    if isinstance(record, dict): return record.get('bots', [])

# ------------------------------------------#



try:
    if os.path.exists(EMOTES_FILE):
        with open(EMOTES_FILE, 'r') as f:
            e_list = json.load(f)
            GENERAL_EMOTES_MAP = {str(item["Number"]): str(item["Id"]) for item in e_list}
            print(f"DEBUG: Loaded {len(GENERAL_EMOTES_MAP)} emotes from {EMOTES_FILE}")
    else:
        print(f"Warning: emotes.json not found at {EMOTES_FILE}")
        GENERAL_EMOTES_MAP = {str(i): "909000001" for i in range(1, 410)} # Default to a valid ID instead of 0
except Exception as e:
    print(f"Warning: Failed to load emotes.json: {e}")
    # Fallback
    GENERAL_EMOTES_MAP = {str(i): "909000001" for i in range(1, 410)}

# Load New Emotes
NEW_EMOTES_MAP = {}
try:
    if os.path.exists('new.json'):
        with open('new.json', 'r') as f:
            n_list = json.load(f)
            NEW_EMOTES_MAP = {str(item["Number"]): str(item["Id"]) for item in n_list}
except Exception as e:
    print(f"Warning: Failed to load new.json: {e}")



# Helper Functions
def is_admin(uid):
    # Reload admins to ensure sync across multi-processes
    load_admins() 
    return str(uid) in OWNER_UIDS or str(uid) in admin_uids

# 👑 NEW: Admin Management Helpers
def load_admins():
    global admin_uids
    try:
        if os.path.exists(ADMIN_FILE):
             with open(ADMIN_FILE, "r") as f:
                admin_uids = json.load(f)
        else:
            admin_uids = []
    except Exception as e:
        # print(f"Error loading admins: {e}")
        admin_uids = []

def save_admins():
    try:
        with open(ADMIN_FILE, "w") as f:
            json.dump(admin_uids, f)
    except Exception as e:
        print(f"Error saving admins: {e}")

def add_admin(target_uid):
    target_uid = str(target_uid)
    if target_uid not in admin_uids:
        admin_uids.append(target_uid)
        save_admins()
        return True
    return False

def remove_admin(target_uid):
    target_uid = str(target_uid)
    if target_uid in admin_uids:
        admin_uids.remove(target_uid)
        save_admins()
        return True
    return False

# Load admins on startup
load_admins()

# 🚫 NEW: Ban Helper Functions
def load_banned_players():
    global banned_uids
    try:
        if os.path.exists(BANNED_FILE):
             with open(BANNED_FILE, "r") as f:
                banned_uids = json.load(f)
        else:
            banned_uids = []
    except Exception as e:
        print(f"Error loading banned players: {e}")
        banned_uids = []

def save_banned_players():
    try:
        with open(BANNED_FILE, "w") as f:
            json.dump(banned_uids, f)
    except Exception as e:
        print(f"Error saving banned players: {e}")

def ban_player(target_uid):
    target_uid = str(target_uid)
    if target_uid not in banned_uids:
        banned_uids.append(target_uid)
        save_banned_players()
        return True
    return False

def unban_player(target_uid):
    target_uid = str(target_uid)
    if target_uid in banned_uids:
        banned_uids.remove(target_uid)
        save_banned_players()
        return True
    return False

def unban_all_players():
    global banned_uids
    banned_uids = []
    save_banned_players()
    return True

def is_banned(target_uid):
    return str(target_uid) in banned_uids

# Load bans on startup
load_banned_players()


def is_bot_muted():
    global is_muted, mute_until
    if is_muted and time.time() < mute_until:
        return True
    elif is_muted and time.time() >= mute_until:
        is_muted = False
        mute_until = 0
        return False
    return False

def fix_num(num):
    fixed = ""
    count = 0
    num_str = str(num)  # Convert the number to a string

    for char in num_str:
        if char.isdigit():
            count += 1
        fixed += char
        if count == 3:
            fixed += "[c]"
            count = 0  
    return fixed


def fix_word(num):
    fixed = ""
    count = 0
    
    for char in num:
        if char:
            count += 1
        fixed += char
        if count == 3:
            fixed += "[c]"
            count = 0  
    return fixed
    

def parse_results(parsed_results):
    """Helper for get_available_room - port from ff/main.py"""
    result_dict = {}
    for result in parsed_results:
        field_data = {}
        field_data["wire_type"] = result.wire_type
        if result.wire_type == "varint":
            field_data["data"] = result.data
        elif result.wire_type == "string":
            field_data["data"] = result.data
        elif result.wire_type == "bytes":
            field_data["data"] = result.data
        elif result.wire_type == "length_delimited":
            if hasattr(result.data, 'results'):
                field_data["data"] = parse_results(result.data.results)
            else:
                field_data["data"] = result.data
        result_dict[result.field] = field_data
    return result_dict

def get_available_room(input_text):
    """Parse protobuf to JSON - port from ff/main.py"""
    try:
        from protobuf_decoder.protobuf_decoder import Parser
        parsed_results = Parser().parse(input_text)
        if not parsed_results:
            return None
        parsed_results_dict = parse_results(parsed_results)
        return json.dumps(parsed_results_dict)
    except Exception as e:
        # print(f"error parsing proto: {e}")
        return None

async def join_squad_only(team_code, key, iv):
    """
    Helper to join a squad without force starting.
    Uses global online_writer from main.py scope.
    """
    print(f"DEBUG: join_squad_only called for team {team_code}")
    try:
        if online_writer is None:
             print(f"❌ [Main] Cannot join {team_code}: online_writer is None (Connection not ready)")
             return

        print(f"DEBUG: Generating join packet for {team_code}...")
        JP = await GenJoinSquadsPacket(team_code, key, iv)
        print(f"DEBUG: Packet generated: {JP[:50]}...")
        
        if online_writer: 
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', JP)
            print(f"✅ [Main] Joined team {team_code} (Packet Sent)")
        else:
            print(f"⚠️ [Main] Cannot join {team_code}: online_writer became None")
    except Exception as e:
        print(f"❌ [Main] Error joining team {team_code}: {e}")
        import traceback
        traceback.print_exc()

def get_player_status(packet, parsed_json=None):
    """Get player status from packet - robust version"""
    try:
        parsed_data = parsed_json
        if not parsed_data:
            json_result = get_available_room(packet)
            if not json_result:
                return "UNKNOWN"
            parsed_data = json.loads(json_result)
        
        # Helper to find status field (key '3')
        def find_status(obj):
            if isinstance(obj, dict):
                # Check if this node looks like player data
                if '3' in obj and 'data' in obj['3']:
                    val = obj['3']['data']
                    if isinstance(val, int):
                        return val
                
                # Recursive search
                for k, v in obj.items():
                    res = find_status(v)
                    if res is not None: return res
                    
            elif isinstance(obj, list):
                for item in obj:
                    res = find_status(item)
                    if res is not None: return res
            return None

        # Try strict path first
        valid_strict = False
        try:
            if "5" in parsed_data and "data" in parsed_data["5"]:
                p5 = parsed_data["5"]["data"]
                if "1" in p5 and "data" in p5["1"]:
                    data = p5["1"]["data"]
                    valid_strict = True
                    if "3" in data and "data" in data["3"]:
                        status = data["3"]["data"]
                        if status == 1: return "SOLO"
                        if status == 2:
                            group_count = data.get("9", {}).get("data", 1)
                            countmax = data.get("10", {}).get("data", 3) + 1
                            return f"INSQUAD ({group_count}/{countmax})"
                        if status == 4: return "IN ROOM"
                    else:
                        return "OFFLINE"
        except:
            pass
            
        # Fallback search if strict path failed or wasn't found
        if not valid_strict:
            print("⚠️ Strict status path failed, searching recursively...")
            status = find_status(parsed_data)
            if status is not None:
                if status == 1: return "SOLO"
                if status == 2: return "INSQUAD (Unknown Size)"
                if status == 3: return "INGAME"
                if status == 4: return "IN ROOM"
                return f"UNKNOWN_STATE_{status}"

        return "NOT_FOUND"
    except Exception as e:
        print(f"Status parse error: {e}")
        return "ERROR"

def get_idroom_by_idplayer(packet):
    """Extract room ID from player info packet - port from ff/main.py"""
    try:
        json_result = get_available_room(packet)
        if not json_result:
            return None
        parsed_data = json.loads(json_result)
        json_data = parsed_data["5"]["data"]
        data = json_data["1"]["data"]
        idroom = data.get('15', {}).get("data")
        return idroom
    except Exception:
        return None


# Load emotes from JSON file
def load_emotes_from_json():
    try:
        # Use absolute path to ensure file is found
        emotes_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'emotes.json')
        with open(emotes_path, 'r') as f:
            emotes_data = json.load(f)
        emotes_map = {}
        for emote in emotes_data:
            if str(emote.get('Number')) != 'no':
                # Force key to string for consistent lookup
                emotes_map[str(emote['Number'])] = int(emote['Id'])
        print(f"Loaded {len(emotes_map)} emotes from emotes.json")
        return emotes_map
    except Exception as e:
        print(f"Error loading emotes.json: {e}")
        return {}

# Load new emotes from JSON file
def load_new_emotes_from_json():
    try:
        with open('new.json', 'r') as f:
            emotes_data = json.load(f)
        emotes_map = {}
        for emote in emotes_data:
            if emote['Number'] != 'no':
                emotes_map[emote['Number']] = int(emote['Id'])
        return emotes_map
    except Exception as e:
        print(f"Error loading new.json: {e}")
        return {}
class ParsedResult:
    # Assuming this class has some attributes
    def __init__(self, data):
        self.data = data

    def to_dict(self):
        return {'data': self.data}  # Convert to a dictionary

# Example usage
result = ParsedResult("example data")
try:
    json_data = json.dumps(result.to_dict())  # Serialize to JSON
except TypeError as e:
    print(f"Serialization error: {e}")

# Ensure you're not passing None
if result is not None:
    # Process the result
    pass
else:
    print("Received NoneType result.")

# Standalone function to load accounts
def load_accounts():
    """Load multiple accounts from JSON file"""
    accounts_file = "accounts.json"
    try:
        with open(accounts_file, "r", encoding="utf-8") as f:
            accounts = json.load(f)
            return accounts
    except FileNotFoundError:
        print(f"❌ Accounts file {accounts_file} not found!")
        return {}
    except Exception as e:
        print(f"❌ Error loading accounts: {e}")
        return {}

async def auto_rings_emote_dual(sender_uid, key, iv, region):
    """Send The Rings emote to both sender and bot for dual emote effect"""
    try:
        # The Rings emote ID
        rings_emote_id = 909050009
        
        # Get bot's UID
        bot = bot_uid
        
        # Send emote to SENDER (person who invited)
        # emote_to_sender = await Emote_k(int(sender_uid), rings_emote_id, key, iv, region)
        # await SEndPacKeT(whisper_writer, online_writer, 'OnLine', emote_to_sender)
        
        # Small delay between emotes
        await asyncio.sleep(0.5)
        
        # Send emote to BOT (bot performs emote on itself)
        emote_to_bot = await Emote_k(int(bot), rings_emote_id, key, iv, region)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', emote_to_bot)
        
        print(f"🤖 Bot performed dual Rings emote with sender {sender_uid} and bot {bot_uid}!")
        
    except Exception as e:
        print(f"Error sending dual rings emote: {e}")

# Ported from ff/main.py
# Ported from ff/main.py
# Ported from ff/main.py
async def jevo_operation_v2(team_code, target_uids, emote_number, key, iv, region, writer):
    emote_id = EMOTE_MAP.get(int(emote_number))
    if not emote_id: return False

    try:
        # JOIN
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, writer, 'OnLine', join_packet)
        await asyncio.sleep(1.8)

        # EMOTES (NO DELAY BETWEEN UIDS)
        for t_uid in target_uids:
            pkt = await Emote_k(int(t_uid), int(emote_id), key, iv, region)
            await SEndPacKeT(whisper_writer, writer, 'OnLine', pkt)

        # LEAVE
        await asyncio.sleep(0.2)
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, writer, 'OnLine', leave_packet)
        return True
    except Exception as e:
        print("JEVO ERROR:", e)
        return False

async def jrevo_operation_v2(team_code, target_uids, key, iv, region, writer):
    try:
        # 1. JOIN
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, writer, 'OnLine', join_packet)
        await asyncio.sleep(1.8)

        # 2. RANDOM EVO EMOTES
        for t_uid in target_uids:
            random_emote = random.choice(list(EMOTE_MAP.values()))
            emote_packet = await Emote_k(int(t_uid), int(random_emote), key, iv, region)
            await SEndPacKeT(whisper_writer, writer, 'OnLine', emote_packet)

        # 3. LEAVE
        await asyncio.sleep(0.2)
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, writer, 'OnLine', leave_packet)
        return True
    except Exception as e:
        print("JREVO ERROR:", e)
        return False

# Fixed Emote Packet Generator (Forces 0515 like Join/Leave)
async def Emote_k_Safe(TarGeT , idT, K, V, region):
    fields = {
        1: 21,
        2: {
            1: 804266360,
            2: 909000001,
            5: {
                1: TarGeT,
                3: idT,
            }
        }
    }
    # Force 0515 to match GenJoinSquadsPacket and ExiT which are working
    packet = "0515" 
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex() , packet , K , V)

async def jp_operation_v2(team_code, target_uids, emote_number, key, iv, region, writer):
    # Uses GENERAL_EMOTES_MAP
    emote_id = GENERAL_EMOTES_MAP.get(str(emote_number))
    
    # Fallback: If input seems to be a raw ID (length > 5)
    if not emote_id and len(str(emote_number)) > 5:
        emote_id = emote_number
        print(f"DEBUG JP: Using Raw Emote ID: {emote_id}")
    else:
        print(f"DEBUG JP: Requested '{emote_number}'. Found ID: {emote_id}")
    
    if not emote_id: 
        print(f"DEBUG JP: Emote '{emote_number}' not found in map (Size {len(GENERAL_EMOTES_MAP)})")
        return False

    try:
        # 1. JOIN
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, writer, 'OnLine', join_packet)
        await asyncio.sleep(1.8)

        # 2. EMOTES
        for t_uid in target_uids:
            try:
                # Use Safe/Fixed Emote function
                pkt = await Emote_k_Safe(int(t_uid), int(emote_id), key, iv, region)
                print(f"DEBUG JP: Sending Emote {emote_id} to {t_uid}")
                await SEndPacKeT(whisper_writer, writer, 'OnLine', pkt)
                # Small delay to prevent packet flooding/loss
                await asyncio.sleep(0.05)
            except Exception as e_send:
                print(f"DEBUG JP: Error sending to {t_uid}: {e_send}")

        # 3. LEAVE
        await asyncio.sleep(0.2)
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, writer, 'OnLine', leave_packet)
        return True
    except Exception as e:
        print("JP ERROR:", e)
        return False

async def jevo_operation_legacy(team_code, target_uids, emote_number, key, iv, region): # Keeping name distinct if checking against old references, but standardizing on jevo_operation above.
     pass # Placeholder to avoid re-insertion errors if matching lines. But I am inserting NEW content.




async def jevor_operation(
    team_code,
    target_uids,
    key,
    iv,
    region
):
    # EVO EMOTE MAP (1–21)
    EVO_MAP = {
        1: 909000063, 2: 909000068, 3: 909000075, 4: 909000081,
        5: 909000085, 6: 909000098, 7: 909000090, 8: 909033002,
        9: 909035007, 10: 909033001, 11: 909037011, 12: 909035012,
        13: 909038010, 14: 909039011, 15: 909040010, 16: 909041005,
        17: 909042008, 18: 909045001, 19: 909049010, 20: 909038012,
        21: 909051003
    }

    try:
        # 1️⃣ JOIN TEAM (same as /jel & /jevo)
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)

        # REQUIRED JOIN SYNC (DO NOT REMOVE)
        await asyncio.sleep(1.8)

        # 2️⃣ SEND RANDOM EVO TO EACH UID (ZERO DELAY)
        for t_uid in target_uids:
            random_emote = random.choice(list(EVO_MAP.values()))
            emote_packet = await Emote_k(
                int(t_uid),
                int(random_emote),
                key,
                iv,
                region
            )
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', emote_packet)

        # small safety gap before leaving
        await asyncio.sleep(0.2)

        # 3️⃣ LEAVE TEAM
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_packet)

        return True

    except Exception as e:
        print("JEVOR ERROR:", e)
        return False

async def jp_operation(
    team_code,
    target_uids,
    emote_number,
    key,
    iv,
    region
):
    # Uses SAME emote map as /p
    emote_id = GENERAL_EMOTES_MAP.get(str(emote_number))
    if not emote_id:
        return False

    try:
        # 1️⃣ JOIN TEAM (same as /jevo)
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)

        # REQUIRED JOIN SYNC
        await asyncio.sleep(1.8)

        # 2️⃣ SEND EMOTES — ZERO DELAY (LIKE /p)
        for t_uid in target_uids:
            pkt = await Emote_k(
                int(t_uid),
                int(emote_id),
                key,
                iv,
                region
            )
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)

        # small safety gap
        await asyncio.sleep(0.2)

        # 3️⃣ LEAVE TEAM
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_packet)

        return True

    except Exception as e:
        print("JP ERROR:", e)
        return False

async def jnew_operation(
    team_code,
    target_uids,
    emote_number,
    key,
    iv,
    region
):
    # Uses NEW emote map
    emote_id = NEW_EMOTES_MAP.get(str(emote_number))
    if not emote_id:
        return False

    try:
        # 1️⃣ JOIN TEAM (same as /jevo)
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)

        # REQUIRED JOIN SYNC
        await asyncio.sleep(1.8)

        # 2️⃣ SEND EMOTES — ZERO DELAY (LIKE /p)
        for t_uid in target_uids:
            pkt = await Emote_k(
                int(t_uid),
                int(emote_id),
                key,
                iv,
                region
            )
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)

        # small safety gap
        await asyncio.sleep(0.2)

        # 3️⃣ LEAVE TEAM
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_packet)

        return True

    except Exception as e:
        print("JNEW ERROR:", e)
        return False

async def jpr_operation(team_code, uids, key, iv, region):
    try:
        # 1️⃣ JOIN TEAM
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)

        # REQUIRED JOIN SYNC (ONCE)
        await asyncio.sleep(1.5)

        # 2️⃣ SEND RANDOM GENERAL EMOTE PER UID (LIKE /p)
        emote_ids = list(GENERAL_EMOTES_MAP.values())

        for uid in uids:
            emote_id = random.choice(emote_ids)

            pkt = await Emote_k(
                int(uid),
                int(emote_id),
                key,
                iv,
                region
            )
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)

        # 3️⃣ LEAVE TEAM
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_packet)

        return True

    except Exception as e:
        print("JPR ERROR:", e)
        return False


async def check_player_in_room(target_uid, key, iv):
    """Check if player is in a room by sending status request"""
    try:
        # Send status request packet
        status_packet = await GeT_Status(int(target_uid), key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', status_packet)
        
        # You'll need to capture the response packet and parse it
        # For now, return True and we'll handle room detection in the main loop
        return True
    except Exception as e:
        print(f"Error checking player room status: {e}")
        return False
        
        
        


class MultiAccountManager:
    def __init__(self):
        self.accounts_file = "accounts.json"
        self.accounts_data = self.load_accounts()
    
    def load_accounts(self):
        """Load multiple accounts from JSON file"""
        try:
            with open(self.accounts_file, "r", encoding="utf-8") as f:
                accounts = json.load(f)

                return accounts
        except FileNotFoundError:
            print(f"❌ Accounts file {self.accounts_file} not found!")
            return {}
        except Exception as e:
            print(f"❌ Error loading accounts: {e}")
            return {}
    
    
    
    async def get_account_token(self, uid, password):
        """Get access token for a specific account"""
        try:
            url = "https://100067.connect.garena.com/oauth/guest/token/grant"
            headers = {
                "Host": "100067.connect.garena.com",
                "User-Agent": await Ua(),
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept-Encoding": "gzip, deflate, br",
                "Connection": "close"
            }
            data = {
                "uid": uid,
                "password": password,
                "response_type": "token",
                "client_type": "2",
                "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
                "client_id": "100067"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, data=data) as response:
                    if response.status == 200:
                        data = await response.json()
                        open_id = data.get("open_id")
                        access_token = data.get("access_token")
                        return open_id, access_token
            return None, None
        except Exception as e:
            print(f"❌ Error getting token for {uid}: {e}")
            return None, None
    
    async def send_join_from_account(self, target_uid, account_uid, password, key, iv, region):
        """Send join request from a specific account"""
        try:
            # Get token for this account
            open_id, access_token = await self.get_account_token(account_uid, password)
            if not open_id or not access_token:
                return False
            
            # Create join packet using the account's credentials
            join_packet = await self.create_account_join_packet(target_uid, account_uid, open_id, access_token, key, iv, region)
            if join_packet:
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)
                return True
            return False
            
        except Exception as e:
            print(f"❌ Error sending join from {account_uid}: {e}")
            return False
            
async def SEnd_InV_with_Cosmetics(Nu, Uid, K, V, region, badge=None):
    """Send invite with cosmetics - optionally with specific badge"""
    region = "ind"
    badge_value = badge if badge is not None else random.choice([1048576, 32768, 2048])
    fields = {
        1: 2, 
        2: {
            1: int(Uid), 
            2: region, 
            4: int(Nu),
            # Simply add field 5 with basic cosmetics
            5: {
                1: "BOT",                    # Name
                2: int(await get_random_avatar()),     # Avatar
                5: badge_value,  # Use provided badge or random
            }
        }
    }

    if region.lower() == "ind":
        packet = '0514'
    elif region.lower() == "bd":
        packet = "0519"
    else:
        packet = "0515"
        
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), packet, K, V)   
            
async def join_custom_room(room_id, room_password, key, iv, region):
    """Join custom room with proper Free Fire packet structure"""
    fields = {
        1: 61,  # Room join packet type (verified for Free Fire)
        2: {
            1: int(room_id),
            2: {
                1: int(room_id),  # Room ID
                2: int(time.time()),  # Timestamp
                3: "BOT",  # Player name
                5: 12,  # Unknown
                6: 9999999,  # Unknown
                7: 1,  # Unknown
                8: {
                    2: 1,
                    3: 1,
                },
                9: 3,  # Room type
            },
            3: str(room_password),  # Room password
        }
    }
    
    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"
        
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), packet_type, key, iv)
    
# Load the emotes mapping
GENERAL_EMOTES_MAP = load_emotes_from_json()
NEW_EMOTES_MAP = load_new_emotes_from_json()

async def reset_bot_state(key, iv, region):
    """Reset bot to solo mode before spam - Critical step from your old TCP"""
    try:
        # Leave any current squad (using your exact leave_s function)
        leave_packet = await leave_squad(key, iv, region)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_packet)
        await asyncio.sleep(0.5)
        
        print("✅ Bot state reset - left squad")
        return True
        
    except Exception as e:
        print(f"❌ Error resetting bot: {e}")
        return False    

async def leave_squad(key, iv, region):
    """Leave squad - converted from your old TCP leave_s()"""
    fields = {
        1: 7,
        2: {
            1: int(bot_uid)  # Use dynamic bot_uid for leaving
        }
    }
    
    packet = (await CrEaTe_ProTo(fields)).hex()
    
    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"
        
    return await GeneRaTePk(packet, packet_type, key, iv) 

async def badge_spam_worker(mode, target_uid, base_badge, uid, chat_id, key, iv, region, chat_type):
    """
    mode: 'fixed' for /s1-/s5 -> badge fixed
          'mixed' for /sm     -> badge random each invite

    target_uid: target player UID (string or int)
    base_badge: BADGE_VALUES[cmd] for /s1-/s5, ignored for /sm if you want
    """
    global BADGE_SPAM_TASK, BADGE_SPAM_STOP

    try:
        target_uid = str(target_uid)
        badge_pool = list(BADGE_VALUES.values())  # for /sm random badges
        spam_count = 250  # how many invites; change if you want

        await reset_bot_state(key, iv, region)

        used_badges = []

        for i in range(spam_count):
            if BADGE_SPAM_STOP:
                if chat_type and uid:
                    stop_msg = "[B][C][FF0000]⛔ Badge spam stopped by /ssm\n"
                    await safe_send_message(chat_type, stop_msg, uid, chat_id, key, iv)
                break

            if mode == "fixed":
                badge_value = base_badge
            else:  # mode == "mixed" → /sm
                badge_value = random.choice(badge_pool)

            join_packet = await request_join_with_badge(
                target_uid,
                badge_value,
                key,
                iv,
                region
            )
            if join_packet:
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)
            
            used_badges.append(badge_value)

            # print(f"✅ badge_spam_worker #{i+1} → UID {target_uid}, badge {badge_value}")
            await asyncio.sleep(0.1)

        if not BADGE_SPAM_STOP and chat_type and uid:
            success_msg = (
                "[B][C][00FF00]✅ Request spam complete!\n"
                f"🎯 Target: {fix_num(target_uid)}\n"
            )
            await safe_send_message(chat_type, success_msg, uid, chat_id, key, iv)

        await asyncio.sleep(1)
        await reset_bot_state(key, iv, region)

    except asyncio.CancelledError:
        # Task was cancelled by /ss
        try:
            if chat_type and uid:
                cancel_msg = "[B][C][FF0000]⛔ Badge spam task cancelled by /ssm\n"
                await safe_send_message(chat_type, cancel_msg, uid, chat_id, key, iv)
        except:
            pass
    except Exception as e:
        if chat_type and uid:
            err_msg = f"[B][C][FF0000]❌ Error in badge spam: {str(e)}\n"
            await safe_send_message(chat_type, err_msg, uid, chat_id, key, iv)
    finally:
        BADGE_SPAM_TASK = None
        BADGE_SPAM_STOP = False


async def request_join_with_badge(target_uid, badge_value, key, iv, region):
    fields = {
        1: 33,
        2: {
            1: int(target_uid),
            2: region.upper(),
            3: 1,
            4: 1,
            5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
            6: "iG:[C][B][FF0000] KRISHNA",
            7: 330,
            8: 1000,
            10: region.upper(),
            11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
                       97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
            12: 1,
            13: int(target_uid),
            14: {
                1: 2203434355,
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            16: 1,
            17: 1,
            18: 312,
            19: 46,
            23: bytes([16, 1, 24, 1]),
            # 👇 random avatar each call
            24: int(get_random_avatar()),
            26: "",
            28: "",
            31: {
                1: 1,
                2: badge_value
            },
            32: badge_value,
            34: {
                1: int(target_uid),
                2: 8,
                3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        },
        10: "en",
        13: {
            2: 1,
            3: 1
        }
    }

    packet = (await CrEaTe_ProTo(fields)).hex()

    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"

    return await GeneRaTePk(packet, packet_type, key, iv)



async def handle_badge_command(cmd, inPuTMsG, uid, chat_id, key, iv, region, chat_type):
    """Handle /s1-/s5: fixed badge, random avatar every invite (stoppable with /ssm)"""
    global BADGE_SPAM_TASK, BADGE_SPAM_STOP

    parts = inPuTMsG.strip().split()
    if len(parts) < 2:
        error_msg = f"[B][C][FF0000]❌ Usage: /{cmd} (uid)\n"
        await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)
        return

    target_uid = parts[1]

    if not target_uid.isdigit():
        error_msg = "[B][C][FF0000]❌ Please write a valid player ID!\n"
        await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)
        return

    base_badge = BADGE_VALUES.get(cmd, 1048576)

    # If a badge spam task is already running, tell user
    if BADGE_SPAM_TASK and not BADGE_SPAM_TASK.done():
        msg = "[B][C][FF0000]⚠ Badge spam already running! Use /ssm to stop it.\n"
        await safe_send_message(chat_type, msg, uid, chat_id, key, iv)
        return

    start_msg = (
        f"[B][C][1E90FF]🌀 /{cmd} started!\n"
        f"Target: {fix_num(target_uid)}\n"
        # f"Badge: {base_badge} (fixed)\n"
        # "[FFFFFF]Random avatar for every invitation.\n"
        "[FFB300]Use /ss to stop.\n"
    )
    await safe_send_message(chat_type, start_msg, uid, chat_id, key, iv)

    BADGE_SPAM_STOP = False
    BADGE_SPAM_TASK = asyncio.create_task(
        badge_spam_worker(
            "fixed",           # mode
            target_uid,
            base_badge,
            uid,
            chat_id,
            key,
            iv,
            region,
            chat_type
        )
    )



        
async def create_authenticated_join(target_uid, account_uid, key, iv, region):
    """Create join request that appears to come from the specific account"""
    try:
        # Use the standard invite function but ensure it uses account context
        join_packet = await SEnd_InV(5, int(target_uid), key, iv, region)
        return join_packet
    except Exception as e:
        print(f"❌ Error creating join packet: {e}")
        return None        
    
async def create_account_join_packet(self, target_uid, account_uid, open_id, access_token, key, iv, region):
        """Create join request packet for specific account"""
        try:
            # This is where you use the account's actual UID instead of main bot UID
            fields = {
                1: 33,
                2: {
                    1: int(target_uid),  # Target UID
                    2: region.upper(),
                    3: 1,
                    4: 1,
                    5: bytes([1, 7, 9, 10, 11, 18, 25, 26, 32]),
                    6: f"BOT:[C][B][FF0000] ACCOUNT_{account_uid[-4:]}",  # Show account UID
                    7: 330,
                    8: 1000,
                    10: region.upper(),
                    11: bytes([49, 97, 99, 52, 98, 56, 48, 101, 99, 102, 48, 52, 55, 56,
                               97, 52, 52, 50, 48, 51, 98, 102, 56, 102, 97, 99, 54, 49, 50, 48, 102, 53]),
                    12: 1,
                    13: int(account_uid),  # Use the ACCOUNT'S UID here, not target UID!
                    14: {
                        1: 2203434355,
                        2: 8,
                        3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
                    },
                    16: 1,
                    17: 1,
                    18: 312,
                    19: 46,
                    23: bytes([16, 1, 24, 1]),
                    24: int(get_random_avatar()),
                    26: "",
                    28: "",
                    31: {
                        1: 1,
                        2: 32768  # V-Badge
                    },
                    32: 32768,
                    34: {
                        1: int(account_uid),  # Use the ACCOUNT'S UID here too!
                        2: 8,
                        3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
                    }
                },
                10: "en",
                13: {
                    2: 1,
                    3: 1
                }
            }
            
            packet = (await CrEaTe_ProTo(fields)).hex()
            
            if region.lower() == "ind":
                packet_type = '0514'
            elif region.lower() == "bd":
                packet_type = "0519"
            else:
                packet_type = "0515"
                
            return await GeneRaTePk(packet, packet_type, key, iv)
            
        except Exception as e:
            print(f"❌ Error creating join packet for {account_uid}: {e}")
            return None

async def handle_sm_command(inPuTMsG, uid, chat_id, key, iv, region, chat_type):
    """
    /sm:
    - random avatar + random badge per invitation
    - stoppable with /ss
    """
    global BADGE_SPAM_TASK, BADGE_SPAM_STOP

    parts = inPuTMsG.strip().split()
    if len(parts) < 2:
        error_msg = "[B][C][FF0000]❌ Usage: /sm (uid)\n"
        await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)
        return

    target_uid = parts[1]

    if not target_uid.isdigit():
        error_msg = "[B][C][FF0000]❌ Please write a valid player ID!\n"
        await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)
        return

    # If a badge spam task is already running, tell user
    if BADGE_SPAM_TASK and not BADGE_SPAM_TASK.done():
        msg = "[B][C][FF0000]⚠ Badge spam already running! Use /ssm to stop it.\n"
        await safe_send_message(chat_type, msg, uid, chat_id, key, iv)
        return

    start_msg = (
        "[B][C][1E90FF]🌀 /sm started!\n"
        f"Target: {fix_num(target_uid)}\n"
        # "[FFFFFF]Random avatar + random badge for every invitation.\n"
        "[FFB300]Use /ssm to stop.\n"
    )
    await safe_send_message(chat_type, start_msg, uid, chat_id, key, iv)

    BADGE_SPAM_STOP = False
    # base_badge can be 0 or any default; worker will ignore it for 'mixed' mode
    BADGE_SPAM_TASK = asyncio.create_task(
        badge_spam_worker(
            "mixed",           # mode = random badges
            target_uid,
            0,                 # base_badge unused in 'mixed' mode
            uid,
            chat_id,
            key,
            iv,
            region,
            chat_type
        )
    )



async def run_max_evos(
    target_ids,
    uid,
    chat_id,
    key,
    iv,
    region,
    whisper_writer,
    online_writer,
    chat_type
):
    global SMAX_STOP, MAX_TASK

    # Mapping of EVOS choices to emote IDs
    evo_emotes = {
        "1": "909000063",   # AK
        "2": "909000068",   # SCAR
        "3": "909000075",   # 1st MP40
        "4": "909000081",   # 1st M1014
        "5": "909000085",   # XM8
        "6": "909000098",   # UMP
        "7": "909000090",   # Famas
        "8": "909033002",   # Mp5
        "9": "909035007",   # M1887
        "10": "909033001",  # M4A1
        "11": "909037011",  # FIST
        "12": "909035012",  # AN94
        "13": "909038010",  # Thompson
        "14": "909039011",  # 2nd M1014
        "15": "909040010",  # 2nd MP40
        "16": "909041005",  # Groza
        "17": "909042008",  # Woodpecker
        "18": "909045001",  # Parafal
        "19": "909049010",  # P90
        "20": "909038012",  # G18
        "21": "909051003"   # M60
    }

    emote_keys = list(range(1, 22))

    intro_msg = "[C][B][1E90FF]max processing!\n"
    await safe_send_message(chat_type, intro_msg, uid, chat_id, key, iv)

    try:
        for key_num in emote_keys:

            # check stop flag
            if SMAX_STOP:
                break_msg = "[C][B][FF0000]EVOS processing stopped by /smax\n"
                await safe_send_message(chat_type, break_msg, uid, chat_id, key, iv)
                break

            emote_key = str(key_num)
            emote_id = evo_emotes.get(emote_key)
            if not emote_id:
                continue

            for target in target_ids:
                if SMAX_STOP:
                    break
                try:
                    emote_packet = await Emote_k(
                        int(target),
                        int(emote_id),
                        key,
                        iv,
                        region
                    )
                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', emote_packet)
                except Exception as e:
                    print(f"Error sending EVOS emote: {e}")

            # spacing between emotes
            await asyncio.sleep(0.08)
            await asyncio.sleep(5)

        if not SMAX_STOP:
            done_msg = "[C][B][00FF00]EVOS emotes complete!\n"
            await safe_send_message(chat_type, done_msg, uid, chat_id, key, iv)

    except Exception as e:
        err_msg = "[C][B][FF0000]Error in /max command\n"
        await safe_send_message(chat_type, err_msg, uid, chat_id, key, iv)
        print("Error in run_max_evos:", e)

    finally:
        # reset state
        MAX_TASK = None
        SMAX_STOP = False


# NEW FUNCTION: /r command implementation - FASTER VERSION
async def r_command_operation(team_code, target_uid, emote_id, key, iv, region):
    """Execute /r command: join team, send emote, then leave - FAST VERSION"""
    try:
        # Step 1: Join the team
        join_packet = await GenJoinSquadsPacket(team_code, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)
        await asyncio.sleep(1)  # Reduced wait time for join to complete
        
        # Step 2: Send emote to target UID (using direct emote ID)
        uid_int = int(target_uid)
        emote_packet = await Emote_k(uid_int, int(emote_id), key, iv, region)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', emote_packet)
        await asyncio.sleep(0.5)  # Reduced wait time for emote to be sent
        
        # Step 3: Leave the team (solo)
        leave_packet = await ExiT(None, key, iv)
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_packet)
        await asyncio.sleep(1)  # Reduced wait time for leave to complete
        
        return True, f"Success! Joined team {team_code}, sent emote ID {emote_id} to {target_uid}, and left team."
    
    except Exception as e:
        return False, f"Error in /r command: {str(e)}"

# Helper functions for ghost join
def dec_to_hex(decimal):
    """Convert decimal to hex string"""
    hex_str = hex(decimal)[2:]
    return hex_str.upper() if len(hex_str) % 2 == 0 else '0' + hex_str.upper()

async def encrypt_packet(packet_hex, key, iv):
    """Encrypt packet using AES CBC"""
    cipher = AES.new(key, AES.MODE_CBC, iv)
    packet_bytes = bytes.fromhex(packet_hex)
    padded_packet = pad(packet_bytes, AES.block_size)
    encrypted = cipher.encrypt(padded_packet)
    return encrypted.hex()

async def nmnmmmmn(packet_hex, key, iv):
    """Wrapper for encrypt_packet"""
    return await encrypt_packet(packet_hex, key, iv)

# Status response cache for /room command
status_response_cache = {}

# Cache file for persistent storage
CACHE_FILE = 'status_cache.pkl'
CACHE_TIMEOUT = 30  # Cache entries expire after 30 seconds

def save_to_cache(player_id, data):
    """Save status to file cache with timestamp"""
    try:
        # Load existing cache
        if os.path.exists(CACHE_FILE):
            try:
                with open(CACHE_FILE, 'rb') as f:
                    cache = pickle.load(f)
            except:
                cache = {}
        else:
            cache = {}
        
        # Add timestamp
        data['saved_at'] = time.time()
        
        # Update cache
        cache[str(player_id)] = data
        
        # Save back
        with open(CACHE_FILE, 'wb') as f:
            pickle.dump(cache, f)
        
        print(f"💾 Saved to file cache: {player_id}")
        return True
    except Exception as e:
        print(f"❌ Cache save error: {e}")
        return False

def load_from_cache(player_id):
    """Load status from file cache, check expiration"""
    try:
        if not os.path.exists(CACHE_FILE):
            return None
        
        with open(CACHE_FILE, 'rb') as f:
            cache = pickle.load(f)
        
        player_key = str(player_id)
        if player_key in cache:
            data = cache[player_key]
            
            # Check if cache is expired
            if 'saved_at' in data:
                if time.time() - data['saved_at'] > CACHE_TIMEOUT:
                    print(f"⏰ Cache expired for {player_id}")
                    del cache[player_key]
                    with open(CACHE_FILE, 'wb') as f:
                        pickle.dump(cache, f)
                    return None
            
            print(f"📥 Loaded from cache: {player_id}")
            return data
        
        return None
    except Exception as e:
        print(f"❌ Cache load error: {e}")
        return None

def Encrypt(number):
    """Encrypt function from first TCP bot"""
    number = int(number)
    encoded_bytes = []
    
    while True:
        byte = number & 0x7F
        number >>= 7
        if number:
            byte |= 0x80
        encoded_bytes.append(byte)
        if not number:
            break
    
    return bytes(encoded_bytes).hex()

async def check_player_status(target_uid, key, iv, max_wait=3):
    """Direct function to check player status with proper waiting"""
    try:
        # Clear old cache
        if target_uid in status_response_cache:
            del status_response_cache[target_uid]
        
        # Send request
        status_packet = await createpacketinfo(target_uid, key, iv)
        if not status_packet:
            return None, "Failed to create packet"
        
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', status_packet)
        print(f"📤 Sent status request for {target_uid}")
        
        # Wait for response with polling
        start_time = time.time()
        while time.time() - start_time < max_wait:
            if target_uid in status_response_cache:
                cache_data = status_response_cache[target_uid]
                return cache_data, "Success"
            
            await asyncio.sleep(0.1)  # Short sleep
        
        return None, f"No response after {max_wait} seconds"
        
    except Exception as e:
        return None, f"Error: {str(e)}"

async def createpacketinfo(idddd, key, iv):
    """Create player status request packet - SAME as first TCP bot"""
    try:
        ida = Encrypt(idddd)
        packet = f"080112090A05{ida}1005"
        header_lenth = len(await encrypt_packet(packet, key, iv)) // 2
        header_lenth_final = dec_to_hex(header_lenth)
        
        if len(header_lenth_final) == 2:
            final_packet = "0F15000000" + header_lenth_final + await nmnmmmmn(packet, key, iv)
        elif len(header_lenth_final) == 3:
            final_packet = "0F1500000" + header_lenth_final + await nmnmmmmn(packet, key, iv)
        elif len(header_lenth_final) == 4:
            final_packet = "0F150000" + header_lenth_final + await nmnmmmmn(packet, key, iv)
        elif len(header_lenth_final) == 5:
            final_packet = "0F15000" + header_lenth_final + await nmnmmmmn(packet, key, iv)
        else:
            final_packet = "0F1500000" + header_lenth_final + await nmnmmmmn(packet, key, iv)
            
        return bytes.fromhex(final_packet)
        
    except Exception as e:
        print(f"Error creating packet info: {e}")
        return None

def clear_cache_entry(player_id):
    """Clear specific cache entry"""
    try:
        if os.path.exists(CACHE_FILE):
            with open(CACHE_FILE, 'rb') as f:
                cache = pickle.load(f)
            
            player_key = str(player_id)
            if player_key in cache:
                del cache[player_key]
                with open(CACHE_FILE, 'wb') as f:
                    pickle.dump(cache, f)
                print(f"🗑️ Cleared cache for {player_id}")
            else:
                # Try saving anyway if modified? No, logic is fine.
                pass
    except Exception as e:
        print(f"❌ Clear cache error: {e}")

def debug_file_cache():
    """Debug the file cache"""
    try:
        if os.path.exists(CACHE_FILE):
            with open(CACHE_FILE, 'rb') as f:
                cache = pickle.load(f)
            print(f"\n📁 FILE CACHE DEBUG:")
            print(f"Size: {len(cache)} entries")
            for uid, data in cache.items():
                age = time.time() - data.get('saved_at', 0)
                status = data.get('status', 'NO STATUS')
                print(f"  {uid}: {status} (age: {age:.1f}s)")
            print("---\n")
            return cache
        else:
            print("📁 No cache file exists")
            return {}
    except Exception as e:
        print(f"❌ Cache debug error: {e}")
        return {}

async def handle_status_response(hex_data):
    """Process status response packets (0f00/0f15) for /room command"""
    try:
        # Received packet usually starts with 0f00 for status response
        if not hex_data.startswith('0f00') and not hex_data.startswith('0f15'):
            # Case insensitive check just in case
            if not hex_data.startswith('0F00') and not hex_data.startswith('0F15'):
                return
        
        # print(f"✨ Processing status packet header: {hex_data[:8]}")
        
        if '08' in hex_data:
             proto_part = f'08{hex_data.split("08", 1)[1]}'
        else:
             print(f"⚠️ Status packet structure missing '08' marker. Hex: {hex_data[:20]}...")
             return

        # Decrypt and parse the packet
        try:
            decrypted_hex = await DeCode_PackEt(proto_part)
        except Exception as e:
            print(f"❌ DeCode_PackEt Error: {e}")
            return
            
        if not decrypted_hex:
            print("❌ Failed to decrypt status packet (result empty)")
            return
            
        try:
            parsed_data = json.loads(decrypted_hex)
        except json.JSONDecodeError as e:
            print(f"❌ JSON Parse Error: {e} | Decrypted: {decrypted_hex[:50]}...")
            return
        
        # Try strict path first (matched with ff/main.py)
        # Path: 5 -> 1 -> 1
        found_id = None
        
        try:
            if '5' in parsed_data and 'data' in parsed_data['5']:
                p5 = parsed_data['5']['data']
                if '1' in p5 and 'data' in p5['1']:
                    p1 = p5['1']['data']
                    if '1' in p1 and 'data' in p1['1']:
                        found_id = str(p1['1']['data'])
        except Exception:
            pass
            
        # Fallback: Search recursively for UID if strict path failed
        if not found_id:
            print("⚠️ Strict path failed, searching for UID...")
            def find_uid(obj):
                if isinstance(obj, dict):
                    for k, v in obj.items():
                        if k == 'data' and isinstance(v, (int, str)):
                            s_v = str(v)
                            # Basic UID validation: 7-12 digits
                            if s_v.isdigit() and 7 <= len(s_v) <= 12:
                                return s_v
                        res = find_uid(v)
                        if res: return res
                elif isinstance(obj, list):
                    for item in obj:
                        res = find_uid(item)
                        if res: return res
                return None
            
            found_id = find_uid(parsed_data)
            
        if not found_id:
            print(f"❌ Could not extract Player ID from packet: {list(parsed_data.keys())}")
            return
            
        player_id = found_id
        print(f"🕵️ Extracted Player ID: {player_id}")
        
        # Get player status
        player_status = get_player_status(proto_part)
        print(f"📊 Extracted Status: {player_status}")
        
        # Create cache entry with packet and status
        cache_entry = {
            'packet': proto_part,
            'status': player_status,
            'saved_at': time.time(),
            'parsed_json': parsed_data # Store parsed json for /status squad info
        }
        
        # Extract additional info based on status
        if "IN ROOM" in player_status:
            try:
                room_id = get_idroom_by_idplayer(proto_part)
                if room_id:
                    cache_entry['room_id'] = room_id
                    print(f"🏠 Room ID extracted: {room_id}")
            except Exception as e:
                print(f"Failed to extract room ID: {e}")
                
        elif "INSQUAD" in player_status:
            try:
                leader_id = get_leader(proto_part)
                if leader_id:
                    cache_entry['leader_id'] = leader_id
                    print(f"👑 Leader ID: {leader_id}")
            except Exception as e:
                print(f"Failed to extract leader: {e}")

        # Store in both caches
        status_response_cache[player_id] = cache_entry
        save_to_cache(player_id, cache_entry)
        
        print(f"📥 Cached status for {player_id}: {player_status}")
        
    except Exception as e:
        print(f"❌ handle_status_response error: {e}")
        pass

def get_leader(packet):
    """Extract leader ID from squad packet"""
    try:
        json_result = get_available_room(packet)
        parsed_data = json.loads(json_result)
        json_data = parsed_data["5"]["data"]
        data = json_data["1"]["data"]
        leader = data['8']["data"]
        return leader
    except Exception as e:
        print(f"Error extracting leader: {e}")
        return None

async def ghost_join_packet(player_id, secret_code, key, iv):
    """Create ghost join packet"""
    try:
        # Create a simple packet structure for joining
        # This is a basic implementation - adjust based on your needs
        packet_data = f"01{dec_to_hex(len(secret_code))}{secret_code.encode().hex()}"
        
        # Encrypt the packet
        encrypted_packet = await encrypt_packet(packet_data, key, iv)
        
        # Create header
        header_length = len(encrypted_packet) // 2
        header_length_hex = dec_to_hex(header_length)
        
        # Build final packet based on header length
        if len(header_length_hex) == 2:
            final_packet = "0515000000" + header_length_hex + encrypted_packet
        elif len(header_length_hex) == 3:
            final_packet = "051500000" + header_length_hex + encrypted_packet
        elif len(header_length_hex) == 4:
            final_packet = "05150000" + header_length_hex + encrypted_packet
        elif len(header_length_hex) == 5:
            final_packet = "0515000" + header_length_hex + encrypted_packet
        else:
            final_packet = "0515000000" + header_length_hex + encrypted_packet
            
        return bytes.fromhex(final_packet)
        
    except Exception as e:
        print(f"Error creating ghost join packet: {e}")
        return None

async def lag_team_loop(team_code, key, iv, region, max_cycles=1500):
    """Rapid join/leave loop to create lag (auto-stop after max_cycles)"""
    global lag_running
    count = 0
    
    # Stagger start to prevent IP rate limits
    await asyncio.sleep(random.uniform(0.1, 0.8))
    
    while lag_running and count < max_cycles:
        try:
            # Join the team
            join_packet = await GenJoinSquadsPacket(team_code, key, iv)
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)
            
            # Wait for server to process join
            await asyncio.sleep(0.1) 
            
            # Leave the team
            leave_packet = await ExiT(None, key, iv)
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_packet)
            
            count += 1
            if count % 10 == 0:
                 print(f"Lag cycle #{count} completed for team: {team_code}")
            
            # Short delay between cycles
            await asyncio.sleep(0.05) 
            
        except Exception as e:
            print(f"Error in lag loop: {e}")
            await asyncio.sleep(0.05)
    
    # auto-stop
    lag_running = False
    print(f"Lag loop stopped automatically after {count} cycles for team: {team_code}")


async def general_emote_spam(uids, emote_number, key, iv, region):
    """Send general emotes based on number mapping from JSON file"""
    try:
        emote_id = GENERAL_EMOTES_MAP.get(str(emote_number))
        if not emote_id:
            return False, f"Invalid emote number! Use numbers from 1-{len(GENERAL_EMOTES_MAP)}"
        
        success_count = 0
        for uid in uids:
            try:
                uid_int = int(uid)
                H = await Emote_k(uid_int, emote_id, key, iv, region)
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
                success_count += 1
                await asyncio.sleep(0.1)
            except Exception as e:
                print(f"Error sending general emote to {uid}: {e}")
        
        return True, f"Sent emote {emote_number} (ID: {emote_id}) to {success_count} player(s)"
    
    except Exception as e:
        return False, f"Error in general_emote_spam: {str(e)}"


# Helper for single-shot emote spam
async def fast_emote_spam(uids, emote_num, key, iv, region):
     # Send 5 times to be sure
     for _ in range(5):
          await general_emote_spam(uids, emote_num, key, iv, region)
          await asyncio.sleep(0.1)

# NEW FUNCTION: Random evolution emote spam to command sender - 5 SECONDS DELAY
async def rnd_worker(uids, uid, chat_id, key, iv, region, chat_type):
    global RND_TASK
    try:
        success, result_msg = await dance_group_emotes(uids, key, iv, region)



        if success:
            success_msg = " [C][00FF00]✅SUCCESS!\n"
            await safe_send_message(chat_type, success_msg, uid, chat_id, key, iv)
        else:
            error_msg = " [C][FF0000]❌ ERROR!\n"
            await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)

    except asyncio.CancelledError:
        # Stopped by /srnd
        stop_msg = " [C][FF0000]⛔ Dance stopped by /srnd\n"
        await safe_send_message(chat_type, stop_msg, uid, chat_id, key, iv)
        # re-raise if you want, or just return
    except Exception as e:
        err_msg = f" [C][FF0000]❌ ERROR in /rnd: {e}\n"
        await safe_send_message(chat_type, err_msg, uid, chat_id, key, iv)
    finally:
        RND_TASK = None



# UPDATED FUNCTION: Dance - ALL 21 emotes to specified UIDs - 2.5 SECONDS DELAY
async def dance_group_emotes(uids, key, iv, region):
    """Send ALL 21 evolution emotes to specified UIDs - 2.5 SECONDS DELAY"""
    try:
        # Get all evolution emote IDs (1-21)
        emote_ids = list(EMOTE_MAP.values())
        
        # Shuffle the emotes for random order
        random.shuffle(emote_ids)
        
        success_count = 0
        total_emotes = len(emote_ids)
        total_time = total_emotes * 5.5  # Calculate total time
        
        print(f"Dance: Sending to {len(uids)} players: {uids}")
        
        for emote_id in emote_ids:
            try:
                # Send to EACH specified UID individually
                emote_sent_count = 0
                for member_uid in uids:
                    try:
                        uid_int = int(member_uid)
                        H = await Emote_k(uid_int, emote_id, key, iv, region)
                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
                        emote_sent_count += 1
                        print(f"Dance: Sent emote to UID {member_uid}")
                    except Exception as e:
                        print(f"Error sending to UID {member_uid}: {e}")
                
                success_count += 1
                
                # Get emote number from ID for display
                emote_number = [k for k, v in EMOTE_MAP.items() if v == emote_id][0]
                print(f"Dance: Sent evolution emote {emote_number} (ID: {emote_id}) to {emote_sent_count} players - {success_count}/{total_emotes}")
                
                await asyncio.sleep(5.5)  # 5 seconds delay between emotes
            except Exception as e:
                print(f"Error sending dance emote {emote_id} to group: {e}")
        
        return True, f"🎉 Ultimate dance party! Sent ALL {success_count} evolution emotes (1-21) to {len(uids)} players! (2.5s delay)"
    
    except Exception as e:
        return False, f"Error in dance_group_emotes: {str(e)}"


async def GeneRaTePk(Pk, N, K, V):
    # Ported from ff/xC4.py utilizing main.py's helpers
    PkEnc = await encrypt_packet(Pk, K, V)
    _ = await DecodE_HeX(int(len(PkEnc) // 2))
    if len(_) == 2: HeadEr = N + "000000"
    elif len(_) == 3: HeadEr = N + "00000"
    elif len(_) == 4: HeadEr = N + "0000"
    elif len(_) == 5: HeadEr = N + "000"
    else: 
        print('ErroR => GeneRatinG ThE PacKeT !! ')
        return None
    return bytes.fromhex(HeadEr + _ + PkEnc)

async def Room_Spam(Uid, Rm, Nm, K, V):
   
    same_value = random.choice([32768])  #you can add any badge value 
    
    fields = {
        1: 78,
        2: {
            1: int(Rm),  
            2: "iG:[C][B][FF0000] ROSHAN X KALLU CODEX",  
            3: {
                2: 1,
                3: 1
            },
            4: 330,      
            5: 6000,     
            6: 201,      
            10: int(get_random_avatar()),  
            11: int(Uid), # Target UID
            12: 1,       
            15: {
                1: 1,
                2: same_value  
            },
            16: same_value,    
            18: {
                1: 11481904755,  
                2: 8,
                3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"
            },
            
            31: {
                1: 1,
                2: same_value  
            },
            32: same_value,    
            34: {
                1: int(Uid),   
                2: 8,
                3: bytes([15,6,21,8,10,11,19,12,17,4,14,20,7,2,1,5,16,3,13,18])
            }
        }
    }
    
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0e15', K, V)


# Global flag for room spam
room_spam_active = False

async def room_spam_worker(target_uid, room_id, key, iv, writer, chat_type, uid, chat_id):
    """Background worker for room spam"""
    global room_spam_active
    room_spam_active = True
    
    spam_count = 250
    sent_count = 0
    
    try:
        for i in range(spam_count):
            if not room_spam_active:
                if chat_type is not None and uid is not None:
                     await safe_send_message(chat_type, "[B][C][FF0000]🛑 Room Spam Stopped!", uid, chat_id, key, iv)
                return

            try:
                spam_packet = await Room_Spam(target_uid, room_id, f"Spam_{i+1}", key, iv)
                # Check writer explicitly
                if spam_packet and writer:
                    await SEndPacKeT(writer, online_writer, 'OnLine', spam_packet)
                    sent_count += 1
                    await asyncio.sleep(0.2)
            except Exception as e:
                print(f"Worker spam error: {e}")
                
        # Finished
        if chat_type is not None and uid is not None:
            spam_msg = f"[B][C][FF0000]✅ Room Spam Finished ({sent_count} sent)!\n"
            await safe_send_message(chat_type, spam_msg, uid, chat_id, key, iv)
        
    except Exception as e:
        print(f"Worker error: {e}")
    finally:
        room_spam_active = False

# ================= NEW FEATURES: Sticker, Title, Noob =================

async def xBunnEr():
    """Get random avatar ID"""
    bN = [902048021]
    return random.choice(bN)

def get_random_sticker():
    """Randomly select one sticker from available packs"""
    sticker_packs = [
        ("1200000001", 1, 24), # NORMAL STICKERS
        ("1200000002", 1, 15), # KELLY EMOJIS
        ("1200000004", 1, 13), # MAD CHICKEN
    ]
    pack_id, start, end = random.choice(sticker_packs)
    sticker_no = random.randint(start, end)
    return f"[1={pack_id}-{sticker_no}]"

async def send_sticker(target_uid, chat_id, key, iv, nickname="[b]JUBAYER"):
    """Send Random Sticker using /sticker command"""
    try:
        sticker_value = get_random_sticker()

        fields = {
            1: 1,
            2: {
                1: int(target_uid),
                2: int(chat_id),
                5: int(datetime.now().timestamp()),
                8: f'{{"StickerStr" : "{sticker_value}", "type":"Sticker"}}',
                9: {
                    1: f"[C][B][FF0000]{nickname}",
                    2: int(await xBunnEr()),
                    4: 330,
                    5: 102000015,
                    8: "BOT TEAM",
                    10: 1,
                    11: 66,
                    12: 66,
                    13: {1: 2},
                    14: {
                        1: 1158053040,
                        2: 8,
                        3: b"\x10\x15\x08\x0a\x0b\x15\x0c\x0f\x11\x04\x07\x02\x03\x0d\x0e\x12\x01\x05\x06"
                    }
                },
                10: "en",
                13: {
                    2: 2,
                    3: 1
                },
                14: {}
            }
        }

        proto_bytes = await CrEaTe_ProTo(fields)
        packet_hex = proto_bytes.hex()

        encrypted_packet = await encrypt_packet(packet_hex, key, iv)
        packet_length = len(encrypted_packet) // 2
        hex_length = f"{packet_length:04x}"

        zeros_needed = 6 - len(hex_length)
        packet_prefix = "121500" + ("0" * zeros_needed)

        final_packet_hex = packet_prefix + hex_length + encrypted_packet
        final_packet = bytes.fromhex(final_packet_hex)

        return final_packet

    except Exception as e:
        print(f"Sticker error: {e}")
        return None

async def noob(target_uid, chat_id, key, iv, nickname="—͞JUBAYERᅠ", title_id=None):
    """EXACT conversion with customizable title ID"""
    try:
        # Use provided title_id or get random one
        if title_id is None:
            # Get a random title from the list
            available_titles = [904090014, 904090015, 904090024, 904090025, 904090026, 904090027, 904990070, 904990071, 904990072]
            title_id = random.choice(available_titles)
        
        # Create fields dictionary with specific title_id
        fields = {
            1: 1,
            2: {
                1: int(target_uid),
                2: int(chat_id),
                5: int(datetime.now().timestamp()),
                8: f'{{"TitleID":{title_id},"type":"Title"}}',
                9: {
                    1: f"[C][B][FF0000]{nickname}",
                    2: int(await xBunnEr()),
                    4: 330,
                    5: 102000015,
                    8: "BOT TEAM",
                    10: 1,
                    11: 1,
                    13: {
                        1: 2
                    },
                    14: {
                        1: 1158053040,
                        2: 8,
                        3: b"\x10\x15\x08\x0a\x0b\x15\x0c\x0f\x11\x04\x07\x02\x03\x0d\x0e\x12\x01\x05\x06"
                    }
                },
                10: "en",
                13: {
                    2: 2,
                    3: 1
                },
                14: {}
            }
        }
        
        proto_bytes = await CrEaTe_ProTo(fields)
        packet_hex = proto_bytes.hex()
        
        encrypted_packet = await encrypt_packet(packet_hex, key, iv)
        packet_length = len(encrypted_packet) // 2
        hex_length = f"{packet_length:04x}"
        
        zeros_needed = 6 - len(hex_length)
        packet_prefix = "121500" + ("0" * zeros_needed)
        
        final_packet_hex = packet_prefix + hex_length + encrypted_packet
        final_packet = bytes.fromhex(final_packet_hex)
        
        print(f"✅ Created packet with Title ID: {title_id}")
        return final_packet
        
    except Exception as e:
        print(f"❌ Conversion error: {e}")
        return None

async def send_all_titles_sequentially(uid, chat_id, key, iv, region, chat_type, writer):
    """Send all titles one by one with 2-second delay"""
    
    # Get all titles
    all_titles = [
        905090075, 904990072, 904990069, 905190079
    ]
    
    total_titles = len(all_titles)
    
    # Send initial message
#     start_msg = f"""[B][C][00FF00]🎖️ STARTING TITLE SEQUENCE!
    
# 📊 Total Titles: {total_titles}
# ⏱️ Delay: 2 seconds between titles
# 🔁 Mode: Sequential
# 🎯 Target: {uid}

# ⏳ Sending titles now...
# """
#     await safe_send_message(chat_type, start_msg, uid, chat_id, key, iv)
    
    try:
        for index, title_id in enumerate(all_titles):
            title_number = index + 1
            
            # Create progress message
#             progress_msg = f"""[B][C][FFFF00]📤 SENDING TITLE {title_number}/{total_titles}

# 🎖️ Title ID: {title_id}
# """
#             await safe_send_message(chat_type, progress_msg, uid, chat_id, key, iv)
            
            # Send title packet
            packet = await noob(uid, chat_id, key, iv, nickname="System", title_id=title_id)
            if packet and writer:
                writer.write(packet)
                await writer.drain()
            
            # Wait 2 seconds
            if title_number < total_titles:
                await asyncio.sleep(2)
                
        # Completion message
        # await safe_send_message(chat_type, "[B][C][00FF00]✅ Titles Sent Successfully!", uid, chat_id, key, iv)

    except Exception as e:
        print(f"Sequential title error: {e}")

async def send_noob_titles_sequentially(uid, chat_id, key, iv, region, chat_type, writer):
    """Send all titles one by one with 2-second delay"""
    
    # Get all titles
    all_titles = [
        904090014, 904090015, 904090024, 904090025, 904090026, 904090027, 904990070, 904990071, 904990072
    ]
    
    total_titles = len(all_titles)
    
    # Send initial message
    start_msg = f"""[B][C][00FF00]ya meku agar tu noob bolra tohtu bot hai


"""
    await safe_send_message(chat_type, start_msg, uid, chat_id, key, iv)
    
    try:
        for index, title_id in enumerate(all_titles):
            title_number = index + 1
            
            # Send title packet
            title_packet = await noob(uid, chat_id, key, iv, nickname="tom", title_id=title_id)
            
            if title_packet and writer:
                writer.write(title_packet)
                await writer.drain()
                print(f"✅ Sent title {title_number}/{total_titles}: {title_id}")
            
            # Wait 2 seconds
            if title_number < total_titles:
                await asyncio.sleep(2)
        
        # Completion message
        completion_msg = f"""[B][C][00FF00]Noobde ab tu bta ye titles aur bol kon noob hai
"""
        await safe_send_message(chat_type, completion_msg, uid, chat_id, key, iv)
        
    except Exception as e:
        print(f"Noob sequence error: {e}")

async def handle_all_titles_command(inPuTMsG, uid, chat_id, key, iv, region, chat_type, writer):
    """Handle /title command"""
    parts = inPuTMsG.strip().split()
    
    if len(parts) == 1:
        target_uid = uid
        target_name = "Yourself"
    elif len(parts) == 2 and parts[1].isdigit():
        target_uid = parts[1]
        target_name = f"UID {target_uid}"
    else:
        error_msg = f"""[B][C][FF0000]❌ Usage: /title [uid]
        
📝 Examples:
/title - Send all titles to yourself
/title 123456789 - Send all titles to specific UID

🎯 What it does:
1. Sends all 4 titles one by one
2. 2-second delay between each title
3. Sends in background (non-blocking)
4. Shows progress updates
"""
        await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)
        return

    # Start the title sequence in the background
    asyncio.create_task(
        send_all_titles_sequentially(target_uid, chat_id, key, iv, region, chat_type, writer)
    )
    
    # Immediate response
#     response_msg = f"""[B][C][00FF00]🚀 STARTING TITLE SEQUENCE IN BACKGROUND!

# 👤 Target: {target_name}
# 🎖️ Total Titles: 4
# ⏱️ Delay: 2 seconds each
# 📱 Status: Running in background...

# 💡 You'll receive progress updates as titles are sent!
# """
#     await safe_send_message(chat_type, response_msg, uid, chat_id, key, iv)

async def handle_alll_titles_command(inPuTMsG, uid, chat_id, key, iv, region, chat_type, writer):
    """Handle noob command"""
    parts = inPuTMsG.strip().split()
    
    if len(parts) == 1:
        target_uid = uid
        target_name = "Yourself"
    elif len(parts) == 2 and parts[1].isdigit():
        target_uid = parts[1]
        target_name = f"UID {target_uid}"
    else:
        # Implicitly handled or show usage? ff/main.py showed usage
        error_msg = f"""[B][C][FF0000]❌ Usage: noob [uid]
        
📝 Examples:
noob - Send all titles to yourself
noob 123456789 - Send all titles to specific UID

🎯 What it does:
1. Sends all titles one by one
2. 2-second delay between each title
3. Sends in background (non-blocking)
4. Shows progress updates
"""
        # await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)
        # return
        pass # Only if requested, maybe user types "noob something"? 
        # Actually ff/main.py logic:
        # if len(parts) == 1 ... elif ... else ... await safe_send_message(error_msg) return
        # So I should include it.
        await safe_send_message(chat_type, error_msg, uid, chat_id, key, iv)
        return

    asyncio.create_task(
        send_noob_titles_sequentially(target_uid, chat_id, key, iv, region, chat_type, writer)
    )


####################################
async def reject_spam_loop(target_uid, key, iv, region):
    """Send reject spam packets to target in background"""
    global reject_spam_running
    
    count = 0
    max_spam = 150
    
    while reject_spam_running and count < max_spam:
        try:
            # Send both packets
            packet1 = await banecipher1(target_uid, key, iv, region)
            packet2 = await banecipher(target_uid, key, iv, region)
            
            # Send to Online connection
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', packet1)
            await asyncio.sleep(0.1)
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', packet2)
            
            count += 1
            print(f"Sent reject spam #{count} to {target_uid}")
            
            # 0.2 second delay between spam cycles
            await asyncio.sleep(0.2)
            
        except Exception as e:
            print(f"Error in reject spam: {e}")
            break
    
    return count    

# Track active auto-reject tasks to prevent overlap
ACTIVE_AUTO_REJECT_TASKS = set()

async def reject_spam_auto(target_uid, key, iv, region):
    """
    Send reject spam packets to BANNED target in background.
    Does not rely on global reject_spam_running flag.
    Runs for separate lifecycle.
    """
    if str(target_uid) in ACTIVE_AUTO_REJECT_TASKS:
        return
        
    ACTIVE_AUTO_REJECT_TASKS.add(str(target_uid))
    print(f"[B][C][FF0000]⛔ BANNED USER INVITE DETECTED: {target_uid}")
    print(f"[B][C][1E90FF]🌀 Executing NEW Banned Rejection Function...")
    
    count = 0
    max_spam = 150
    
    try:
        while count < max_spam:
            # Send both packets
            packet1 = await banecipher1(target_uid, key, iv, region)
            packet2 = await banned_uid_message(target_uid, key, iv, region)
            
            # Send to Online connection
            if online_writer:
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', packet1)
                await asyncio.sleep(0.1)
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', packet2)
            else:
                break
            
            count += 1
            if count % 20 == 0:
                print(f"Auto-reject {target_uid}: {count}/{max_spam}")
            
            # 0.2 second delay between spam cycles
            await asyncio.sleep(0.2)
            
    finally:
        ACTIVE_AUTO_REJECT_TASKS.discard(str(target_uid))
        print(f"Auto-reject spam finished for {target_uid}")

async def reject_spam_muted(target_uid, key, iv, region):
    """
    Send MUTED reject spam packets to target in background.
    Run when bot is muted and non-admin invites.
    """
    if str(target_uid) in ACTIVE_AUTO_REJECT_TASKS:
        return
        
    ACTIVE_AUTO_REJECT_TASKS.add(str(target_uid))
    print(f"[B][C][FF0000]🔇 MUTED BOT INVITE DETECTED: {target_uid}")
    print(f"[B][C][1E90FF]🌀 Executing MUTED Rejection Function...")
    
    count = 0
    max_spam = 150
    
    try:
        while count < max_spam:
            # Send both packets
            packet1 = await banecipher1(target_uid, key, iv, region)
            packet2 = await muted_message(target_uid, key, iv, region)
            
            # Send to Online connection
            if online_writer:
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', packet1)
                await asyncio.sleep(0.1)
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', packet2)
            else:
                break
            
            count += 1
            if count % 20 == 0:
                print(f"Muted-reject {target_uid}: {count}/{max_spam}")
            
            # 0.2 second delay between spam cycles
            await asyncio.sleep(0.2)
            
    except Exception as e:
        print(f"Error in muted-reject spam: {e}")
    finally:
        ACTIVE_AUTO_REJECT_TASKS.discard(str(target_uid))
        print(f"Muted-reject spam finished for {target_uid}")
    
async def handle_reject_completion(spam_task, target_uid, sender_uid, chat_id, chat_type, key, iv):
    """Handle completion of reject spam and send final message"""
    try:
        spam_count = await spam_task
        
        # Send completion message
        if spam_count >= 150:
            completion_msg = f"[B][C][00FF00]✅ Reject Spam Completed Successfully"
        else:
            completion_msg = f"[B][C][FFFF00]⚠️ Reject Spam Partially Completed"
        
        await safe_send_message(chat_type, completion_msg, sender_uid, chat_id, key, iv)
        
    except asyncio.CancelledError:
        print("Reject spam was cancelled")
    except Exception as e:
        error_msg = f"[B][C][FF0000]❌ ERROR in reject spam: {str(e)}\n"
        await safe_send_message(chat_type, error_msg, sender_uid, chat_id, key, iv)
    finally:
        # ALWAYS remove the UID from block list when task finishes (for any reason)
        try:
            if str(target_uid) in REJECT_BLOCKED_UIDS:
                REJECT_BLOCKED_UIDS.discard(str(target_uid))
                print(f"🔓 Unblocked invites from {target_uid}")
        except Exception as e:
            print(f"Error unblocking UID: {e}")    
    
async def banecipher(client_id, key, iv, region):
    """Create reject spam packet 1 - Converted to new async format"""
    banner_text = f"""
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███

[b][FF0000]=====================[00FF00] 
████████╗░█████╗░███╗░░░███╗
╚══██╔══╝██╔══██╗████╗░████║
░░░██║░░░██║░░██║██╔████╔██║
░░░██║░░░██║░░██║██║╚██╔╝██║
░░░██║░░░╚█████╔╝██║░╚═╝░██║
░░░╚═╝░░░░╚════╝░╚═╝░░░░░╚═╝
[FF0000]=====================

[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███





"""        
    fields = {
        1: 5,
        2: {
            1: int(client_id),
            2: 1,
            3: int(client_id),
            4: banner_text
        }
    }
    
    packet_enc = (await CrEaTe_ProTo(fields)).hex()
    packet_enc = await EnC_PacKeT(packet_enc, key, iv) 

    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"
        
    # Manual Header Construction (Type + 4-byte Length)
    packet_len = len(packet_enc) // 2
    header = packet_type + f"{packet_len:08x}"
    
    return bytes.fromhex(header + packet_enc)

async def banecipher1(client_id, key, iv, region):
    """Create reject spam packet 2 - Converted to new async format"""
    gay_text = f"""
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███

[b][FF0000]=====================[00FF00] 
████████╗░█████╗░███╗░░░███╗
╚══██╔══╝██╔══██╗████╗░████║
░░░██║░░░██║░░██║██╔████╔██║
░░░██║░░░██║░░██║██║╚██╔╝██║
░░░██║░░░╚█████╔╝██║░╚═╝░██║
░░░╚═╝░░░░╚════╝░╚═╝░░░░░╚═╝
[FF0000]=====================

[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███
[b][00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███
[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[b][FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███[00FF00]███[FF0000]███






"""        
    fields = {
        1: int(client_id),
        2: 5,
        4: 50,
        5: {
            1: int(client_id),
            2: gay_text,
        }
    }
    
    packet_enc = (await CrEaTe_ProTo(fields)).hex()
    packet_enc = await EnC_PacKeT(packet_enc, key, iv)

    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"
        
    # Manual Header Construction (Type + 4-byte Length)
    packet_len = len(packet_enc) // 2
    header = packet_type + f"{packet_len:08x}"
    
    return bytes.fromhex(header + packet_enc)

async def banned_uid_message(client_id, key, iv, region):
    """Create reject spam packet 1 - Converted to new async format"""
    banner_text = f"""
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███

[b][FFFF00]=====================[FF0000] 

▀▀█▀▀ ░█─░█ ▀█▀ ░█▀▀▀█ 　 ▀█▀ ░█▀▀▄ 　 ░█─░█ ─█▀▀█ ░█▀▀▀█ 　 ░█▀▀█ ░█▀▀▀ ░█▀▀▀ ░█▄─░█ 　  
─░█── ░█▀▀█ ░█─ ─▀▀▀▄▄ 　 ░█─ ░█─░█ 　 ░█▀▀█ ░█▄▄█ ─▀▀▀▄▄ 　 ░█▀▀▄ ░█▀▀▀ ░█▀▀▀ ░█░█░█ 　 
─░█── ░█─░█ ▄█▄ ░█▄▄▄█ 　 ▄█▄ ░█▄▄▀ 　 ░█─░█ ░█─░█ ░█▄▄▄█ 　 ░█▄▄█ ░█▄▄▄ ░█▄▄▄ ░█──▀█ 　 

                          ░█▀▀█ ─█▀▀█ ░█▄─░█ ░█▄─░█ ░█▀▀▀ ░█▀▀▄ 
                          ░█▀▀▄ ░█▄▄█ ░█░█░█ ░█░█░█ ░█▀▀▀ ░█─░█ 
                          ░█▄▄█ ░█─░█ ░█──▀█ ░█──▀█ ░█▄▄▄ ░█▄▄▀
[FFFF00]=====================

[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███
[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[b][00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[00E5FF]███[5A2D82]███[b][5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███[5A2D82]███[FFFFFF]███

"""        
    fields = {
        1: 5,
        2: {
            1: int(client_id),
            2: 1,
            3: int(client_id),
            4: banner_text
        }
    }
    
    packet_enc = (await CrEaTe_ProTo(fields)).hex()
    packet_enc = await EnC_PacKeT(packet_enc, key, iv) 

    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"
        
    # Manual Header Construction (Type + 4-byte Length)
    packet_len = len(packet_enc) // 2
    header = packet_type + f"{packet_len:08x}"
    
    return bytes.fromhex(header + packet_enc)

async def muted_message(client_id, key, iv, region):
    """Create reject spam packet 1 - Converted to new async format"""
    banner_text = f"""
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
.
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███

[b][FF0000]=====================[00FFFF] 

██████╗░░█████╗░████████╗  ███╗░░░███╗██╗░░░██╗████████╗███████╗██████╗░
██╔══██╗██╔══██╗╚══██╔══╝  ████╗░████║██║░░░██║╚══██╔══╝██╔════╝██╔══██╗
██████╦╝██║░░██║░░░██║░░░  ██╔████╔██║██║░░░██║░░░██║░░░█████╗░░██║░░██║
██╔══██╗██║░░██║░░░██║░░░  ██║╚██╔╝██║██║░░░██║░░░██║░░░██╔══╝░░██║░░██║
██████╦╝╚█████╔╝░░░██║░░░  ██║░╚═╝░██║╚██████╔╝░░░██║░░░███████╗██████╔╝
╚═════╝░░╚════╝░░░░╚═╝░░░  ╚═╝░░░░░╚═╝░╚═════╝░░░░╚═╝░░░╚══════╝╚═════╝░

[FF0000]=====================

[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███
[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███
[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[b][00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███[00BFFF]███[8A2BE2]███

"""        
    fields = {
        1: 5,
        2: {
            1: int(client_id),
            2: 1,
            3: int(client_id),
            4: banner_text
        }
    }
    
    packet_enc = (await CrEaTe_ProTo(fields)).hex()
    packet_enc = await EnC_PacKeT(packet_enc, key, iv) 

    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"
        
    # Manual Header Construction (Type + 4-byte Length)
    packet_len = len(packet_enc) // 2
    header = packet_type + f"{packet_len:08x}"
    
    return bytes.fromhex(header + packet_enc) 

####################################

#Clan-info-by-clan-id
def Get_clan_info(clan_id):
    try:
        url = f"https://get-clan-info.vercel.app/get_clan_info?clan_id={clan_id}"
        res = requests.get(url)
        if res.status_code == 200:
            data = res.json()
            msg = f""" 
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
▶▶▶▶GUILD DETAILS◀◀◀◀
Achievements: {data['achievements']}\n\n
Balance : {fix_num(data['balance'])}\n\n
Clan Name : {data['clan_name']}\n\n
Expire Time : {fix_num(data['guild_details']['expire_time'])}\n\n
Members Online : {fix_num(data['guild_details']['members_online'])}\n\n
Regional : {data['guild_details']['regional']}\n\n
Reward Time : {fix_num(data['guild_details']['reward_time'])}\n\n
Total Members : {fix_num(data['guild_details']['total_members'])}\n\n
ID : {fix_num(data['id'])}\n\n
Last Active : {fix_num(data['last_active'])}\n\n
Level : {fix_num(data['level'])}\n\n
Rank : {fix_num(data['rank'])}\n\n
Region : {data['region']}\n\n
Score : {fix_num(data['score'])}\n\n
Timestamp1 : {fix_num(data['timestamp1'])}\n\n
Timestamp2 : {fix_num(data['timestamp2'])}\n\n
Welcome Message: {data['welcome_message']}\n\n
XP: {fix_num(data['xp'])}\n\n
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            """
            return msg
        else:
            msg = """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
Failed to get info, please try again later!!

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            """
            return msg
    except:
        pass
#GET INFO BY PLAYER ID
def get_player_info(player_id):
    url = f"https://like2.vercel.app/player-info?uid={player_id}&server={server2}&key={key2}"
    response = requests.get(url)
    print(response)    
    if response.status_code == 200:
        try:
            r = response.json()
            return {
                "Account Booyah Pass": f"{r.get('booyah_pass_level', 'N/A')}",
                "Account Create": f"{r.get('createAt', 'N/A')}",
                "Account Level": f"{r.get('level', 'N/A')}",
                "Account Likes": f" {r.get('likes', 'N/A')}",
                "Name": f"{r.get('nickname', 'N/A')}",
                "UID": f" {r.get('accountId', 'N/A')}",
                "Account Region": f"{r.get('region', 'N/A')}",
                }
        except ValueError as e:
            pass
            return {
                "error": "Invalid JSON response"
            }
    else:
        pass
        return {
            "error": f"Failed to fetch data: {response.status_code}"
        }
#GET PLAYER BIO 
def get_player_bio(uid):
    try:
        url = f"https://info-wotaxxdev-api.vercel.app/info?uid={uid}"
        res = requests.get(url)
        if res.status_code == 200:
            data = res.json()
            # Bio is inside socialInfo -> signature
            bio = data.get('socialInfo', {}).get('signature', None)
            if bio:
                return bio
            else:
                return "No bio available"
        else:
            return f"Failed to fetch bio. Status code: {res.status_code}"
    except Exception as e:
        return f"Error occurred: {e}"
#CHAT WITH AI
def talk_with_ai(question):
    url = f"https://aashish-ai-api.vercel.app/ask?key=AASHISH65&message={question}"
    res = requests.get(url)
    if res.status_code == 200:
        data = res.json()
        msg = data["message"]["content"]
        return msg
    else:
        return "An error occurred while connecting to the server."


####################################

# ** NEW INFO FUNCTION using the new API **
def newinfo(uid):
    # Base URL without parameters
    url = "https://like2.vercel.app/player-info"
    # Parameters dictionary - this is the robust way to do it
    params = {
        'uid': uid,
        'server': server2,  # Hardcoded to bd as requested
        'key': key2
    }
    try:
        # Pass the parameters to requests.get()
        response = requests.get(url, params=params, timeout=10)
        
        # Check if the request was successful
        if response.status_code == 200:
            data = response.json()
            # Check if the expected data structure is in the response
            if "basicInfo" in data:
                return {"status": "ok", "data": data}
            else:
                # The API returned 200, but the data is not what we expect (e.g., error message in JSON)
                return {"status": "error", "message": data.get("error", "Invalid ID or data not found.")}
        else:
            # The API returned an error status code (e.g., 404, 500)
            try:
                # Try to get a specific error message from the API's response
                error_msg = response.json().get('error', f"API returned status {response.status_code}")
                return {"status": "error", "message": error_msg}
            except ValueError:
                # If the error response is not JSON
                return {"status": "error", "message": f"API returned status {response.status_code}"}

    except requests.exceptions.RequestException as e:
        # Handle network errors (e.g., timeout, no connection)
        return {"status": "error", "message": f"Network error: {str(e)}"}
    except ValueError: 
        # Handle cases where the response is not valid JSON
        return {"status": "error", "message": "Invalid JSON response from API."}
        

        
async def send_title_msg(chat_id, key, iv):
        """Build title packet using dictionary structure like GenResponsMsg"""
    
        fields = {
            1: 1,  # type
            2: {   # data
                1: "13777777720",  # uid
                2: str(chat_id),   # chat_id  
                3: f"{{\"TitleID\":{get_random_title()},\"type\":\"Title\"}}",  # title
                4: int(datetime.now().timestamp()),  # timestamp
                5: 0,   # chat_type
                6: "en", # language
                9: {    # field9 - player details
                    1: "[C][B][FF0000] KRN ON TOP",  # Nickname
                    2: int(get_random_avatar()),          # avatar_id
                    3: 330,                          # rank
                    4: 102000015,                    # badge
                    5: "TEMP GUILD",                 # Clan_Name
                    6: 1,                            # field10
                    7: 1,                            # global_rank_pos
                    8: {                             # badge_info
                        1: 2                         # value
                    },
                    9: {                             # prime_info
                        1: 1158053040,               # prime_uid
                        2: 8,                        # prime_level
                        3: "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"  # prime_hex
                    }
                },
                13: {   # field13 - url options
                    1: 2,   # url_type
                    2: 1    # curl_platform
                },
                99: b""  # empty_field
            }
        }

        # **EXACTLY like GenResponsMsg:**
        packet = await CrEaTe_ProTo(fields)
        packet = packet.hex()
        encrypted_packet = await EnC_PacKeT(packet, key, iv)
        header_length = len(encrypted_packet) // 2
        header_length_final = await DecodE_HeX(header_length)
    
        # **KEY: Use 0515 for title packets instead of 1215**
        if len(header_length_final) == 2:
            final_packet = "0515000000" + header_length_final + encrypted_packet
        elif len(header_length_final) == 3:
            final_packet = "051500000" + header_length_final + encrypted_packet
        elif len(header_length_final) == 4:
            final_packet = "05150000" + header_length_final + encrypted_packet
        elif len(header_length_final) == 5:
            final_packet = "0515000" + header_length_final + encrypted_packet
    
        return bytes.fromhex(final_packet)
        
        

	
#ADDING-100-LIKES-IN-24H
def send_likes(uid):
    try:
        likes_api_response = requests.get(
             f"https://yourlikeapi/like?uid={uid}&server_name={server2}&x-vercel-set-bypass-cookie=true&x-vercel-protection-bypass={BYPASS_TOKEN}",
             timeout=15
             )
      
      
        if likes_api_response.status_code != 200:
            return f"""
[C][B][FF0000]━━━━━
[FFFFFF]Like API Error!
Status Code: {likes_api_response.status_code}
Please check if the uid is correct.
━━━━━
"""

        api_json_response = likes_api_response.json()

        player_name = api_json_response.get('PlayerNickname', 'Unknown')
        likes_before = api_json_response.get('LikesbeforeCommand', 0)
        likes_after = api_json_response.get('LikesafterCommand', 0)
        likes_added = api_json_response.get('LikesGivenByAPI', 0)
        status = api_json_response.get('status', 0)

        if status == 1 and likes_added > 0:
            # ✅ Success
            return f"""
[C][B][11EAFD]‎━━━━━━━━━━━━
[FFFFFF]Likes Status:

[00FF00]Likes Sent Successfully!

[FFFFFF]Player Name : [00FF00]{player_name}  
[FFFFFF]Likes Added : [00FF00]{likes_added}  
[FFFFFF]Likes Before : [00FF00]{likes_before}  
[FFFFFF]Likes After : [00FF00]{likes_after}  
[C][B][11EAFD]‎━━━━━━━━━━━━
[C][B][FFB300]Subscribe: [FFFFFF]SPIDEERIO YT [00FF00]!!
"""
        elif status == 2 or likes_before == likes_after:
            # 🚫 Already claimed / Maxed
            return f"""
[C][B][FF0000]━━━━━━━━━━━━

[FFFFFF]No Likes Sent!

[FF0000]You have already taken likes with this UID.
Try again after 24 hours.

[FFFFFF]Player Name : [FF0000]{player_name}  
[FFFFFF]Likes Before : [FF0000]{likes_before}  
[FFFFFF]Likes After : [FF0000]{likes_after}  
[C][B][FF0000]━━━━━━━━━━━━
"""
        else:
            # ❓ Unexpected case
            return f"""
[C][B][FF0000]━━━━━━━━━━━━
[FFFFFF]Unexpected Response!
Something went wrong.

Please try again or contact support.
━━━━━━━━━━━━
"""

    except requests.exceptions.RequestException:
        return """
[C][B][FF0000]━━━━━
[FFFFFF]Like API Connection Failed!
Is the API server (app.py) running?
━━━━━
"""
    except Exception as e:
        return f"""
[C][B][FF0000]━━━━━
[FFFFFF]An unexpected error occurred:
[FF0000]{str(e)}
━━━━━
"""


####################################
#CHECK ACCOUNT IS BANNED

Hr = {
    'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 11; ASUS_Z01QD Build/PI)",
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'Content-Type': "application/x-www-form-urlencoded",
    'Expect': "100-continue",
    'X-Unity-Version': "2018.4.11f1",
    'X-GA': "v1 1",
    'ReleaseVersion': "OB52"}

# ---- Random Colores ----
def get_random_color():
    colors = [
        "[FF0000]", "[00FF00]", "[0000FF]", "[FFFF00]", "[FF00FF]", "[00FFFF]", "[FFFFFF]", "[FFA500]",
        "[A52A2A]", "[800080]", "[000000]", "[808080]", "[C0C0C0]", "[FFC0CB]", "[FFD700]", "[ADD8E6]",
        "[90EE90]", "[D2691E]", "[DC143C]", "[00CED1]", "[9400D3]", "[F08080]", "[20B2AA]", "[FF1493]",
        "[7CFC00]", "[B22222]", "[FF4500]", "[DAA520]", "[00BFFF]", "[00FF7F]", "[4682B4]", "[6495ED]",
        "[5F9EA0]", "[DDA0DD]", "[E6E6FA]", "[B0C4DE]", "[556B2F]", "[8FBC8F]", "[2E8B57]", "[3CB371]",
        "[6B8E23]", "[808000]", "[B8860B]", "[CD5C5C]", "[8B0000]", "[FF6347]", "[FF8C00]", "[BDB76B]",
        "[9932CC]", "[8A2BE2]", "[4B0082]", "[6A5ACD]", "[7B68EE]", "[4169E1]", "[1E90FF]", "[191970]",
        "[00008B]", "[000080]", "[008080]", "[008B8B]", "[B0E0E6]", "[AFEEEE]", "[E0FFFF]", "[F5F5DC]",
        "[FAEBD7]"
    ]
    return random.choice(colors)

print(get_random_color())
    
# ---- Random Avatar ----
def get_random_avatar():
    avatar_list = [
        '902000013', '902049020', '902049019', '902049018', '902049017',
        '902049016', '902047016', '902027027', '902027022', '902000207',
        '902000065', '902048020', '902043017', '902043018', '902043019',
        '902043020', '902043021', '902043022', '902043023', '902043024',
        '902043025', '902045016', '902045017', '902045018', '902045019',
        '902045020', '902045021', '902045022', '902045023', '902045024',
        '902045025', '902037031'
    ]
    return random.choice(avatar_list)
    
# ---- Random Avatar ----
def get_random_title():
    title_list = [
        '905190079', '904990069'
    ]
    return random.choice(title_list)
async def encrypted_proto(encoded_hex):
    key = b'Yg&tc%DEuh6%Zc^8'
    iv = b'6oyZDr22E3ychjM%'
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_message = pad(encoded_hex, AES.block_size)
    encrypted_payload = cipher.encrypt(padded_message)
    return encrypted_payload
    
async def GeNeRaTeAccEss(uid , password):
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    headers = {
        "Host": "100067.connect.garena.com",
        "User-Agent": (await Ua()),
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close"}
    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"}
    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=Hr, data=data) as response:
            if response.status != 200: return "Failed to get access token"
            data = await response.json()
            open_id = data.get("open_id")
            access_token = data.get("access_token")
            return (open_id, access_token) if open_id and access_token else (None, None)

async def EncRypTMajoRLoGin(open_id, access_token):
    major_login = MajoRLoGinrEq_pb2.MajorLogin()
    major_login.event_time = str(datetime.now())[:-7]
    major_login.game_name = "free fire"
    major_login.platform_id = 1
    major_login.client_version = "1.120.2"
    major_login.system_software = "Android OS 9 / API-28 (PQ3B.190801.10101846/G9650ZHU2ARC6)"
    major_login.system_hardware = "Handheld"
    major_login.telecom_operator = "Verizon"
    major_login.network_type = "WIFI"
    major_login.screen_width = 1920
    major_login.screen_height = 1080
    major_login.screen_dpi = "280"
    major_login.processor_details = "ARM64 FP ASIMD AES VMH | 2865 | 4"
    major_login.memory = 3003
    major_login.gpu_renderer = "Adreno (TM) 640"
    major_login.gpu_version = "OpenGL ES 3.1 v1.46"
    major_login.unique_device_id = "Google|34a7dcdf-a7d5-4cb6-8d7e-3b0e448a0c57"
    major_login.client_ip = "223.191.51.89"
    major_login.language = "en"
    major_login.open_id = open_id
    major_login.open_id_type = "4"
    major_login.device_type = "Handheld"
    memory_available = major_login.memory_available
    memory_available.version = 55
    memory_available.hidden_value = 81
    major_login.access_token = access_token
    major_login.platform_sdk_id = 1
    major_login.network_operator_a = "Verizon"
    major_login.network_type_a = "WIFI"
    major_login.client_using_version = "7428b253defc164018c604a1ebbfebdf"
    major_login.external_storage_total = 36235
    major_login.external_storage_available = 31335
    major_login.internal_storage_total = 2519
    major_login.internal_storage_available = 703
    major_login.game_disk_storage_available = 25010
    major_login.game_disk_storage_total = 26628
    major_login.external_sdcard_avail_storage = 32992
    major_login.external_sdcard_total_storage = 36235
    major_login.login_by = 3
    major_login.library_path = "/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/lib/arm64"
    major_login.reg_avatar = 1
    major_login.library_token = "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-YPKM8jHEwAJlhpmhDhv5MQ==/base.apk"
    major_login.channel_type = 3
    major_login.cpu_type = 2
    major_login.cpu_architecture = "64"
    major_login.client_version_code = "2019118695"
    major_login.graphics_api = "OpenGLES2"
    major_login.supported_astc_bitset = 16383
    major_login.login_open_id_type = 4
    major_login.analytics_detail = b"FwQVTgUPX1UaUllDDwcWCRBpWA0FUgsvA1snWlBaO1kFYg=="
    major_login.loading_time = 13564
    major_login.release_channel = "android"
    major_login.extra_info = "KqsHTymw5/5GB23YGniUYN2/q47GATrq7eFeRatf0NkwLKEMQ0PK5BKEk72dPflAxUlEBir6Vtey83XqF593qsl8hwY="
    major_login.android_engine_init_flag = 110009
    major_login.if_push = 1
    major_login.is_vpn = 1
    major_login.origin_platform_type = "4"
    major_login.primary_platform_type = "4"
    string = major_login.SerializeToString()
    return  await encrypted_proto(string)

async def MajorLogin(payload):
    url = "https://loginbp.ggblueshark.com/MajorLogin"
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=payload, headers=Hr, ssl=ssl_context) as response:
            if response.status == 200: return await response.read()
            return None

async def GetLoginData(base_url, payload, token):
    url = f"{base_url}/GetLoginData"
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    Hr['Authorization']= f"Bearer {token}"
    async with aiohttp.ClientSession() as session:
        async with session.post(url, data=payload, headers=Hr, ssl=ssl_context) as response:
            if response.status == 200: return await response.read()
            return None

async def DecRypTMajoRLoGin(MajoRLoGinResPonsE):
    proto = MajoRLoGinrEs_pb2.MajorLoginRes()
    proto.ParseFromString(MajoRLoGinResPonsE)
    return proto

async def DecRypTLoGinDaTa(LoGinDaTa):
    proto = PorTs_pb2.GetLoginData()
    proto.ParseFromString(LoGinDaTa)
    return proto

async def DecodeWhisperMessage(hex_packet):
    packet = bytes.fromhex(hex_packet)
    proto = DEcwHisPErMsG_pb2.DecodeWhisper()
    proto.ParseFromString(packet)
    return proto
    
async def decode_team_packet(hex_packet):
    packet = bytes.fromhex(hex_packet)
    proto = sQ_pb2.recieved_chat()
    proto.ParseFromString(packet)
    return proto
    
async def xAuThSTarTuP(TarGeT, token, timestamp, key, iv):
    uid_hex = hex(TarGeT)[2:]
    uid_length = len(uid_hex)
    encrypted_timestamp = await DecodE_HeX(timestamp)
    encrypted_account_token = token.encode().hex()
    encrypted_packet = await EnC_PacKeT(encrypted_account_token, key, iv)
    encrypted_packet_length = hex(len(encrypted_packet) // 2)[2:]
    if uid_length == 9: headers = '0000000'
    elif uid_length == 8: headers = '00000000'
    elif uid_length == 10: headers = '000000'
    elif uid_length == 7: headers = '000000000'
    else: print('Unexpected length') ; headers = '0000000'
    return f"0115{headers}{uid_hex}{encrypted_timestamp}00000{encrypted_packet_length}{encrypted_packet}"
     
async def cHTypE(H):
    if not H: return 'Squid'
    elif H == 1: return 'CLan'
    elif H == 2: return 'PrivaTe'
    
async def SEndMsG(H , message , Uid , chat_id , key , iv):
    TypE = await cHTypE(H)
    if TypE == 'Squid': msg_packet = await xSEndMsgsQ(message , chat_id , key , iv)
    elif TypE == 'CLan': msg_packet = await xSEndMsg(message , 1 , chat_id , chat_id , key , iv)
    elif TypE == 'PrivaTe': msg_packet = await xSEndMsg(message , 2 , Uid , Uid , key , iv)
    return msg_packet

async def SEndPacKeT(OnLinE , ChaT , TypE , PacKeT):
    # OnLinE param receives whisper_writer
    # ChaT param receives online_writer (or specific writer)
    if TypE == 'ChaT' and OnLinE: OnLinE.write(PacKeT) ; await OnLinE.drain()
    elif TypE == 'OnLine' and ChaT: ChaT.write(PacKeT) ; await ChaT.drain()
    else: return 'UnsoPorTed TypE ! >> ErrrroR (:():)' 

async def safe_send_message(chat_type, message, target_uid, chat_id, key, iv, max_retries=3):
    """Safely send message with retry mechanism"""
    for attempt in range(max_retries):
        try:
            P = await SEndMsG(chat_type, message, target_uid, chat_id, key, iv)
            await SEndPacKeT(whisper_writer, online_writer, 'ChaT', P)
            print(f"Message sent successfully on attempt {attempt + 1}")
            return True
        except Exception as e:
            print(f"Failed to send message (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                await asyncio.sleep(0.5)  # Wait before retry
    return False

async def fast_emote_spam(uids, emote_id, key, iv, region):
    """Fast emote spam function that sends emotes rapidly"""
    global fast_spam_running
    count = 0
    max_count = 25  # Spam 25 times
    
    while fast_spam_running and count < max_count:
        for uid in uids:
            try:
                uid_int = int(uid)
                H = await Emote_k(uid_int, int(emote_id), key, iv, region)
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
            except Exception as e:
                print(f"Error in fast_emote_spam for uid {uid}: {e}")
        
        count += 1
        await asyncio.sleep(0.1)  # 0.1 seconds interval between spam cycles

# NEW FUNCTION: Custom emote spam with specified times
async def custom_emote_spam(uid, emote_id, times, key, iv, region):
    """Custom emote spam function that sends emotes specified number of times"""
    global custom_spam_running
    count = 0
    
    while custom_spam_running and count < times:
        try:
            uid_int = int(uid)
            H = await Emote_k(uid_int, int(emote_id), key, iv, region)
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
            count += 1
            await asyncio.sleep(0.1)  # 0.1 seconds interval between emotes
        except Exception as e:
            print(f"Error in custom_emote_spam for uid {uid}: {e}")
            break

# FIXED FUNCTION: Faster spam request loop - Sends exactly 30 requests quickly
async def spam_request_loop(target_uid, key, iv, region):
    """Spam request function that creates group and sends join requests in loop - FIXED VERSION"""
    global spam_request_running
    count = 0
    max_requests = 250  # Send exactly 30 requests
    
    while spam_request_running and count < max_requests:
        try:
            # Create squad
            PAc = await OpEnSq(key, iv, region)
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
            await asyncio.sleep(0.3)  # Increased delay for stability
            
            # Send invite
            V = await SEnd_InV(5, int(target_uid), key, iv, region)
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
            await asyncio.sleep(0.3)  # Increased delay for stability
            
            # Leave squad
            E = await ExiT(None, key, iv)
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)
            
            count += 1
            print(f"Sent request #{count} to {target_uid}")
            
            # Delay between requests
            await asyncio.sleep(0.3)  # Increased delay for stability
            
        except Exception as e:
            print(f"Error in spam_request_loop for uid {target_uid}: {e}")
            # Continue with next request instead of breaking
            await asyncio.sleep(0.3)
            


# NEW FUNCTION: Evolution emote spam with mapping
async def evo_emote_spam(uids, number, key, iv, region):
    """Send evolution emotes based on number mapping"""
    try:
        emote_id = EMOTE_MAP.get(int(number))
        if not emote_id:
            return False, f"Invalid number! Use 1-21 only."
        
        success_count = 0
        for uid in uids:
            try:
                uid_int = int(uid)
                H = await Emote_k(uid_int, emote_id, key, iv, region)
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
                success_count += 1
                await asyncio.sleep(0.1)
            except Exception as e:
                print(f"Error sending evo emote to {uid}: {e}")
        
        return True, f"Sent evolution emote {number} (ID: {emote_id}) to {success_count} player(s)"
    
    except Exception as e:
        return False, f"Error in evo_emote_spam: {str(e)}"

# NEW FUNCTION: Fast evolution emote spam
async def evo_fast_emote_spam(uids, number, key, iv, region):
    """Fast evolution emote spam function"""
    global evo_fast_spam_running
    count = 0
    max_count = 25  # Spam 25 times
    
    emote_id = EMOTE_MAP.get(int(number))
    if not emote_id:
        return False, f"Invalid number! Use 1-21 only."
    
    while evo_fast_spam_running and count < max_count:
        for uid in uids:
            try:
                uid_int = int(uid)
                H = await Emote_k(uid_int, emote_id, key, iv, region)
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
            except Exception as e:
                print(f"Error in evo_fast_emote_spam for uid {uid}: {e}")
        
        count += 1
        await asyncio.sleep(0.1)  # CHANGED: 0.5 seconds to 0.1 seconds
    
    return True, f"Completed fast evolution emote spam {count} times"

# NEW FUNCTION: Custom evolution emote spam with specified times
async def evo_custom_emote_spam(uids, number, times, key, iv, region):
    """Custom evolution emote spam with specified repeat times"""
    global evo_custom_spam_running
    count = 0
    
    emote_id = EMOTE_MAP.get(int(number))
    if not emote_id:
        return False, f"Invalid number! Use 1-21 only."
    
    while evo_custom_spam_running and count < times:
        for uid in uids:
            try:
                uid_int = int(uid)
                H = await Emote_k(uid_int, emote_id, key, iv, region)
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
            except Exception as e:
                print(f"Error in evo_custom_emote_spam for uid {uid}: {e}")
        
        count += 1
        await asyncio.sleep(0.1)  # CHANGED: 0.5 seconds to 0.1 seconds
    
    return True, f"Completed custom evolution emote spam {count} times"

async def EnC_Vr(N):
    if N < 0: ''
    H = []
    while True:
        BesTo = N & 0x7F ; N >>= 7
        if N: BesTo |= 0x80
        H.append(BesTo)
        if not N: break
    return bytes(H)

async def CrEaTe_VarianT(field_number, value):
    field_header = (field_number << 3) | 0
    return await EnC_Vr(field_header) + await EnC_Vr(value)

async def CrEaTe_LenGTh(field_number, value):
    field_header = (field_number << 3) | 2
    encoded_value = value.encode() if isinstance(value, str) else value
    return await EnC_Vr(field_header) + await EnC_Vr(len(encoded_value)) + encoded_value

async def CrEaTe_ProTo(fields):
    packet = bytearray()
    for field, value in fields.items():
        if isinstance(value, dict):
            nested_packet = await CrEaTe_ProTo(value)
            packet.extend(await CrEaTe_LenGTh(field, nested_packet))
        elif isinstance(value, int):
            packet.extend(await CrEaTe_VarianT(field, value))
        elif isinstance(value, str) or isinstance(value, bytes):
            packet.extend(await CrEaTe_LenGTh(field, value))
    return packet

async def DecodE_HeX(H):
    R = hex(H) 
    F = str(R)[2:]
    if len(F) == 1: F = "0" + F ; return F
    else: return F

async def bundle_packet_async(bundle_id, key, iv, region="ind"):
    """Create bundle packet"""
    fields = {
        1: 88,
        2: {
            1: {
                1: bundle_id,
                2: 1
            },
            2: 2
        }
    }
    
    # Use your CrEaTe_ProTo function
    packet = await CrEaTe_ProTo(fields)
    packet_hex = packet.hex()
    
    # Use your encrypt_packet function
    encrypted = await encrypt_packet(packet_hex, key, iv)
    
    # Use your DecodE_HeX function
    header_length = len(encrypted) // 2
    header_length_hex = await DecodE_HeX(header_length)
    
    # Build final packet based on region
    if region.lower() == "ind":
        packet_type = '0514'
    elif region.lower() == "bd":
        packet_type = "0519"
    else:
        packet_type = "0515"
    
    # Determine header based on length
    if len(header_length_hex) == 2:
        final_header = f"{packet_type}000000"
    elif len(header_length_hex) == 3:
        final_header = f"{packet_type}00000"
    elif len(header_length_hex) == 4:
        final_header = f"{packet_type}0000"
    elif len(header_length_hex) == 5:
        final_header = f"{packet_type}000"
    else:
        final_header = f"{packet_type}000000"
    
    final_packet_hex = final_header + header_length_hex + encrypted
    return bytes.fromhex(final_packet_hex)

async def RedZed_SendInv(bot_uid, uid, key, iv):
    """Async version of send invite function"""
    try:
        fields = {
            1: 33, 
            2: {
                1: int(uid), 
                2: "IND", 
                3: 1, 
                4: 1, 
                6: "RedZedKing!!", 
                7: 330, 
                8: 1000, 
                9: 100, 
                10: "DZ", 
                12: 1, 
                13: int(uid), 
                16: 1, 
                17: {
                    2: 159, 
                    4: "y[WW", 
                    6: 11, 
                    8: "1.118.1", 
                    9: 3, 
                    10: 1
                }, 
                18: 306, 
                19: 18, 
                24: 902000306, 
                26: {}, 
                27: {
                    1: 11, 
                    2: int(bot_uid), 
                    3: 99999999999
                }, 
                28: {}, 
                31: {
                    1: 1, 
                    2: 32768
                }, 
                32: 32768, 
                34: {
                    1: bot_uid, 
                    2: 8, 
                    3: b"\x10\x15\x08\x0A\x0B\x13\x0C\x0F\x11\x04\x07\x02\x03\x0D\x0E\x12\x01\x05\x06"
                }
            }
        }
        
        # Convert bytes properly
        if isinstance(fields[2][34][3], str):
            fields[2][34][3] = b"\x10\x15\x08\x0A\x0B\x13\x0C\x0F\x11\x04\x07\x02\x03\x0D\x0E\x12\x01\x05\x06"
        
        # Use async versions of your functions
        packet = await CrEaTe_ProTo(fields)
        packet_hex = packet.hex()
        
        # Generate final packet
        final_packet = await GeneRaTePk(packet_hex, '0515', key, iv)
        
        return final_packet
        
    except Exception as e:
        print(f"❌ Error in RedZed_SendInv: {e}")
        return None

async def ArohiAccepted(uid,code,K,V):
    fields = {
        1: 4,
        2: {
            1: uid,
            3: uid,
            8: 1,
            9: {
            2: 161,
            4: "y[WW",
            6: 11,
            8: "1.114.18",
            9: 3,
            10: 1
            },
            10: str(code),
        }
        }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex() , '0515' , K , V)

async def TcPOnLine(ip, port, key, iv, AutHToKen, region="ind", bot_uid=None, reconnect_delay=0.5):
    global online_writer , spam_room , whisper_writer , spammer_uid , spam_chat_id , spam_uid , XX , uid , Spy,data2, Chat_Leave, fast_spam_running, fast_spam_task, custom_spam_running, custom_spam_task, spam_request_running, spam_request_task, evo_fast_spam_running, evo_fast_spam_task, evo_custom_spam_running, evo_custom_spam_task, lag_running, lag_task, current_group_members, insquad, joining_team, REJECT_BLOCKED_UIDS
    
    # Initialize auto-accept state
    if insquad is not None:
        insquad = None
    if joining_team is True:
        joining_team = False
        
    online_writer = None
    whisper_writer = None

    while True:
        try:
            print(f"Attempting to connect to {ip}:{port}...")
            reader , writer = await asyncio.open_connection(ip, int(port))
            online_writer = writer
            if bot_uid:
                online_writers[bot_uid] = writer
            
            # --- AUTHENTICATION ---
            bytes_payload = bytes.fromhex(AutHToKen)
            online_writer.write(bytes_payload)
            await online_writer.drain()
            print("Authentication token sent. Entering read loop...")
            
            while True:
                data2 = await reader.read(9999)
                if not data2: 
                    print("Connection closed by the server.")
                    break
                
                data_hex = data2.hex()

                # --- Status Response Interception ---
                if len(data_hex) > 100: # Simple length filter
                    # Try to handle ANY packet as status response if it looks like protobuf
                    asyncio.create_task(handle_status_response(data_hex))
                
                # =================== EMOTE HIJACK ====================
                if data_hex.startswith('0514'):
                    try:
                        # Try to extract emote info from encrypted packet
                        decrypted = await DeCode_PackEt(data_hex[10:])
                        packet_json = json.loads(decrypted)
                        
                        # Check for Type 21 (emote packet)
                        if packet_json.get('1') == 21:
                            if '2' in packet_json and 'data' in packet_json['2']:
                                emote_data = packet_json['2']['data']
                                
                                if ('1' in emote_data and '2' in emote_data and 
                                    '5' in emote_data and 'data' in emote_data['5']):
                                    
                                    nested = emote_data['5']['data']
                                    
                                    if '1' in nested and '3' in nested:
                                        sender_uid = nested.get('1', {}).get('data')
                                        emote_id = nested.get('3', {}).get('data')
                                        
                                        print(f"🎯 EMOTE HIJACK DETECTED!")
                                        print(f"👤 Sender: {sender_uid}")
                                        print(f"🎭 Original emote: {emote_id}")
                                        
                                        # Send special emote back
                                        special_emote = await Emote_k(int(sender_uid), 909038002, key, iv, region)
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', special_emote)
                                        print(f"🎁 Sent special emote 909038002 to {sender_uid}")
                                        
                                        # Mirror user's emote back
                                        await asyncio.sleep(0.3)
                                        try:
                                            mirror_emote_id = int(emote_id)
                                            mirror_packet = await Emote_k(int(sender_uid), mirror_emote_id, key, iv, region)
                                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', mirror_packet)
                                            print(f"🔄 Mirroring user's emote {emote_id} back")
                                        except ValueError:
                                            print(f"❌ Could not convert emote ID: {emote_id}")
                                        
                                        # Bot also does the emote to itself
                                        await asyncio.sleep(0.2)
                                        try:
                                            # Use global bot_uid if available
                                            bot_self_emote = await Emote_k(14009897329, int(emote_id), key, iv, region)
                                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', bot_self_emote)
                                            print(f"🤖 Bot also doing emote {emote_id}")
                                        except Exception as e:
                                            print(f"❌ Bot self-emote failed: {e}")
                                        
                                        continue  # Skip other processing for this packet
                                        
                    except Exception as e:
                        print(f"❌ Emote hijack error: {e}")
                        pass
                
                # =================== AUTO ACCEPT HANDLING ===================
                
                # Case 1: Squad is cancelled or left
                if data_hex.startswith('0500') and insquad is not None:
                    try:
                        packet = await DeCode_PackEt(data_hex[10:])
                        packet_json = json.loads(packet)
                        
                        code_val = packet_json.get('1')
                        # Debug print to find the correct exit code
                        print(f"Squad status update code: {code_val}")
                        
                        if code_val in [6, 7, 8, 52]: # Added more potential codes
                             insquad = None
                             joining_team = False
                             print(f"Squad cancelled or exited (code {code_val}).")
                             continue
                             
                    except Exception as e:
                        print(f"Error in squad check: {e}")
                        pass

                # Case 2: Receiving an invitation while not in a squad (Auto-Join/Accept)
                # Added check: If we get an invite, maybe we aren't actually in a squad?
                if data_hex.startswith("0500") and (insquad is None or joining_team == False):
                    try:
                        packet = await DeCode_PackEt(data_hex[10:])
                        packet_json = json.loads(packet)
                        
                        if '5' in packet_json and 'data' in packet_json['5']:
                             p5 = packet_json['5']['data']
                             # Check minimum structure for invite
                             if '2' in p5 and 'data' in p5['2'] and '1' in p5['2']['data'] and '1' in p5 and 'data' in p5['1'] and '8' in p5 and 'data' in p5['8']:
                                 
                                 invite_uid = p5['2']['data']['1']['data'] 
                                 squad_owner = p5['1']['data']
                                 code = p5['8']['data']

                                 # 🚫 Block invites from banned players
                                 if is_banned(invite_uid):
                                     print(f"🚫 Ignored invite from BANNED player: {invite_uid}")
                                     
                                     # Send "Blocked" message to friend chat
                                     try:
                                         ban_msg = "[B][C][FF0000]Your account has been blocked. Please contact the administrator."
                                         # Type 2 = Private/Friend Chat
                                         whisper_pkt = await SEndMsG(2, ban_msg, int(invite_uid), int(invite_uid), key, iv)
                                         if online_writer:
                                             await SEndPacKeT(whisper_writer, online_writer, 'ChaT', whisper_pkt)
                                     except Exception as e:
                                         print(f"Failed to send ban warning: {e}")

                                     # 🔥 Trigger Auto-Reject Spam on Banned User
                                     asyncio.create_task(reject_spam_auto(invite_uid, key, iv, region))
                                     continue

                                 # 🚫 Block invites from REJECT SPAM targets
                                 if str(invite_uid) in REJECT_BLOCKED_UIDS:
                                     print(f"🚫 Ignored invite from REJECTED player: {invite_uid}")
                                     continue

                                 # 🔇 Block invites if bot is muted (unless admin)
                                 if is_bot_muted() and not is_admin(invite_uid):
                                     print(f"🔇 Bot is muted, ignoring invite from: {invite_uid}")
                                     
                                     # Send "Bot is muted" message to friend chat
                                     try:
                                         mute_msg = "[B][C][FF0000]Bot is muted"
                                         # Type 2 = Private/Friend Chat
                                         whisper_pkt = await SEndMsG(2, mute_msg, int(invite_uid), int(invite_uid), key, iv)
                                         if online_writer:
                                             await SEndPacKeT(whisper_writer, online_writer, 'ChaT', whisper_pkt)
                                         print(f"Sent muted warning to {invite_uid}")
                                     except Exception as e:
                                         print(f"Failed to send muted warning: {e}")

                                     # 🔥 Trigger Muted Reject Spam
                                     asyncio.create_task(reject_spam_muted(invite_uid, key, iv, region))
                                     continue
                                 
                                 # Logic to accept
                                 bot_uid_val = bot_uid
                                 emote_id = 909050009
                                 
                                #  SendInv = await RedZed_SendInv(bot_uid_val, invite_uid, key, iv)
                                #  await SEndPacKeT(whisper_writer, online_writer, 'OnLine', SendInv)
                                 
                                 if 'RejectMSGtaxt' in globals():
                                     inv_packet = await RejectMSGtaxt(squad_owner, squad_owner, key, iv)
                                     await SEndPacKeT(whisper_writer, online_writer, 'OnLine', inv_packet)
                                 
                                 print(f"Received squad invite from {squad_owner}, accepting...")                  
                                 Join = await ArohiAccepted(squad_owner, code, key, iv)
                                 await SEndPacKeT(whisper_writer, online_writer, 'OnLine', Join)
                                 
                                 # ⚠️ CHECK IF LEVEL UP AUTO IS RUNNING
                                 # ⚠️ CHECK IF LEVEL UP AUTO IS RUNNING
                                 if level_running:
                                      print(f"⚠️ Invite received while Level Up Auto is running! Warning sender.")
                                      # Increase wait to ensure joined
                                      await asyncio.sleep(2.0)
                                      
                                      warn_msg = "[B][C][FF0000]level up is running use /sauto to use bot"
                                      
                                      # 1. Send to Team Chat (Type 0)
                                      try:
                                          chat_pkt = await SEndMsG(0, warn_msg, squad_owner, squad_owner, key, iv)
                                          if online_writer:
                                               await SEndPacKeT(whisper_writer, online_writer, 'ChaT', chat_pkt)
                                      except Exception as e:
                                          print(f"Failed to send team warning: {e}")

                                      # 2. Send to Inviter Private (Type 2 - Private/Friend)
                                      try:
                                          # Use invite_uid as target
                                          # Passing 2 to SEndMsG triggers 'PrivaTe' logic -> xSEndMsg with Type 2
                                          whisper_pkt = await SEndMsG(2, warn_msg, int(invite_uid), int(invite_uid), key, iv)
                                          if online_writer:
                                               await SEndPacKeT(whisper_writer, online_writer, 'ChaT', whisper_pkt)
                                      except Exception as e:
                                           print(f"Failed to send private warning: {e}")
                                      
                                      # Increase leave delay to ensure packets sent
                                      await asyncio.sleep(1.5)
                                      
                                      # Leave to resume auto loop
                                      leave_pkt = await ExiT(None, key, iv)
                                      await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_pkt)
                                      continue
                                    
                                 await asyncio.sleep(2)

                                 # 🎁 RANDOM BUNDLE ON JOIN 🎁
                                 try:
                                     # Bundle IDs mapping
                                     bundle_ids_map = {
                                        "rampage": 914000002,
                                        "cannibal": 914000003,
                                        "devil": 914038001,
                                        "scorpio": 914039001,
                                        "frostfire": 914042001,
                                        "paradox": 914044001,
                                        "naruto": 914047001,
                                        "aurora": 914047002,
                                        "midnight": 914048001,
                                        "itachi": 914050001,
                                        "dreamspace": 914051001
                                     }
                                     
                                     random_bundle_name = random.choice(list(bundle_ids_map.keys()))
                                     random_bundle_id = bundle_ids_map[random_bundle_name]
                                     
                                     print(f"🎁 Equipping random bundle: {random_bundle_name} ({random_bundle_id})")
                                     
                                     # Send bundle packet
                                     bundle_pkt = await bundle_packet_async(random_bundle_id, key, iv, region)
                                     if bundle_pkt:
                                         await SEndPacKeT(whisper_writer, online_writer, 'OnLine', bundle_pkt)
                                         
                                 except Exception as e:
                                     print(f"❌ Error equipping random bundle: {e}")

                                 insquad = True
                                 continue
                    except Exception as e:
                        pass # Ignore parsing errors for non-invite packets

                # Case 3: Joining Team/Chat handling (long packet)
                if data_hex.startswith('0500') and len(data_hex) > 1000 and joining_team:
                    try:
                        packet = await DeCode_PackEt(data_hex[10:])
                        packet_json = json.loads(packet)
                        
                        OwNer_UiD , CHaT_CoDe , SQuAD_CoDe = await GeTSQDaTa(packet_json)

                        # 🚫 CHECK IF TEAM OWNER IS BANNED OR MUTED
                        if is_banned(OwNer_UiD) or (is_bot_muted() and not is_admin(OwNer_UiD)):
                             print(f"🚫 BLOCKED: Owner {OwNer_UiD} is banned/muted. Leaving team...")
                             leave_pkt = await ExiT(None, key, iv)
                             await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_pkt)
                             joining_team = False
                             continue
                        
                        print(f"Received squad data for joining team, attempting chat auth for {OwNer_UiD}...")
                        JoinCHaT = await AutH_Chat(3 , OwNer_UiD , CHaT_CoDe, key,iv)
                        await SEndPacKeT(whisper_writer , online_writer , 'ChaT' , JoinCHaT)

                        # 🎁 RANDOM BUNDLE ON JOIN VIA CODE 🎁
                        try:
                            # Bundle IDs mapping
                            bundle_ids_map = {
                                "rampage": 914000002,
                                "cannibal": 914000003,
                                "devil": 914038001,
                                "scorpio": 914039001,
                                "frostfire": 914042001,
                                "paradox": 914044001,
                                "naruto": 914047001,
                                "aurora": 914047002,
                                "midnight": 914048001,
                                "itachi": 914050001,
                                "dreamspace": 914051001
                            }
                                     
                            random_bundle_name = random.choice(list(bundle_ids_map.keys()))
                            random_bundle_id = bundle_ids_map[random_bundle_name]
                                     
                            print(f"🎁 (Code Join) Equipping random bundle: {random_bundle_name} ({random_bundle_id})")
                                     
                            # Send bundle packet
                            bundle_pkt = await bundle_packet_async(random_bundle_id, key, iv, region)
                            if bundle_pkt:
                                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', bundle_pkt)
                                         
                        except Exception as e:
                            print(f"❌ Error equipping random bundle (Code Join): {e}")

                        
                        # WELCOME MESSAGE (Team Chat)
                        message = f'''[FF0000][c]━━━━━━━━━━━━━━━━━━━━[/c]

[FFD700][b][c]✨ Welcome, brother! I am always ready to help you 😊 ✨[/b]

[FFFFFF][c]To find out your commands, send this command:  

[32CD32][b][c]/🤫help -> [FFFFFF]Show Full Menu[/b]
[32CD32][b][c]/🤫group -> [FFFFFF]Show Group Menu[/b]
[32CD32][b][c]/🤫emote -> [FFFFFF]Show Emote Menu[/b]
[32CD32][b][c]/🤫attack -> [FFFFFF]Show Attack Menu[/b]
[32CD32][b][c]/🤫levelup -> [FFFFFF]Show levelup Menu[/b]

[FF0000][c]━━━━━━━━━━━━━━━━━━━━[/c]

[FFD700][b][c]thank you for supporting follow:[/b]

[1E90FF][b][c] Instagram Name: ig._tom_[/b]
[1E90FF][c]muzammil_cp[/c]

[FFD700][b][c]Developer: TOM [/b]

[FF0000][c]━━━━━━━━━━━━━━━━━━━━[/c]'''
                        P = await SEndMsG(0 , message , OwNer_UiD , OwNer_UiD , key , iv)
                        await SEndPacKeT(whisper_writer , online_writer , 'ChaT' , P)

                        joining_team = False
                            
                    except Exception as e:
                        print(f"Error in joining_team chat auth: {e}")
                        pass
                
                # Case 4: General Chat Auth (long packet, not actively joining)
                if data_hex.startswith('0500') and len(data_hex) > 1000 and joining_team == False:
                    try:
                        packet = await DeCode_PackEt(data_hex[10:])
                        packet_json = json.loads(packet)
                        
                        # Only try to auth chat if we have the necessary structure
                        if '5' in packet_json and 'data' in packet_json['5'] and '14' in packet_json['5']['data']:
                            OwNer_UiD , CHaT_CoDe , SQuAD_CoDe = await GeTSQDaTa(packet_json)

                            # 🚫 CHECK IF TEAM OWNER IS BANNED OR MUTED
                            if is_banned(OwNer_UiD) or (is_bot_muted() and not is_admin(OwNer_UiD)):
                                 print(f"🚫 BLOCKED: Owner {OwNer_UiD} is banned/muted. Leaving team...")
                                 leave_pkt = await ExiT(None, key, iv)
                                 await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_pkt)
                                 continue

                            print(f"Received long packet, attempting general chat auth for {OwNer_UiD}...")
                            JoinCHaT = await AutH_Chat(3 , OwNer_UiD , CHaT_CoDe, key,iv)
                            await SEndPacKeT(whisper_writer , online_writer , 'ChaT' , JoinCHaT)

                            # WELCOME MESSAGE (Team Chat)
                            message = f'''[FF0000][c]━━━━━━━━━━━━━━━━━━━━[/c]

[FFD700][b][c]✨ Welcome, brother! I am always ready to help you 😊 ✨[/b]

[FFFFFF][c]To find out your commands, send this command:  

[32CD32][b][c]/🤫help -> [FFFFFF]Show Full Menu[/b]
[32CD32][b][c]/🤫group -> [FFFFFF]Show Group Menu[/b]
[32CD32][b][c]/🤫emote -> [FFFFFF]Show Emote Menu[/b]
[32CD32][b][c]/🤫attack -> [FFFFFF]Show Attack Menu[/b]
[32CD32][b][c]/🤫levelup -> [FFFFFF]Show levelup Menu[/b]

[FF0000][c]━━━━━━━━━━━━━━━━━━━━[/c]

[FFD700][b][c]thank you for supporting follow:[/b]

[1E90FF][b][c] Instagram Name: ig._tom_[/b]
[1E90FF][c]muzammil_cp[/c]

[FFD700][b][c]Developer: TOM [/b]

[FF0000][c]━━━━━━━━━━━━━━━━━━━━[/c]'''
                            P = await SEndMsG(0 , message , OwNer_UiD , OwNer_UiD , key , iv)
                            await SEndPacKeT(whisper_writer , online_writer , 'ChaT' , P)
                            
                            # Existing welcome message logic could go here if needed
                            try:
                                 await auto_rings_emote_dual(OwNer_UiD, key, iv, region)
                            except Exception as emote_error:
                                print(f"Auto dual emote failed: {emote_error}")
                        else:
                            # Not a chat packet, ignore
                            pass

                    except:
                        if data.hex().startswith('0500') and len(data.hex()) > 1000:
                            try:
                                print(data.hex()[10:])
                                packet = await DeCode_PackEt(data.hex()[10:])
                                print(packet)
                                packet = json.loads(packet)
                                OwNer_UiD , CHaT_CoDe , SQuAD_CoDe = await GeTSQDaTa(packet)

                                JoinCHaT = await AutH_Chat(3 , OwNer_UiD , CHaT_CoDe, key,iv)
                                await SEndPacKeT(whisper_writer , online_writer , 'ChaT' , JoinCHaT)


                                message = f'[B][C]{get_random_color()}\\n- Welcome, brother! \\n'
                                P = await SEndMsG(0 , message , OwNer_UiD , OwNer_UiD , key , iv)
                                await SEndPacKeT(whisper_writer , online_writer , 'ChaT' , P)
                            except:
                                pass
                        # print(f"Error in general chat auth: {e}")
                        pass
            
            # Close connection if inner loop breaks           
            if online_writer is not None:
                online_writer.close()
                await online_writer.wait_closed()
                online_writer = None

        except Exception as e: 
            print(f"- ErroR With {ip}:{port} - {e}")
            online_writer = None
        
        await asyncio.sleep(reconnect_delay)
        
                    

                            
async def GenLevelStartPacket(key, iv):
    # Packet for /auto start (matches start_autooo in LEVELUP)
    # Field 1: 9, Field 2: {1: 12480598706}
    fields = {
        1: 9,
        2: {
            1: 12480598706,
        },
    }
    # Using 0515 as packet ID based on LEVELUP
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), "0515", key, iv)

async def GenLevelLeavePacket(key, iv):
    # Packet for /auto leave (matches leave_s in LEVELUP)
    # Field 1: 7, Field 2: {1: 12480598706}
    fields = {
        1: 7,
        2: {
            1: 12480598706,
        },
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), "0515", key, iv)

async def run_one_time_start(team_code, uid, chat_id, chat_type, key, iv, writer=None):
    """
    Helper for /start command: Joins, spams start for 18s, then leaves.
    """
    try:
        # Resolve writer if not passed
        if not writer and uid in online_writers:
             writer = online_writers[uid]

        # Join team
        if whisper_writer and writer:
             join_pkt = await GenJoinSquadsPacket(team_code, key, iv)
             await SEndPacKeT(whisper_writer, writer, 'OnLine', join_pkt)
             await asyncio.sleep(2)
        
        # Spam Start Packet
        start_pkt = await GenLevelStartPacket(key, iv)
        end_time = time.time() + 18 # START_SPAM_DURATION
        
        while time.time() < end_time:
             if whisper_writer and writer:
                  await SEndPacKeT(whisper_writer, writer, 'OnLine', start_pkt)
             await asyncio.sleep(0.2) # START_SPAM_DELAY
        
        # if chat_id:
        #     msg = f"[B][C][00FF00]Force start complete for team {team_code}.\nLeaving team now.\n{PROMO_TEXT}"
        #     await safe_send_message(chat_type, msg, uid, chat_id, key, iv)
        
        # Leave team - DISABLED PER USER REQUEST
        # if whisper_writer and online_writer:
        #      leave_pkt = await GenLevelLeavePacket(key, iv)
        #      await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_pkt)

    except Exception as e:
        print(f"Error in run_one_time_start: {e}")

async def level_loop_task(team_code, uid, chat_id, chat_type, key, iv, region):
    global level_running, whisper_writer, online_writer
    print(f"[LEVEL] Starting level loop for team {team_code}")
    
    while level_running:
        try:
            # JOIN
            join_pkt = await GenJoinSquadsPacket(team_code, key, iv)
            if whisper_writer and online_writer:
                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_pkt)
            
            await asyncio.sleep(2)
            
            # Message: Joined
            if whisper_writer:
                msg = f"[C][B][FFA500]Team {team_code} joined. Starting match...\n{PROMO_TEXT}"
                # Use safe_send_message or GenResponsMsg logic? 
                # LEVELUP used GenResponsMsg. main.py uses safe_send_message.
                if chat_id:
                     await safe_send_message(chat_type, msg, uid, chat_id, key, iv)

            # START SPAM
            start_pkt = await GenLevelStartPacket(key, iv)
            end_time = time.time() + 18 # duration from LEVELUP
            while time.time() < end_time and level_running:
                if online_writer:
                    online_writer.write(start_pkt)
                    await online_writer.drain()
                await asyncio.sleep(0.2) # START_SPAM_DELAY
            
            if not level_running: break

            # WAIT
            if whisper_writer:
                msg = f"[C][B][00FF00]Match started. Bot lobby me wait karega 20 sec...\n{PROMO_TEXT}"
                if chat_id:
                     await safe_send_message(chat_type, msg, uid, chat_id, key, iv)
            
            waited = 0
            while waited < 20 and level_running: # WAIT_AFTER_MATCH_SECONDS
                await asyncio.sleep(1)
                waited += 1

            if not level_running: break

            # LEAVE
            leave_pkt = await GenLevelLeavePacket(key, iv)
            if online_writer:
                online_writer.write(leave_pkt)
                await online_writer.drain()
            
            await asyncio.sleep(2)

            if whisper_writer:
                 msg = f"[C][B][FF0000]Leaving team {team_code} and rejoining to force start again...\n{PROMO_TEXT}"
                 if chat_id:
                     await safe_send_message(chat_type, msg, uid, chat_id, key, iv)

        except Exception as e:
            print(f"[LEVEL] Error in loop: {e}")
            level_running = False
            break
    
    print(f"[LEVEL] Loop stopped for team {team_code}")
async def telegram_cmd_listener(cmd_queue, key, iv, region, bot_uid, bot_password, current_clan_id, join_func):
    global level_running, level_task, uid, chat_id, XX, reject_spam_running, reject_spam_task, current_group_members, is_muted, banned_uids, whisper_writer, online_writer
    global spam_req_task, invite_spam_task, room_spam_task, lag_task, evo_custom_spam_task, max_evo_task, rnd_task, fast_spam_task, BADGE_SPAM_TASK, spam_request_task, spam_request_running, lag_running
    
    # Initialize task placeholders if not exist
    spam_req_task = None
    invite_spam_task = None
    room_spam_task = None
    lag_task = None
    evo_custom_spam_task = None
    max_evo_task = None
    rnd_task = None
    fast_spam_task = None
    
    print("background telegram cmd listener started")
    while True:
        try:
            if cmd_queue and not cmd_queue.empty():
                try:
                    cmd_data = cmd_queue.get_nowait()
                    cmd = cmd_data[0]
                    print(f"DEBUG: Listener received CMD: {cmd}")

                    if cmd == 'stop':
                        os._exit(0)
                    
                    elif cmd == 'restart':
                         with open("restart_flag", "w") as f: f.write("restart")
                         os._exit(0)

                    # Requires Bot to be 'In-Game' / Connected (UID/ChatID set)
                    if bot_uid is None: # Use bot_uid instead of uid
                        continue
                        # print("Waiting for bot to initialize UID/ChatID...")

                    if cmd == 'start': # /start <teamcode>
                         # chat_id might be None initially (e.g. before joining team), so we allow it.
                         
                         team_code = cmd_data[1]
                         asyncio.create_task(run_one_time_start(team_code, bot_uid, chat_id, XX, key, iv))

                    elif cmd == 'join': # /join <teamcode> <sender_uid>
                        team_code = cmd_data[1]
                        sender_uid = cmd_data[2] if len(cmd_data) > 2 else None
                        # Use injected join function
                        await join_func(team_code, key, iv, sender_uid, region, bot_uid)

                    elif cmd == 'solo':
                         try:
                             # ExiT(None, key, iv) creates packet to leave team
                             EP = await ExiT(None, key, iv)
                             if online_writer:
                                 await SEndPacKeT(whisper_writer, online_writer, 'OnLine', EP)
                                 print(f"✅ {bot_uid} Left Squad (Solo)")
                             
                             # Remove from session if managed
                             # We need to know WHO requested it if we want to enforce ownership
                             # But here we are inside the worker. The 'solo' command in Telegram 
                             # needs to enforce it. IF this worker receives 'solo', it assumes authorized.
                         except Exception as e:
                             print(f"❌ Error going solo: {e}")

                    elif cmd == 'slots':
                        try:
                            # cmd_data = ('slots', mode_str, uid_arg)
                            mode_val = int(cmd_data[1])
                            target_uid = cmd_data[2]
                            
                            # 1. Open Squad
                            PAc = await OpEnSq(key, iv, region)
                            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
                            await asyncio.sleep(0.3)

                            # 2. Change Mode (Use target_uid directly even if 0)
                            C = await cHSq(mode_val, target_uid, key, iv, region)
                            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', C)
                            
                            # 3. Invite if UID provided
                            if target_uid:
                                await asyncio.sleep(0.3)
                                V = await SEnd_InV(mode_val, target_uid, key, iv, region)
                                if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
                            
                            # 4. Exit (Legacy uses None)
                            # User Request: Wait 10 seconds before leaving
                            print(f"⏳ {bot_uid} waiting 10s before leaving squad...")
                            await asyncio.sleep(10)
                            E = await ExiT(None, key, iv)
                            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)

                            print(f"✅ Executed /{mode_val} command (Slots) & Left after 10s")
                        except Exception as e:
                             print(f"❌ Error in slots command: {e}")



                    
                    elif cmd == 'auto': # /auto <teamcode>
                        team_code = cmd_data[1]
                        if not level_running:
                            level_running = True
                            level_task = asyncio.create_task(level_loop_task(team_code, bot_uid, chat_id, XX, key, iv, region))
                    
                    elif cmd == 'sauto':
                        if level_running:
                            level_running = False
                            if level_task: level_task.cancel()

                    elif cmd == 'lag': # /lag <teamcode>
                         team_code = cmd_data[1]
                         if lag_running:
                              lag_running = False
                              if lag_task: lag_task.cancel()
                              await asyncio.sleep(0.1)
                         
                         lag_running = True
                         lag_task = asyncio.create_task(lag_team_loop(team_code, key, iv, region))
                         print(f"🔥 Lag started on team {team_code}")

                    elif cmd == 'slag':
                         if lag_running:
                              lag_running = False
                              if lag_task: lag_task.cancel()
                              print("🛑 Lag stopped")
                    
                    elif cmd == 'inv': # /inv <target_uid>
                        target_inv = int(cmd_data[1])
                        try:
                            PAc = await OpEnSq(key, iv, region)
                            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
                            await asyncio.sleep(0.3)
                            C = await cHSq(5, target_inv, key, iv, region)
                            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', C)
                            await asyncio.sleep(0.3)
                            V = await SEnd_InV(5, target_inv, key, iv, region)
                            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
                            await asyncio.sleep(0.3)
                            E = await ExiT(None, key, iv)
                            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)
                        except: pass

                    elif cmd == 'gj': # /gj <guild_id>
                        gid = cmd_data[1]
                        loop = asyncio.get_event_loop()
                        with ThreadPoolExecutor() as executor:
                            await loop.run_in_executor(executor, api_join_guild, bot_uid, bot_password, gid)

                    elif cmd == 'gl': # /gl <guild_id>
                        gid = cmd_data[1]
                        
                        target_gid = gid
                        if (target_gid is None or target_gid == 'current') and current_clan_id:
                            target_gid = current_clan_id
                            
                        if target_gid:
                             loop = asyncio.get_event_loop()
                             with ThreadPoolExecutor() as executor:
                                  await loop.run_in_executor(executor, api_leave_guild, bot_uid, bot_password, target_gid)
                        else:
                             print("Error: /gl failed - No Guild ID provided and Bot not in a guild.")



                    elif cmd == 'bundle_short': # /b1 ...
                        c = cmd_data[1] # "1", "2" ...
                        # Mapping
                        b_shorts = {
                             "1": "2500001", "2": "2500002", "3": "2500003", "4": "2500004",
                             "5": "2500005", "6": "2500006", "7": "2500007", "8": "2500008",
                             "9": "2500009", "10": "2500010", "11": "2500011"
                        }
                        bid = b_shorts.get(c, "2500001")
                        if whisper_writer and online_writer:
                            pkt = await bundle_packet_async(bid, key, iv, region)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)





                    elif cmd == 'ban':
                         uid_ban = cmd_data[1]
                         # Add to global banned list
                         if uid_ban not in banned_uids: banned_uids.append(uid_ban)
                         save_banned_uids()

                    elif cmd == 'unban':
                         uid_ban = cmd_data[1]
                         if uid_ban in banned_uids: banned_uids.remove(uid_ban)
                         save_banned_uids()
                    
                    elif cmd == 'mute':
                         global is_muted, mute_until
                         duration = int(cmd_data[1])
                         is_muted = True
                         mute_until = time.time() + duration
                    
                    elif cmd == 'unmute':
                         is_muted = False
                         mute_until = 0

                    elif cmd == 'ban':
                         uid_ban = cmd_data[1]
                         try:
                             with open("banned.json", "r") as f: ban_list = json.load(f)
                         except: ban_list = []
                         if uid_ban not in ban_list:
                             ban_list.append(uid_ban)
                             with open("banned.json", "w") as f: json.dump(ban_list, f)

                    elif cmd == 'unban':
                         uid_unban = cmd_data[1]
                         try:
                             with open("banned.json", "r") as f: ban_list = json.load(f)
                         except: ban_list = []
                         
                         if uid_unban == 'all':
                             ban_list = []
                         elif uid_unban in ban_list:
                             ban_list.remove(uid_unban)
                         with open("banned.json", "w") as f: json.dump(ban_list, f)
                     

                    elif cmd == 'jel': # teamcode, [uid1, uid2...], emote
                         if len(cmd_data) < 3: continue
                         team_code = cmd_data[1]
                         emote_arg = cmd_data[-1]
                         target_uids = cmd_data[2:-1] 
                         
                         writer = online_writers.get(bot_uid)
                         if writer:
                             asyncio.create_task(jevo_operation_v2(team_code, target_uids, emote_arg, key, iv, region, writer))

                    elif cmd == 'jp': # teamcode, [uid1, uid2...], emote
                         if len(cmd_data) < 3: continue 
                         
                         team_code = cmd_data[1]
                         emote_arg = cmd_data[-1]
                         target_uids = cmd_data[2:-1]
                         
                         writer = online_writers.get(bot_uid)
                         if writer:
                             asyncio.create_task(jp_operation_v2(team_code, target_uids, emote_arg, key, iv, region, writer))

                    elif cmd == 'jrevo': # teamcode, [uid1, uid2...]
                         if len(cmd_data) < 2: continue
                         team_code = cmd_data[1]
                         target_uids = cmd_data[2:]
                         
                         writer = online_writers.get(bot_uid)
                         if writer:
                             asyncio.create_task(jrevo_operation_v2(team_code, target_uids, key, iv, region, writer))

                    elif cmd == 'jevo': # teamcode, [uid1, uid2...], emote
                         # Expected format: /jevo teamcode uid1 uid2 ... emote_num
                         if len(cmd_data) < 4:
                             # Not enough args
                             continue
                             
                         team_code = cmd_data[1]
                         emote = cmd_data[-1] # Last arg is emote
                         target_uids = cmd_data[2:-1] # Middle args are UIDs
                         
                         writer = online_writers.get(bot_uid)
                         
                         if writer:
                             # 1. Join
                             asyncio.create_task(run_one_time_start(team_code, bot_uid, chat_id, XX, key, iv, writer))
                             await asyncio.sleep(1.0)
                             
                             # 2. Emote logic
                             # Resolve Emote ID
                             emote_id = emote
                             if len(str(emote)) < 5:
                                 if str(emote) in EMOTE_MAP: emote_id = EMOTE_MAP[str(emote)]
                                 elif int(emote) in EMOTE_MAP: emote_id = EMOTE_MAP[int(emote)]

                             # Send Emote to ALL targets
                             print(f"DEBUG: Processing Emote Spam on UIDs: {target_uids} with Emote: {emote_id}")
                             for i in range(5):
                                  if whisper_writer:
                                      for t in target_uids:
                                          try:
                                              print(f"DEBUG: {i} Sending Emote {emote_id} to {t}")
                                              pkt = await Emote_k(int(t), int(emote_id), key, iv, region)
                                              await SEndPacKeT(whisper_writer, writer, 'OnLine', pkt)
                                          except Exception as e:
                                              print(f"DEBUG: Failed to send emote to {t}: {e}")
                                  await asyncio.sleep(0.1)

                             await asyncio.sleep(0.5)
                             
                             # 3. Leave
                             if whisper_writer:
                                 leave_pkt = await ExiT(None, key, iv)
                                 await SEndPacKeT(whisper_writer, writer, 'OnLine', leave_pkt)
                    


                    # --- NEW COMMANDS LOGIC ---
                    elif cmd == 'slots':
                        slots = int(cmd_data[1])
                        uid_target = 0
                        if len(cmd_data) > 2 and cmd_data[2]:
                             uid_target = int(cmd_data[2])

                        # Change slots using cHSq with logic matching /inv and TcPChaT /5
                        if whisper_writer and online_writer:
                             # Determine which UID to use (Target or Self)
                             # Matches /inv logic (uses target) and TcPChaT /5 logic (uses self)
                             packet_uid = uid_target if uid_target else int(bot_uid)
                             
                             # 1. Open Squad State
                             open_pkt = await OpEnSq(key, iv, region)
                             await SEndPacKeT(whisper_writer, online_writer, 'OnLine', open_pkt)
                             await asyncio.sleep(0.3)
                             
                             # 2. Change Squad (cHSq)
                             pkt = await cHSq(slots, packet_uid, key, iv, region)
                             await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)
                             await asyncio.sleep(0.3)
                             
                             # 3. Send Invite (SEnd_InV)
                             # Even if no target (just changing slots), TcPChaT sends inv to self/packet_uid
                             inv_pkt = await SEnd_InV(slots, packet_uid, key, iv, region)
                             await SEndPacKeT(whisper_writer, online_writer, 'OnLine', inv_pkt)
                             
                             # 4. Schedule Leave after 12 seconds (Non-blocking)
                             async def _delayed_leave():
                                 await asyncio.sleep(12)
                                 try:
                                     exit_pkt = await ExiT(None, key, iv)
                                     if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', exit_pkt)
                                 except Exception as e: print(f"Delayed leave failed: {e}")
                             asyncio.create_task(_delayed_leave())



                    elif cmd == 'status':
                        target, chat_id_req = cmd_data[1], cmd_data[2]
                        # check_player_status returns (cache_data, status_msg)
                        cache_data, msg_or_fail = await check_player_status(target, key, iv)
                        
                        if cache_data:
                            status = cache_data.get('status', 'UNKNOWN')
                            
                            # Construct Detailed Message (Matching User Request)
                            status_msg = f"📊 *PLAYER STATUS*\n"
                            status_msg += "────────────────\n"
                            status_msg += f"👤 UID: `{target}`\n"
                            status_msg += f"📊 Status: `{status}`\n"
                            
                            if "IN ROOM" in status:
                                if 'room_id' in cache_data:
                                    status_msg += f"🏠 Room ID: `{cache_data['room_id']}`\n"
                                else:
                                    status_msg += "🏠 Room ID: Not available\n"
                            
                            elif "INSQUAD" in status:
                                if 'leader_id' in cache_data:
                                    status_msg += f"👑 Leader: `{cache_data['leader_id']}`\n"
                                
                                # Try to get squad size (simplified as dict structure is complex)
                                # Access cached parsed_json structure directly if available
                                if 'parsed_json' in cache_data:
                                    try:
                                        parsed = cache_data['parsed_json']
                                        # logic matches snippet
                                        if '5' in parsed and 'data' in parsed['5']:
                                            squad_data = parsed['5']['data']['1']['data']
                                            if '9' in squad_data and 'data' in squad_data['9']:
                                                members = squad_data['9']['data']
                                                max_members = squad_data['10']['data'] + 1
                                                status_msg += f"👥 Squad: {members}/{max_members}\n"
                                    except: pass

                            elif "SOLO" in status:
                                status_msg += "👤 Player is solo\n"
                            elif "OFFLINE" in status:
                                status_msg += "🔴 Player is offline\n"
                            elif "INGAME" in status:
                                status_msg += "🎮 Player is in a match\n"
                                
                            status_msg += "────────────────\n✅ Real-time data"
                            reply_text = status_msg
                        else:
                            reply_text = f"❌ *Status Failed for {target}*:\n{msg_or_fail}"
                            
                        if chat_id_req:
                             try:
                                  token_v = "8598370793:AAHx3xUAXPhPKkao9kftjIHk7f-vrlGNPco"
                                  url = f"https://api.telegram.org/bot{token_v}/sendMessage"
                                  requests.post(url, json={'chat_id': chat_id_req, 'text': reply_text, 'parse_mode': 'Markdown'})
                             except Exception as e:
                                  print(f"Failed to send TG status: {e}")












                    









                    elif cmd == 'look':
                        cmd_val = cmd_data[1] # b1, b2... or short code
                        # Map b1..b11 to bundle IDs
                        bundle_order = [
                            "rampage", "cannibal", "devil", "scorpio", "frostfire", 
                            "paradox", "naruto", "aurora", "midnight", "itachi", "dreamspace"
                        ]
                        bundle_ids = {
                            "rampage": 914000002, "cannibal": 914000003, "devil": 914038001,
                            "scorpio": 914039001, "frostfire": 914042001, "paradox": 914044001,
                            "naruto": 914047001, "aurora": 914047002, "midnight": 914048001,
                            "itachi": 914050001, "dreamspace": 914052001
                        }
                        # Convert b1 -> index 0?
                        # User implementation in Step 1427 used "look_num". 
                        # Handler sends "b1" (string). 
                        # Need to parse "b1" -> 1.
                        try:
                            # if cmd is "b1", look_num=1
                            look_num = int(cmd_val.replace('b', ''))
                            if 1 <= look_num <= len(bundle_order):
                                b_name = bundle_order[look_num-1]
                                b_id = bundle_ids.get(b_name)
                                if b_id and whisper_writer and online_writer:
                                    pkt = await bundle_packet_async(b_id, key, iv, region)
                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)
                        except: pass
    




                    elif cmd == 'spam_req': # sm, s1..s5
                        subcmd, target = cmd_data[1], cmd_data[2]
                        target_int = int(target)
                        
                        # Logic matching ff folder (badge_spam_worker)
                        if BADGE_SPAM_TASK and not BADGE_SPAM_TASK.done(): BADGE_SPAM_TASK.cancel()
                        
                        mode = 'mixed' if subcmd == 'sm' else 'fixed'
                        base_badge = BADGE_VALUES.get(subcmd, 0)
                        
                        # Pass None for chat_type to avoid in-game feedback spam from Telegram command
                        BADGE_SPAM_TASK = asyncio.create_task(
                            badge_spam_worker(mode, target_int, base_badge, uid, chat_id, key, iv, region, None)
                        )

                    elif cmd == 'ssm':
                         if BADGE_SPAM_TASK: BADGE_SPAM_TASK.cancel()

                    elif cmd == 'spm':
                         target = cmd_data[1]
                         # Use global spam_request_loop logic (parity with in-game)
                         if spam_request_task and not spam_request_task.done():
                             spam_request_running = False
                             spam_request_task.cancel()
                             await asyncio.sleep(0.5)
                         
                         spam_request_running = True
                         spam_request_task = asyncio.create_task(spam_request_loop(target, key, iv, region))

                    elif cmd == 'sspm':
                         spam_request_running = False
                         if spam_request_task: spam_request_task.cancel()

                    elif cmd == 'room':
                         target = cmd_data[1]
                         tg_chat_id = cmd_data[2] if len(cmd_data) > 2 else None
                         
                         # Must find room_id
                         try:
                             # Check status to get room ID
                             status_res, _ = await check_player_status(target, key, iv)
                             r_id = None
                             status_text = "UNKNOWN"
                             
                             if status_res and status_res.get('packet'):
                                 r_id = get_idroom_by_idplayer(status_res.get('packet'))
                                 status_text = get_player_status(status_res.get('packet')) or "UNKNOWN"
                             
                             # Strict check: Must be IN ROOM
                             if r_id and "IN ROOM" in status_text:
                                 room_spam_task = asyncio.create_task(room_spam_worker(target, r_id, key, iv, whisper_writer, None, None, None))
                                 
                                 success_msg = f"""room spam started 🕵️
Extracted Player ID: {target}
📊 Extracted Status: {status_text}
🏠 Room ID extracted: {r_id}"""
                                 if tg_chat_id:
                                     bot.send_message(tg_chat_id, success_msg)
                                 
                                 print(f"/room spam started on {target} in room {r_id}")
                             else:
                                 err_msg = f"""👤 Player: {target}
❌ Not in custom room"""
                                 if tg_chat_id:
                                     bot.send_message(tg_chat_id, err_msg)
                                 
                                 # Also send to game if possible (optional, but good for debugging)
                                 # if chat_id:
                                 #      await safe_send_message(XX, err_msg, bot_uid, chat_id, key, iv)
                                 print(f"❌ /room failed: {target} not in room")
                         except Exception as e:
                             print(f"/room error: {e}")

                    elif cmd == 'sroom':
                         if room_spam_task: room_spam_task.cancel()

                    elif cmd == 'lag':
                         team = cmd_data[1]
                         lag_task = asyncio.create_task(lag_team_loop(team, key, iv, region))

                    elif cmd == 'slag':
                         if lag_task: lag_task.cancel()


                except Exception as e:
                    print(f"Error processing cmd: {e}")

        except Exception as e:
            pass # Queue empty

        await asyncio.sleep(2)

async def join_equip_ready(team_code, key, iv, sender_uid=None, region='ind', bot_uid=None):
    # 1. Join
    try:
        join_pkt = await GenJoinSquadsPacket(team_code, key, iv)
        if online_writer:
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_pkt)
            print(f"✅ Joined team {team_code}")
    except Exception as e:
        print(f"❌ Join Error: {e}")
    
    await asyncio.sleep(1.0)
    
    # 2. Equip Random Bundle
    try:
        # Define bundles locally
        bundle_ids = {
            "rampage": 914000002, "cannibal": 914000003, "devil": 914038001,
            "scorpio": 914039001, "frostfire": 914042001, "paradox": 914044001,
            "naruto": 914047001, "aurora": 914047002, "midnight": 914048001,
            "itachi": 914050001, "dreamspace": 914052001
        }
        random_name, random_id = random.choice(list(bundle_ids.items()))
        
        bundle_pkt = await bundle_packet_async(random_id, key, iv, region)
        if online_writer:
            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', bundle_pkt)
            print(f"🎁 Auto-Equipped: {random_name}")
    except Exception as e:
        print(f"⚠️ Bundle Equip Error: {e}")

    await asyncio.sleep(2.0)

    # 3. Dual Rings Emote (Moved to after Equip)
    if sender_uid:
        try:
            rings_id = 909050009
            # Send to Sender
            pkt = await Emote_k(int(sender_uid), rings_id, key, iv, region)
            if online_writer: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)
            print(f"💍 Dual Rings with {sender_uid}")
        except Exception as e:
            print(f"❌ Emote Error: {e}")
            
    await asyncio.sleep(0.5)

    await asyncio.sleep(0.5)
    
    # 3. Ready / Start - REMOVED per user request
    # try:
    #     start_pkt = await GenLevelStartPacket(key, iv)
    #     if online_writer:
    #         await SEndPacKeT(whisper_writer, online_writer, 'OnLine', start_pkt)
    #         print(f"✅ Auto-Ready Sent")
    # except Exception as e:
    #     print(f"❌ Ready Error: {e}")

async def TcPChaT(ip, port, AutHToKen, key, iv, LoGinDaTaUncRypTinG, ready_event, region, bot_uid, bot_password, cmd_queue=None, reconnect_delay=0.5):
    print(region, 'TCP CHAT')

    global spam_room , whisper_writer , spammer_uid , spam_chat_id , spam_uid , online_writer , chat_id , XX , uid , Spy,data2, Chat_Leave, fast_spam_running, fast_spam_task, custom_spam_running, custom_spam_task, spam_request_running, spam_request_task, evo_fast_spam_running, evo_fast_spam_task, evo_custom_spam_running, evo_custom_spam_task, lag_running, lag_task, current_group_members, is_muted, mute_until, MAX_TASK, SMAX_STOP, RND_TASK, BADGE_SPAM_STOP, BADGE_SPAM_TASK, reject_spam_running, reject_spam_task, level_running, level_task
    while True:
        try:
            reader , writer = await asyncio.open_connection(ip, int(port))
            whisper_writer = writer
            bytes_payload = bytes.fromhex(AutHToKen)
            whisper_writer.write(bytes_payload)
            await whisper_writer.drain()
            ready_event.set()
            # Start Command Listener Task
            if cmd_queue:
                 asyncio.create_task(telegram_cmd_listener(cmd_queue, key, iv, region, bot_uid, bot_password, LoGinDaTaUncRypTinG.Clan_ID, join_equip_ready))
            if LoGinDaTaUncRypTinG.Clan_ID:
                clan_id = LoGinDaTaUncRypTinG.Clan_ID
                clan_compiled_data = LoGinDaTaUncRypTinG.Clan_Compiled_Data
                print('\n - TarGeT BoT in CLan ! ')
                print(f' - Clan Uid > {clan_id}')
                print(f' - BoT ConnEcTed WiTh CLan ChaT SuccEssFuLy ! ')
                pK = await AuthClan(clan_id , clan_compiled_data , key , iv)
                if whisper_writer: whisper_writer.write(pK) ; await whisper_writer.drain()
            while True:
                data = await reader.read(9999)
                if not data: break
                if "1200" in data.hex()[0:4]:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        try:
                            room_uid = parsed_data["5"]["data"]["1"]["data"]
                        except KeyError:
                            logging.warning("Warning: '1' key is missing in parsed_data, skipping...")
                            room_uid = None
                    except Exception as e:
                        logging.error(f"Error processing room packet: {e}")
        
                if data.hex().startswith("120000"):
                    try:
                        response = await DecodeWhisperMessage(data.hex()[10:])
                        uid = response.Data.uid
                        chat_id = response.Data.Chat_ID
                        XX = response.Data.chat_type
                        inPuTMsG = response.Data.msg.lower()
        
        # Debug print to see what we're receiving
                        print(f"Received message: {inPuTMsG} from UID: {uid} in chat type: {XX}")
        
                    except:
                        response = None


                    if response:

                        # ALL COMMANDS NOW WORK IN ALL CHAT TYPES (SQUAD, GUILD, PRIVATE)
                        

                        # ============================
                        # ADMIN COMMANDS (enhanced and shortened)
                        # ============================


                        # ============================
                        # BAN SYSTEM CHECK
                        # ============================
                        if is_banned(uid) and not is_admin(uid):
                            if inPuTMsG.startswith('/'):
                                # Notify the user they are banned
                                msg = "[B][C][FF0000]🚫 Your account has been blocked. Please contact the administrator."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                print(f"Ignored command from banned UID: {uid}")
                            continue

                        # ============================
                        # MUTE SYSTEM CHECK
                        # ============================
                        if is_bot_muted() and not is_admin(uid):
                            if inPuTMsG.startswith('/'):
                                print(f"🔇 Ignored command from {uid} (Bot Muted)")
                            continue

                        # ============================
                        # ADMIN COMMANDS (enhanced and shortened)
                        # ============================

                        # ============================
                        # OWNER COMMANDS
                        # ============================


                        # /bundle command
                        if inPuTMsG.strip().startswith('/bundle'):
                            print('Processing bundle command')
    
                            parts = inPuTMsG.strip().split()
                            
                            if len(parts) < 2:
                             
                                bundle_list = """[B][C][FFFFFF]• rampage 
[FFFFFF]• cannibal 
[FFFFFF]• devil 
[FFFFFF]• scorpio 
[FFFFFF]• frostfire
[FFFFFF]• paradox 
[FFFFFF]• naruto 
[FFFFFF]• aurora 
[FFFFFF]• midnight 
[FFFFFF]• itachi 
[FFFFFF]• dreamspace
"""
                                await safe_send_message(response.Data.chat_type, bundle_list, uid, chat_id, key, iv)
                            else:
                                bundle_name = parts[1].lower()
                          
      
                                # Bundle IDs mapping
                                bundle_ids = {
                                    "rampage": 914000002,
                                    "cannibal": 914000003,
                                    "devil": 914038001,
                                    "scorpio": 914039001,
                                    "frostfire": 914042001,
                                    "paradox": 914044001,
                                    "naruto": 914047001,
                                    "aurora": 914047002,
                                    "midnight": 914048001,
                                    "itachi": 914050001,
                                    "dreamspace": 914051001
                                }
                                
                             
                                if bundle_name not in bundle_ids:
                                    error_msg = f"""[B][C][FF0000]❌ Bundle '{bundle_name}' not found!

[00FF00]Available bundles:
[FFFFFF]• rampage • cannibal • devil
[FFFFFF]• scorpio • frostfire • paradox
[FFFFFF]• naruto • aurora • midnight
[FFFFFF]• itachi • dreamspace

[00FF00]Use: /bundle [name]"""
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    return
                                    
                                bundle_id = bundle_ids[bundle_name]

                                   
                       
                  
                                initial_msg = f"[B][C][00FF00]🎁 Sending {bundle_name} bundle...\nID: {bundle_id}\n"
                                await safe_send_message(response.Data.chat_type, initial_msg, uid, chat_id, key, iv)
        
                                try:
                                
                                    bundle_packet = await bundle_packet_async(bundle_id, key, iv)
            
                                    if bundle_packet and online_writer:
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', bundle_packet)
                                        success_msg = f"[B][C][00FF00]✅ BUNDLE SENT SUCCESSFULLY!\n🎁 Name: {bundle_name}\n🆔 ID: {bundle_id}\n👤 Target: {uid}"
                                        await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                    else:
                                        error_msg = f"[B][C][FF0000]❌ Failed to create bundle packet!\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                
                                except Exception as e:
                                    error_msg = f"[B][C][FF0000]❌ Error sending bundle: {str(e)[:50]}\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # /oldbundle command - Sends generic ID for any name (Legacy Support)
                        if inPuTMsG.strip().startswith('/oldbundle '):
                            print('Processing old bundle command')
    
                            parts = inPuTMsG.strip().split()
                            
                            if len(parts) >= 2:
                                bundle_name = parts[1].lower()
        
                                # Old Logic: All bundles use the same ID
                                bundle_id = 914051001
        
                                initial_msg = f"[B][C][00FF00]🎁 Sending {bundle_name.upper()} bundle (Universal ID)...\nID: {bundle_id}\n"
                                await safe_send_message(response.Data.chat_type, initial_msg, uid, chat_id, key, iv)
        
                                try:
                                    # Create bundle packet
                                    bundle_packet = await bundle_packet_async(bundle_id, key, iv, region)
            
                                    if bundle_packet and online_writer:
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', bundle_packet)
                                        success_msg = f"[B][C][00FF00]✅ BUNDLE SENT SUCCESSFULLY!\n🎁 Name: {bundle_name.upper()}\n🆔 ID: {bundle_id} (Universal)"
                                        await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                    else:
                                        error_msg = f"[B][C][FF0000]❌ Failed to create bundle packet!\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                
                                except Exception as e:
                                    error_msg = f"[B][C][FF0000]❌ Error sending bundle: {str(e)[:50]}\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # /b1 - /b11 shortcut commands
                        if inPuTMsG.strip().startswith('/b') and inPuTMsG.strip()[2:].isdigit():
                            try:
                                cmd_parts = inPuTMsG.strip().split()
                                cmd = cmd_parts[0] # e.g. /b1
                                number = int(cmd[2:]) # Extract number after /b
                                
                                # Define mapping list (order matters!)
                                bundle_order = [
                                    "rampage", "cannibal", "devil", "scorpio", "frostfire", 
                                    "paradox", "naruto", "aurora", "midnight", "itachi", "dreamspace"
                                ]
                                
                                # Bundle IDs mapping (must match /bundle command)
                                bundle_ids = {
                                    "rampage": 914000002,
                                    "cannibal": 914000003,
                                    "devil": 914038001,
                                    "scorpio": 914039001,
                                    "frostfire": 914042001,
                                    "paradox": 914044001,
                                    "naruto": 914047001,
                                    "aurora": 914047002,
                                    "midnight": 914048001,
                                    "itachi": 914050001,
                                    "dreamspace": 914051001
                                }

                                if 1 <= number <= len(bundle_order):
                                    bundle_name = bundle_order[number-1]
                                    bundle_id = bundle_ids[bundle_name]
                                    
                                    # Send the bundle (same logic as /bundle)
                                    initial_msg = f"[B][C][00FF00]🎁 Sending {bundle_name} bundle...\n"
                                    await safe_send_message(response.Data.chat_type, initial_msg, uid, chat_id, key, iv)
            
                                    try:
                                        bundle_packet = await bundle_packet_async(bundle_id, key, iv)
                
                                        if bundle_packet and online_writer:
                                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', bundle_packet)
                                            success_msg = f"[B][C][00FF00]✅ BUNDLE SENT SUCCESSFULLY!\n🎁 Name: {bundle_name}\n"
                                            await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                        else:
                                            error_msg = f"[B][C][FF0000]❌ Failed to create bundle packet!\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                    
                                    except Exception as e:
                                        error_msg = f"[B][C][FF0000]❌ Error sending bundle: {str(e)[:50]}\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    # Invalid number (Optional: only reply if it looks like a user error, or ignore to avoid spam)
                                    pass 
                                    
                            except ValueError:
                                pass # Not a valid number format

                        if inPuTMsG.strip().startswith('/gj '):
                            if is_admin(uid):
                                parts = inPuTMsG.strip().split()
                                if len(parts) < 2:
                                    await safe_send_message(response.Data.chat_type, '[B][C][FF0000]Usage: /gj [guild_id]', uid, chat_id, key, iv)
                                else:
                                    target_gid = parts[1]
                                    await safe_send_message(response.Data.chat_type, '[B][C][FFFF00] Guild Joining...', uid, chat_id, key, iv)
                                    
                                    loop = asyncio.get_event_loop()
                                    with ThreadPoolExecutor() as executor:
                                        res = await loop.run_in_executor(executor, api_join_guild, bot_uid, bot_password, target_gid)

                                    await safe_send_message(response.Data.chat_type, res, uid, chat_id, key, iv)
                            else:
                                await safe_send_message(response.Data.chat_type, '[B][C][FF0000] ADMIN ONLY COMMAND!', uid, chat_id, key, iv)

                        if inPuTMsG.strip().startswith('/gl'):
                            if is_admin(uid):
                                parts = inPuTMsG.strip().split()
                                
                                target_gid = None
                                if len(parts) > 1:
                                    target_gid = parts[1]
                                elif LoGinDaTaUncRypTinG.Clan_ID:
                                    target_gid = LoGinDaTaUncRypTinG.Clan_ID
                                
                                if target_gid:
                                    await safe_send_message(response.Data.chat_type, f'[B][C][FFFF00] Leaving Guild {fix_num(target_gid)}', uid, chat_id, key, iv)
                                    
                                    loop = asyncio.get_event_loop()
                                    with ThreadPoolExecutor() as executor:
                                        res = await loop.run_in_executor(executor, api_leave_guild, bot_uid, bot_password, target_gid)

                                    await safe_send_message(response.Data.chat_type, res, uid, chat_id, key, iv)
                                else:
                                     await safe_send_message(response.Data.chat_type, '[B][C][FF0000] Error: Use /gl [guild_id] or ensure bot is in a guild.', uid, chat_id, key, iv)
                            else:
                                await safe_send_message(response.Data.chat_type, '[B][C][FF0000] ADMIN ONLY COMMAND!', uid, chat_id, key, iv)

                        # NEW EVO_CUSTOM COMMAND
                        if inPuTMsG.strip().startswith('/evo_c '):
                            print('Processing evo_c command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 3:
                                error_msg = f"[B][C][FF0000]❌ ERROR! Usage: /evo_c uid1 [uid2] [uid3] [uid4] number(1-21) time(1-100)\nExample: /evo_c 123456789 1 10\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                # Parse uids, number, and time
                                uids = []
                                number = None
                                time_val = None
                                
                                for part in parts[1:]:
                                    if part.isdigit():
                                        if len(part) <= 2:  # Number or time should be 1-100 (1, 2, or 3 digits)
                                            if number is None:
                                                number = part
                                            elif time_val is None:
                                                time_val = part
                                            else:
                                                uids.append(part)
                                        else:
                                            uids.append(part)
                                    else:
                                        break
                                
                                # If we still don't have time_val, try to get it from the last part
                                if not time_val and len(parts) >= 3:
                                    last_part = parts[-1]
                                    if last_part.isdigit() and len(last_part) <= 3:
                                        time_val = last_part
                                        # Remove time_val from uids if it was added by mistake
                                        if time_val in uids:
                                            uids.remove(time_val)
                                
                                if not uids or not number or not time_val:
                                    error_msg = f"[B][C][FF0000]❌ ERROR! Invalid format! Usage: /evo_c uid1 [uid2] [uid3] [uid4] number(1-21) time(1-100)\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    try:
                                        number_int = int(number)
                                        time_int = int(time_val)
                                        
                                        if number_int not in EMOTE_MAP:
                                            error_msg = f"[B][C][FF0000]❌ ERROR! Number must be between 1-21 only!\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                        elif time_int < 1 or time_int > 100:
                                            error_msg = f"[B][C][FF0000]❌ ERROR! Time must be between 1-100 only!\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                        else:
                                            # Stop any existing evo_custom spam
                                            if evo_custom_spam_task and not evo_custom_spam_task.done():
                                                evo_custom_spam_running = False
                                                evo_custom_spam_task.cancel()
                                                await asyncio.sleep(0.5)
                                            
                                            # Start new evo_custom spam
                                            evo_custom_spam_running = True
                                            evo_custom_spam_task = asyncio.create_task(evo_custom_emote_spam(uids, number_int, time_int, key, iv, region))
                                            
                                            # SUCCESS MESSAGE
                                            emote_id = EMOTE_MAP[number_int]
                                            success_msg = f"[B][C][00FF00]✅ SUCCESS! Custom evolution emote spam started!\nTargets: {len(uids)} players\nEmote: {number_int} (ID: {emote_id})\nRepeat: {time_int} times\nInterval: 0.1 seconds\n"
                                            await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                            
                                    except ValueError:
                                        error_msg = f"[B][C][FF0000]❌ ERROR! Invalid number/time format! Use numbers only.\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # /add command

                        if inPuTMsG.startswith('/add') and str(uid) in OWNER_UIDS:
                            parts = inPuTMsG.split()
                            if len(parts) >= 2:
                                target_add = parts[1]
                                if add_admin(target_add):
                                    msg = f"[B][C][00FF00]✅ User {fix_num(target_add)} is now an Admin!"
                                else:
                                    msg = f"[B][C][FFFF00]⚠ User {fix_num(target_add)} is already an Admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                            else:
                                msg = "[B][C][FF0000]❌ Usage: /add <uid>"
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /remove command
                        elif inPuTMsG.startswith('/remove') and str(uid) in OWNER_UIDS:
                            parts = inPuTMsG.split()
                            if len(parts) >= 2:
                                target_remove = parts[1]
                                if remove_admin(target_remove):
                                     msg = f"[B][C][00FF00]✅ User {fix_num(target_remove)} removed from Admin!"
                                else:
                                     msg = f"[B][C][FFFF00]⚠ User {fix_num(target_remove)} is not an Admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                            else:
                                msg = "[B][C][FF0000]❌ Usage: /remove <uid>"
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /admin list command
                        elif inPuTMsG == '/admin list' and str(uid) in OWNER_UIDS:
                            if admin_uids:
                                formatted_list = [fix_num(aid) for aid in admin_uids]
                                msg = f"[B][C][00FF00]👑 Admin List:\n[FFFFFF]" + "\n".join(formatted_list)
                            else:
                                msg = "[B][C][00FF00]✅ No additional admins."
                            await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /restart command
                        elif inPuTMsG == '/restart':
                            if is_admin(uid):
                                msg = "[B][C][00FF00]🔄 Restarting all bots..."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                
                                # Create restart flag
                                with open("restart_flag", "w") as f:
                                    f.write("restart")
                                
                                print("🔄 Restart command received. Stopping all bots...")
                                
                                # Kill all other bot processes (siblings) so parent loop finishes
                                try:
                                    current_process = psutil.Process()
                                    parent = current_process.parent()
                                    for child in parent.children(recursive=False):
                                        if child.pid != current_process.pid:
                                            try:
                                                child.terminate()
                                            except:
                                                pass
                                except Exception as e:
                                    print(f"Error stopping siblings: {e}")

                                # Kill self to finish the last join() in parent
                                sys.exit(0)
                            else:
                                msg = "[B][C][FF0000]🚫 You are not an admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)


                        # /ban command
                        if inPuTMsG.startswith('/ban'):
                            if is_admin(uid):
                                parts = inPuTMsG.split()
                                if len(parts) >= 2:
                                    if parts[1].lower() == 'list':
                                        # Show list
                                        if banned_uids:
                                            # Apply fix_num to each UID for display
                                            formatted_list = [fix_num(uid) for uid in banned_uids]
                                            msg = f"[B][C][FF0000]🚫 Banned Players:\n[FFFFFF]" + "\n".join(formatted_list)
                                        else:
                                            msg = "[B][C][00FF00]✅ No banned players."
                                        await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                    else:
                                        # Ban UID
                                        target_ban = parts[1]
                                        if ban_player(target_ban):
                                            msg = f"[B][C][FF0000]🚫 Player {fix_num(target_ban)} has been BANNED!"
                                        else:
                                            msg = f"[B][C][FFFF00]⚠ Player {fix_num(target_ban)} is already banned."
                                        await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                else: 
                                    msg = "[B][C][FF0000]❌ Usage: /ban <uid>"
                                    await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                            else:
                                msg = "[B][C][FF0000]🚫 You are not an admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /unban command
                        elif inPuTMsG.startswith('/unban'):
                            if is_admin(uid):
                                parts = inPuTMsG.split()
                                if len(parts) >= 2:
                                    if parts[1].lower() == 'all':
                                        unban_all_players()
                                        msg = "[B][C][00FF00]✅ All players have been UNBANNED!"
                                        await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                    else:
                                        target_unban = parts[1]
                                        if unban_player(target_unban):
                                            msg = f"[B][C][00FF00]✅ Player {fix_num(target_unban)} has been UNBANNED!"
                                        else:
                                            msg = f"[B][C][FFFF00]⚠ Player {fix_num(target_unban)} is not in the ban list."
                                        await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                else:
                                    msg = "[B][C][FF0000]❌ Usage: /unban <uid>"
                                    await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                            else:
                                msg = "[B][C][FF0000]🚫 You are not an admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /stop  -> kill process
                        if inPuTMsG.startswith('/stop'):
                            if is_admin(uid):
                                stop_msg = f"[FF0000]TCP TOM BOT stopping..."
                                await safe_send_message(response.Data.chat_type, stop_msg, uid, chat_id, key, iv)
                                os._exit(0)
                            else:
                                msg = "[B][C][FF0000]🚫 You are not an admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /mute 30s /mute 5m /mute 1h /mute 10  (10 = 10m)
                        elif inPuTMsG.startswith('/mute'):
                            if is_admin(uid):
                                try:
                                    parts = inPuTMsG.split()
                                    if len(parts) >= 2:
                                        time_str = parts[1]
                                        if time_str.endswith('s'):
                                            duration = int(time_str[:-1])
                                        elif time_str.endswith('m'):
                                            duration = int(time_str[:-1]) * 60
                                        elif time_str.endswith('h'):
                                            duration = int(time_str[:-1]) * 3600
                                        else:
                                            # default: treat as minutes
                                            duration = int(time_str) * 60

                                        is_muted = True
                                        mute_until = time.time() + duration
                                        mute_msg = f"[FFB300]TOM BOT muted {time_str}"
                                    else:
                                        mute_msg = f"[FF0000]Usage: /mute 30s/5m/1h"

                                    await safe_send_message(response.Data.chat_type, mute_msg, uid, chat_id, key, iv)
                                except Exception:
                                    error_msg = f"[FF0000]Invalid time format"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                msg = "[B][C][FF0000]🚫 You are not an admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /unmute
                        elif inPuTMsG.startswith('/unmute'):
                            if is_admin(uid):
                                is_muted = False
                                mute_until = 0
                                unmute_msg = f"[00FF00]TOM BOT unmuted"
                                await safe_send_message(response.Data.chat_type, unmute_msg, uid, chat_id, key, iv)
                            else:
                                msg = "[B][C][FF0000]🚫 You are not an admin."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # ============================
                        # If bot is muted: ignore all commands from non-admins
                        # ============================
                        if is_bot_muted() and not is_admin(uid) and inPuTMsG.startswith('/'):
                            initial_message = f"[B][C]Bot muted, ignoring command"
                            await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                            print(f"Bot muted, ignoring command from {uid}: {inPuTMsG}")
                            continue

                        # ALL COMMANDS NOW WORK IN ALL CHAT TYPES (SQUAD, GUILD, PRIVATE)
                        
                        # AI Command - /ai
#                         if inPuTMsG.strip().startswith('/ai '):
#                             print('Processing AI command in any chat type')
                            
#                             question = inPuTMsG[4:].strip()
#                             if question:
#                                 initial_message = f"[B][C]{get_random_color()}\n🤖 AI is thinking...\n"
#                                 await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                
#                                 # Use ThreadPoolExecutor to avoid blocking the async loop
#                                 loop = asyncio.get_event_loop()
#                                 with ThreadPoolExecutor() as executor:
#                                     ai_response = await loop.run_in_executor(executor, talk_with_ai, question)
                                
#                                 # Format the AI response
#                                 ai_message = f"""
# [B][C][00FF00]🤖 AI Response:

# [FFFFFF]{ai_response}

# [C][B][FFB300]Question: [FFFFFF]{question}
# """
#                                 await safe_send_message(response.Data.chat_type, ai_message, uid, chat_id, key, iv)
#                             else:
#                                 error_msg = f"[B][C][FF0000]❌ ERROR! Please provide a question after /ai\nExample: /ai What is Free Fire?\n"
#                                 await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                #GET PLAYER BIO-/bio
                        if inPuTMsG.strip().startswith('/bio '):
                            print('Processing bio command in any chat type')

                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f"[B][C][FF0000]❌ ERROR! Usage: /bio <uid>\nExample: /bio 4368569733\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
                                initial_message = f"[B][C]{get_random_color()}\nFetching the player bio...\n"
                                await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)

                                # Use ThreadPoolExecutor to avoid blocking the async loop
                                loop = asyncio.get_event_loop()
                                with ThreadPoolExecutor() as executor:
                                    bio_result = await loop.run_in_executor(executor, get_player_bio, target_uid)

                                await safe_send_message(response.Data.chat_type, f"[B][C]{get_random_color()}\n{bio_result}", uid, chat_id, key, iv)

                        # Likes Command - /likes
                        if inPuTMsG.strip().startswith('/likes'):
                            print('Processing likes command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f"[B][C][FF0000]❌ ERROR! Usage: /likes (uid)\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
                                initial_message = f"[B][C]{get_random_color()}\nSending 100 likes to {fix_num(target_uid)}...\n"
                                await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                
                                # Use ThreadPoolExecutor to avoid blocking the async loop
                                loop = asyncio.get_event_loop()
                                with ThreadPoolExecutor() as executor:
                                    likes_result = await loop.run_in_executor(executor, send_likes, target_uid)
                                
                                await safe_send_message(response.Data.chat_type, likes_result, uid, chat_id, key, iv)
                                
                                #TEAM SPAM MESSAGE COMMAND
                        if inPuTMsG.strip().startswith('/ms'):
                            print('Processing /ms command')

                            try:
                                parts = inPuTMsG.strip().split(maxsplit=1)

                                if len(parts) < 2:
                                    error_msg = (
                                        "[B][C][FF0000]❌ ERROR! Usage:\n"
                                        "/ms <message>\n"
                                        "Example: /ms TOM"
                                    )
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    user_message = parts[1].strip()

                                    for _ in range(30):
                                        color = get_random_color()  # random color from your list
                                        colored_message = f"[B][C]{color} {user_message}"  # correct format
                                        await safe_send_message(response.Data.chat_type, colored_message, uid, chat_id, key, iv)
                                        await asyncio.sleep(0.5)

                            except Exception as e:
                                error_msg = f"[B][C][FF0000]❌ ERROR! Something went wrong:\n{str(e)}"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                
                                #GALI SPAM MESSAGE 
            #             if inPuTMsG.strip().startswith('/bw '):
            #                 print('Processing /bw command')

            #                 try:
            #                     parts = inPuTMsG.strip().split(maxsplit=1)

            #                     if len(parts) < 2:
            #                         error_msg = (
            #                             "[B][C][FF0000]❌ ERROR! Usage:\n"
            #                             "/bw <name>\n"
            #                             "Example: /bw hater"
            #                         )
            #                         await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
            #                     else:
            #                         name = parts[1].strip()

            #                         messages = [
            #                             "{Name} TƐRI SƐXY BHEN KI CHXT ME ME L0DA DAAL KAR RAAT BHAR JOR JOR SE CH0DUNGA",
            #                             "{Name} MADHERXHOD TƐRI MÁÁ KI KALI G4ND MƐ LÀND MARU",
            #                             "{Name} TƐRI BHƐN KI TIGHT CHXT KO 5G KI SPEED SE CHÒD DU",
            #                             "{Name} TƐRI BEHEN KI CHXT ME L4ND MARU",
            #                             "{Name} TƐRI MÁÁ KI CHXT 360 BAR",
            #                             "{Name} TƐRI BƐHƐN KI CHXT 720 BAR",
            #                             "{Name} BEHEN KE L0DE",
            #                             "{Name} MADARCHXD",
            #                             "{Name} BETE TƐRA BAAP HUN ME",
            #                             "{Name} G4NDU APNE BAAP KO H8 DEGA",
            #                             "{Name} KI MÀÀ KI CHXT PER NIGHT 4000",
            #                             "{Name} KI BƐHƐN KI CHXT PER NIGHT 8000",
            #                             "{Name} R4NDI KE BACHHƐ APNE BAP KO H8 DEGA",
            #                             "INDIA KA NO-1 G4NDU {Name}",
            #                             "{Name} CHAPAL CH0R",
            #                             "{Name} TƐRI MÀÀ KO GB ROAD PE BETHA KE CHXDUNGA",
            #                             "{Name} BETA JHULA JHUL APNE BAAP KO MAT BHUL"
            # ]

            #                         # Send each message one by one with random color
            #                         for msg in messages:
            #                             colored_message = f"[B][C]{get_random_color()} {msg.replace('{Name}', name.upper())}"
            #                             await safe_send_message(response.Data.chat_type, colored_message, uid, chat_id, key, iv)
            #                             await asyncio.sleep(0.5)

            #                 except Exception as e:
            #                     error_msg = f"[B][C][FF0000]❌ ERROR! Something went wrong:\n{str(e)}"
            #                     await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                

                        # Add this with your other command handlers in the TcPChaT function
                        
                        # /auto command
                        if inPuTMsG.startswith('/auto'):
                            # Format: /auto123456
                            # Need to extract team code
                            try:
                                # Remove /auto (len 5) to get number
                                # But LEVELUP used: split_data[1].split(b'(')[0]...
                                # inPuTMsG is already decoded string.
                                # User might type /auto 123456 or /auto123456
                                # Let's try to find numbers.
                                
                                # Check if it has space
                                parts = inPuTMsG.strip().split()
                                if len(parts) >= 2:
                                     team_code = parts[1]
                                else:
                                     # Try to slice if connected
                                     team_code = inPuTMsG[5:].strip() # len('/auto') = 5
                                
                                if not team_code.isdigit():
                                     msg = f"[B][C][FF0000]Please provide a valid numeric team code.\nExample: /auto123456"
                                     await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                else:
                                     if level_running:
                                          msg = f"[B][C][00FFFF]Auto start already running. Use /sauto to stop."
                                          await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                     else:
                                          level_running = True
                                          level_task = asyncio.create_task(level_loop_task(team_code, uid, chat_id, response.Data.chat_type, key, iv, region))
                                          
                                          msg = f"[B][C][FFA500]Auto start enabled for team {team_code}.\nBot join → start → wait → leave → rejoin 24x7.\n{PROMO_TEXT}"
                                          await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                          
                            except Exception as e:
                                msg = f"[B][C][FF0000]Error in /auto: {e}"
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)

                        # /start command - One-time force start
                        if inPuTMsG.startswith('/start'):
                            try:
                                parts = inPuTMsG.strip().split()
                                if len(parts) >= 2:
                                     team_code = parts[1]
                                else:
                                     team_code = inPuTMsG[6:].strip() # len('/start') = 6
                                
                                if not team_code.isdigit():
                                     msg = f"[B][C][FF0000]Please provide a valid numeric team code.\nExample: /start123456"
                                     await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                else:
                                     msg = f"[B][C][FFA500]Force starting team {team_code} (1 time)...\n{PROMO_TEXT}"
                                     await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                                     
                                     # Run in background to avoid blocking processing
                                     asyncio.create_task(run_one_time_start(team_code, uid, chat_id, response.Data.chat_type, key, iv))
                                     
                            except Exception as e:
                                msg = f"[B][C][FF0000]Error in /start: {e}"
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)


                        # /sauto command
                        if inPuTMsG.startswith('/sauto'):
                            if not level_running:
                                msg = f"[B][C][FF0000]Auto start is not running."
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                            else:
                                level_running = False
                                if level_task:
                                    level_task.cancel()
                                    level_task = None
                                msg = f"[B][C][00FF00]Auto start stopped.\n{PROMO_TEXT}"
                                await safe_send_message(response.Data.chat_type, msg, uid, chat_id, key, iv)
                        if inPuTMsG.strip().startswith('/multijoin'):
                            print('Processing multi-account join request')
    
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f"[B][C][FF0000]❌ Usage: /multijoin (target_uid)\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
        
                                if not target_uid.isdigit():
                                    error_msg = f"[B][C][FF0000]❌ Please write a valid player ID!\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    return
        
                                initial_msg = f"[B][C][00FF00]🚀 Starting multi-join attack on {target_uid}...\n"
                                await safe_send_message(response.Data.chat_type, initial_msg, uid, chat_id, key, iv)
        
                                try:
                                    # Try the fake multi-account method (more reliable)
                                    success_count, total_attempts = await real_multi_account_join(target_uid, key, iv, region)
            
                                    if success_count > 0:
                                        result_msg = f"""
[B][C][00FF00]✅ MULTI-JOIN ATTACK COMPLETED!

🎯 Target: {target_uid}
✅ Successful Requests: {success_count}
📊 Total Attempts: {total_attempts}
⚡ Different squad variations sent!

💡 Check your game for join requests!
"""
                                    else:
                                        result_msg = f"[B][C][FF0000]❌ All join requests failed! Check bot connection.\n"
            
                                    await safe_send_message(response.Data.chat_type, result_msg, uid, chat_id, key, iv)
            
                                except Exception as e:
                                    error_msg = f"[B][C][FF0000]❌ Multi-join error: {str(e)}\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

           
                        if inPuTMsG.strip().startswith('/fastmultijoin'):
                            print('Processing fast multi-account join spam')
    
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f"[B][C][FF0000]❌ ERROR! Usage: /fastmultijoin (uid)\nExample: /fastmultijoin 123456789\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
        
                                # Load accounts
                                accounts_data = load_accounts()
                                if not accounts_data:
                                    error_msg = f"[B][C][FF0000]❌ ERROR! No accounts found!\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    return
                                
                                initial_msg = f"[B][C][00FF00]⚡ FAST MULTI-ACCOUNT JOIN SPAM!\n🎯 Target: {target_uid}\n👥 Accounts: {len(accounts_data)}\n"
                                await safe_send_message(response.Data.chat_type, initial_msg, uid, chat_id, key, iv)
        
                                try:
                                    join_count = 0
                                    # Send join requests rapidly from all accounts
                                    for uid, password in accounts_data.items():
                                        try:
                                            # Use your existing join request function
                                            join_packet = await SEnd_InV(5, int(target_uid), key, iv, region)
                                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_packet)
                                            join_count += 1
                                            print(f"✅ Fast join from account {uid}")
                    
                                            # Very short delay
                                            await asyncio.sleep(0.1)
                    
                                        except Exception as e:
                                            print(f"❌ Fast join failed for {uid}: {e}")
                                            continue
            
                                    success_msg = f"[B][C][00FF00]✅ FAST MULTI-JOIN COMPLETED!\n🎯 Target: {target_uid}\n✅ Successful: {join_count}/{len(accounts_data)}\n⚡ Speed: Ultra fast\n"
                                    await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
            
                                except Exception as e:
                                    error_msg = f"[B][C][FF0000]❌ ERROR in fast multi-join: {str(e)}\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        if inPuTMsG.strip().startswith('/title'):
                            # Process /title command in any chat type
                            parts = inPuTMsG.strip().split()
    
                            # Check if bot is in a team
              
                            # initial_message = f"[B][C]{get_random_color()}\nSending title to current team...\n"
                            # await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
    
                            try:
                                # Send title packet
                                title_packet = await send_title_msg(chat_id, key, iv)
                                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', title_packet)
        
                                # SUCCESS MESSAGE
                                # success_message = f"[B][C][00FF00]✅ SUCCESS! Title sent to current team!\n"
                                # await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)
        
                            except Exception as e:
                                print(f"Title send failed: {e}")
                                error_msg = f"[B][C][FF0000]❌ ERROR! Failed to send title: {str(e)}\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

#####################################################
                        # Update the command handler
                        if inPuTMsG.strip().startswith('/rej'):
                            print('Processing reject spam command in any chat type')
    
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f"[B][C][FF0000]❌ ERROR! Usage: /reject (target_uid)\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
        
                                # Stop any existing reject spam
                                if reject_spam_task and not reject_spam_task.done():
                                    reject_spam_running = False
                                    reject_spam_task.cancel()
                                    await asyncio.sleep(0.5)
        
                                # Add to blocked list
                                REJECT_BLOCKED_UIDS.add(str(target_uid))

                                # Send start message
                                start_msg = f"[B][C][1E90FF]🌀 Started Reject Spam on {fix_num(target_uid)} (Invites blocked)"
                                await safe_send_message(response.Data.chat_type, start_msg, uid, chat_id, key, iv)
        
                                # Start reject spam in background
                                reject_spam_running = True
                                reject_spam_task = asyncio.create_task(reject_spam_loop(target_uid, key, iv, region))
        
                                # Wait for completion in background and send completion message
                                asyncio.create_task(handle_reject_completion(reject_spam_task, target_uid, uid, chat_id, response.Data.chat_type, key, iv))


                        if inPuTMsG.strip() == '/srej':
                            if reject_spam_task and not reject_spam_task.done():
                                reject_spam_running = False
                                reject_spam_task.cancel()
                                stop_msg = f"[B][C][00FF00]✅ Reject spam stopped successfully!\n"
                                await safe_send_message(response.Data.chat_type, stop_msg, uid, chat_id, key, iv)
                            else:
                                error_msg = f"[B][C][FF0000]❌ No active reject spam to stop!\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
#######################################################

                        # ============================
                        # (Rest of your commands below stay the same)
                        # ============================
                        # UPDATED DANCE COMMAND - Now requires UIDs
                        if inPuTMsG.strip().startswith('/rnd'):

                            print('Processing dance command with UIDs in any chat type')
    
    # if already running, don't start again
                            if RND_TASK is not None and not RND_TASK.done():
                                already_msg = " [C][FF0000]❌ /rnd already running! Use /srnd to stop.\n"
                                await safe_send_message(response.Data.chat_type, already_msg, uid, chat_id, key, iv)
                            else:
                                parts = inPuTMsG.strip().split()
                                if len(parts) < 2:
                                    error_msg = " [C][FF0000]❌ ERROR! Usage: /rnd [uid1] [uid2] [uid3] [uid4]"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
            # Parse UIDs from command
                                    uids = []
                                    for part in parts[1:]:
                                        if part.isdigit() and len(part) > 3:  # UIDs should be longer than 3 digits
                                            uids.append(part)
            
                                    if not uids:
                                        error_msg = " [C][FF0000]❌ ERROR! No valid UIDs provided! Usage: /rnd uid1 [uid2] [uid3] [uid4]\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    else:
                                        total_time = 21 * 2.5  # 21 emotes × 2.5 seconds (just info)
                                        initial_message = f" [C]{get_random_color()}\n🎉 Starting ULTIMATE dance party with ALL 21 evolution emotes"
                                        await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                
                # IMPORTANT: run in background, DO NOT await here
                                        RND_TASK = asyncio.create_task(
                                            rnd_worker(
                                                uids,
                                                uid,
                                                chat_id,
                                                key,
                                                iv,
                                                region,
                                                response.Data.chat_type
                                            )
                                        )

                        if inPuTMsG.strip().startswith('/srnd'):

                            if RND_TASK is None or RND_TASK.done():
                                no_task_msg = " [C][FF0000]❌ No /rnd dance is currently running.\n"
                                await safe_send_message(response.Data.chat_type, no_task_msg, uid, chat_id, key, iv)
                            else:
                                RND_TASK.cancel()
                                stop_msg = " [C][FFD700]⛔ Stopping /rnd dance... please wait.\n"
                                await safe_send_message(response.Data.chat_type, stop_msg, uid, chat_id, key, iv)


# NEW /max Command - send EVOS emotes to up to 5 UIDs: /max id1 id2 id3 id4 id5
                        if inPuTMsG.strip().startswith('/max'):

    # prevent double /max
                            if MAX_TASK is not None and not MAX_TASK.done():
                                already_msg = "[C][B][FF0000]/max is already running! Use /smax to stop.\n"
                                await safe_send_message(response.Data.chat_type, already_msg, uid, chat_id, key, iv)
                            else:
                                print('Processing /max command with multiple IDs...')

                                parts = inPuTMsG.strip().split()
                                target_ids = []

                                if len(parts) > 1:
                                    for p in parts[1:]:
                                        if p.isdigit():
                                            target_ids.append(p)
                                        if len(target_ids) >= 5:
                                            break

                                if not target_ids:
                                    target_ids = [str(uid)]

                                SMAX_STOP = False  # reset stop flag

                                # start background task
                                MAX_TASK = asyncio.create_task(
                                    run_max_evos(
                                        target_ids,
                                        uid,
                                        chat_id,
                                        key,
                                        iv,
                                        region,
                                        whisper_writer,
                                        online_writer,
                                        response.Data.chat_type
                                    )
                                )

# /smax -> stop running /max process
                        if inPuTMsG.strip().startswith('/smax'):

                            if MAX_TASK is None or MAX_TASK.done():
                                no_task_msg = "[C][B][FF0000]No /max process is currently running.\n"
                                await safe_send_message(response.Data.chat_type, no_task_msg, uid, chat_id, key, iv)
                            else:
                                SMAX_STOP = True
                                stop_msg = "[C][B][FFD700]Stopping /max... please wait.\n"
                                await safe_send_message(response.Data.chat_type, stop_msg, uid, chat_id, key, iv)


                        # NEW /rmax Command - each UID gets a different random dance emote once
                        if inPuTMsG.strip().startswith('/rmax'):
                            print('Processing /rmax command with multiple IDs (random per UID)...')

                            parts = inPuTMsG.strip().split()

                            target_ids = []

                            # Parse up to 5 numeric IDs after /dance
                            if len(parts) > 1:
                                for p in parts[1:]:
                                    if p.isdigit():
                                        target_ids.append(p)
                                    if len(target_ids) >= 5:
                                        break

                            # If no valid IDs given, default to sender
                            if not target_ids:
                                target_ids = [str(uid)]

                            # Mapping of DANCE emotes to IDs (same as your previous list)
                            evo_emotes = {
                            "1": "909000063",   # AK
                            "2": "909000068",   # SCAR
                            "3": "909000075",   # 1st MP40
                            "4": "909000081",   # 1st M1014
                            "5": "909000085",   # XM8
                            "6": "909000098",   # UMP
                            "7": "909000090",   # Famas
                            "8": "909033002",   # Mp5
                            "9": "909035007",  # M1887
                            "10": "909033001",  # M4A1
                            "11": "909037011",   # FIST
                            "12": "909035012",   # AN94
                            "13": "909038010",  # Thompson
                            "14": "909039011",   # 2nd M1014
                            "15": "909040010",   # 2nd MP40
                            "16": "909041005",  # Groza
                            "17": "909042008",  # Woodpecker
                            "18": "909045001",  # Parafal
                            "19": "909049010",   # P90
                            "20": "909038012",  # G18
                            "21": "909051003"   # M60
                            }

                            try:
                                # Info message
                                intro_msg = (
                                    "[C][B][1E90FF]rmax Processing!\n"
                                )
                                await safe_send_message(response.Data.chat_type, intro_msg, uid, chat_id, key, iv)

                                sent_count = 0
                                result_lines = []

                                # For each target UID, pick its own random emote and send ONCE
                                for target in target_ids:
                                    try:
                                        random_key = random.choice(list(evo_emotes.keys()))
                                        random_emote_id = int(evo_emotes[random_key])

                                        H = await Emote_k(int(target), random_emote_id, key, iv, region)
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
                                        sent_count += 1

                                        result_lines.append(
                                            f"[FFFFFF]Processing /rmax command with multiple IDs (random per UID)..."
                                        )
                                    except Exception as e:
                                        print(f"Error sending dance emote")
                                        result_lines.append(
                                            f"[FF0000]Failed to send emote"
                                        )

                                # Build final summary message
                                summary = (
                                    "[C][B][00FF00]complete!\n"
                                )
                                await safe_send_message(response.Data.chat_type, summary, uid, chat_id, key, iv)

                            except Exception as e:
                                err_msg = f"[C][B][FF0000]Error in /rmax command"
                                await safe_send_message(response.Data.chat_type, err_msg, uid, chat_id, key, iv)

                        # NEW /loop Command - /loop uid1 uid2 uid3 uid4 uid5 emote_number
                        if inPuTMsG.strip().startswith('/loop '):
                            print('Processing /loop command with multiple IDs...')

                            parts = inPuTMsG.strip().split()

                            # Need at least: /loop uid emote_number
                            if len(parts) < 3:
                                error_msg = (
                                    "[C][B][FF0000]Usage: /loop [uid1] [uid2] [uid3] [uid4] [uid5] emote_number(1-43)\n"
                                )
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                # Last argument is emote number, previous are UIDs
                                raw_args = parts[1:]

                                emote_number_str = raw_args[-1]
                                uid_parts = raw_args[:-1]

                                target_ids = []
                                for p in uid_parts:
                                    if p.isdigit():
                                        target_ids.append(p)
                                    if len(target_ids) >= 5:
                                        break

                                # If no valid IDs given, default to sender
                                if not target_ids:
                                    target_ids = [str(uid)]

                                # Validate emote number
                                if not emote_number_str.isdigit():
                                    error_msg = "[C][B][FF0000]Emote number must be numeric (1-43)!"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    emote_choice = int(emote_number_str)

                                    # Mapping of EVOS choices to emote IDs
                                    evo_emotes = {
                            1 : 909051001,   
                            2 : 909051002,  
                            3 : 909051005,   
                            4 : 909051010,  
                            5 : 909051014,   
                            6 : 909050009,   
                            7 : 909050008,  
                            8 : 909050010,   
                            9 : 909050011,  
                            10 : 909050012,  
                            11 : 909050027,   
                            12 : 909050028,  
                            13 : 909000010,  
                            14 : 909000014, 
                            15 : 909037001,  
                            16 : 909036006,  
                            17 : 909036003, 
                            18 : 909036001,  
                            19 : 909037006,  
                            20 : 909040001,
                            21 : 909040008,
                            22 : 909040013,   
                            23 : 909041004,  
                            24 : 909042012,   
                            25 : 909043001,  
                            26 : 909043009,   
                            27 : 909043003,   
                            28 : 909043002,  
                            29 : 909044002,   
                            30 : 909044003,  
                            31 : 909045002,  
                            32 : 909045003,   
                            33 : 909045009, 
                            34 : 909049017,  
                            35 : 909049001, 
                            36 : 909046001,  
                            37 : 909047004,  
                            38 : 909047012, 
                            39 : 909047018,  
                            40 : 909048003,  
                            41 : 909048004,
                            42 : 909048005,
                            43 : 909048006
                                    }

                                    emote_id = evo_emotes.get(emote_choice)

                                    if not emote_id:
                                        error_msg = "[C][B][FF0000]Emote number must be between 1 and 43!"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    else:
                                        # Info message
                                        intro_msg = (
                                            "[C][B][1E90FF]loop Processing!\n"
                                        )
                                        await safe_send_message(response.Data.chat_type, intro_msg, uid, chat_id, key, iv)

                                        try:
                                            sent_count = 0

                                            # Send selected emote ONCE to each target id
                                            for target in target_ids:
                                                try:
                                                    emote_packet = await Emote_k(
                                                        int(target),
                                                        int(emote_id),
                                                        key,
                                                        iv,
                                                        region
                                                    )
                                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', emote_packet)
                                                    sent_count += 1
                                                except Exception as e:
                                                    print(f"Error sending EVOS emote")

                                            done_msg = (
                                                f"[C][B][00FF00]complete!\n"
                                            )
                                            await safe_send_message(response.Data.chat_type, done_msg, uid, chat_id, key, iv)

                                        except Exception as e:
                                            err_msg = f"[C][B][FF0000]Error in /loop command"
                                            await safe_send_message(response.Data.chat_type, err_msg, uid, chat_id, key, iv)

                        # NEW /rloop Command - each UID gets a different random dance emote once
                        if inPuTMsG.strip().startswith('/rloop '):
                            print('Processing /rloop command with multiple IDs (random per UID)...')

                            parts = inPuTMsG.strip().split()

                            target_ids = []

                            # Parse up to 5 numeric IDs after /rloop
                            if len(parts) > 1:
                                for p in parts[1:]:
                                    if p.isdigit():
                                        target_ids.append(p)
                                    if len(target_ids) >= 5:
                                        break

                            # If no valid IDs given, default to sender
                            if not target_ids:
                                target_ids = [str(uid)]

                            # Mapping of DANCE emotes to IDs (same as your previous list)
                            evo_emotes = {
                            "1": "909051001",
                            "2": "909051002",   
                            "3": "909051005",   
                            "4": "909051010",   
                            "5": "909051014",  
                            "6": "909050009",   
                            "7": "909050008",   
                            "8": "909050010",  
                            "9": "909050011",  
                            "10": "909050012",  
                            "11": "909050027",   
                            "12": "909050028",   
                            "13": "909000010",  
                            "14": "909000014",   
                            "15": "909037001",  
                            "16": "909036006",  
                            "17": "909036003", 
                            "18": "909036001", 
                            "19": "909037006",   
                            "20": "909040001",  
                            "21": "909040008",   
                            "22": "909040013",  
                            "23": "909041004",   
                            "24": "909042012",   
                            "25": "909043001",   
                            "26": "909043009",  
                            "27": "909043003",   
                            "28": "909043002",   
                            "29": "909044002",   
                            "30": "909044003",  
                            "31": "909045002",  
                            "32": "909045003",   
                            "33": "909045009",   
                            "34": "909049017", 
                            "35": "909049001",   
                            "36": "909046001",  
                            "37": "909047004",  
                            "38": "909047012",  
                            "39": "909047018", 
                            "40": "909048003",   
                            "41": "909048004", 
                            "42": "909048005",   
                            "43": "909048006"  
                            }

                            try:
                                # Info message
                                intro_msg = (
                                    "[C][B][1E90FF]rloop Processing!\n"
                                )
                                await safe_send_message(response.Data.chat_type, intro_msg, uid, chat_id, key, iv)

                                sent_count = 0
                                result_lines = []

                                # For each target UID, pick its own random emote and send ONCE
                                for target in target_ids:
                                    try:
                                        random_key = random.choice(list(evo_emotes.keys()))
                                        random_emote_id = int(evo_emotes[random_key])

                                        H = await Emote_k(int(target), random_emote_id, key, iv, region)
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
                                        sent_count += 1

                                        result_lines.append(
                                            f"[FFFFFF]sending dance emote"
                                        )
                                    except Exception as e:
                                        print(f"Error sending dance emote")
                                        result_lines.append(
                                            f"[FF0000]Failed to send emote"
                                        )

                                # Build final summary message
                                summary = (
                                    "[C][B][00FF00]complete!\n"
                                )
                                await safe_send_message(response.Data.chat_type, summary, uid, chat_id, key, iv)

                            except Exception as e:
                                err_msg = f"[C][B][FF0000]Error in /rloop command"
                                await safe_send_message(response.Data.chat_type, err_msg, uid, chat_id, key, iv)

                        # NEW /dance Command - each UID gets a different random dance emote once
                        if inPuTMsG.strip().startswith('/dance '):
                            print('Processing /dance command with multiple IDs (random per UID)...')

                            parts = inPuTMsG.strip().split()

                            target_ids = []

                            # Parse up to 5 numeric IDs after /dance
                            if len(parts) > 1:
                                for p in parts[1:]:
                                    if p.isdigit():
                                        target_ids.append(p)
                                    if len(target_ids) >= 5:
                                        break

                            # If no valid IDs given, default to sender
                            if not target_ids:
                                target_ids = [str(uid)]

                            # Mapping of DANCE emotes to IDs (same as your previous list)
                            evo_emotes = {
                                "1": "909051012",
                                "2": "909000010",
                                "3": "909051013",
                                "4": "909035010",
                                "5": "909034014",
                                "6": "909033009",
                                "7": "909000141",
                                "8": "909000095",
                                "9": "909037002",
                                "10": "909037009",
                                "11": "909039004",
                                "12": "909040006",
                                "13": "909041010",
                                "14": "909042001",
                                "15": "909042002",
                                "16": "909042007",
                                "17": "909045004",
                                "18": "909045011",
                                "19": "909045010",
                                "20": "909049018",
                                "21": "909049001",
                                "22": "909048018",
                                "23": "909049007",
                                "24": "909049009",
                            }

                            try:
                                # Info message
                                intro_msg = (
                                    "[C][B][1E90FF]dance Processing!\n"
                                )
                                await safe_send_message(response.Data.chat_type, intro_msg, uid, chat_id, key, iv)

                                sent_count = 0
                                result_lines = []

                                # For each target UID, pick its own random emote and send ONCE
                                for target in target_ids:
                                    try:
                                        random_key = random.choice(list(evo_emotes.keys()))
                                        random_emote_id = int(evo_emotes[random_key])

                                        H = await Emote_k(int(target), random_emote_id, key, iv, region)
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
                                        sent_count += 1

                                        result_lines.append(
                                            f"[FFFFFF]UID [00FF00]{target} [FFFFFF]→ Emote #{random_key} (ID: {random_emote_id})"
                                        )
                                    except Exception as e:
                                        print(f"Error sending dance emote")
                                        result_lines.append(
                                            f"[FF0000]Failed to send emote"
                                        )

                                # Build final summary message
                                summary = (
                                    "[C][B][00FF00]complete!\n"
                                )
                                await safe_send_message(response.Data.chat_type, summary, uid, chat_id, key, iv)

                            except Exception as e:
                                err_msg = f"[C][B][FF0000]Error in /dance command"
                                await safe_send_message(response.Data.chat_type, err_msg, uid, chat_id, key, iv)



                        # NEW /jel COMMAND - Team join, emote trigger, then leave - FAST VERSION
                        if inPuTMsG.strip().startswith('/jel'):
                            print('Processing /jel command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 4:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /jel [team_code] [uid] [emote_id]\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                team_code = parts[1]
                                target_uid = parts[2]
                                emote_id = parts[3]
                                
                                initial_message = f"jel Processing!\n"
                                await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                
                                # Execute the /r command operation with direct emote ID
                                success, result_msg = await r_command_operation(team_code, target_uid, emote_id, key, iv, region)
                                
                                if success:
                                    success_msg = f" [C][00FF00]✅ SUCCESS!\n"
                                    await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                else:
                                    error_msg = f" [C][FF0000]❌ ERROR!\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # Invite Command - /inv (creates 5-player group and sends request)
                        if inPuTMsG.strip().startswith('/inv '):
                            print('Processing invite command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f"[B][C][FF0000]❌ ERROR! Usage: /inv (uid)\nExample: /inv 123456789\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
                                initial_message = f"[B][C]{get_random_color()}\nCreating 5-Player Group and sending request to {target_uid}...\n"
                                await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                
                                try:
                                    # Fast squad creation and invite for 5 players
                                    PAc = await OpEnSq(key, iv, region)
                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
                                    await asyncio.sleep(0.3)
                                    
                                    C = await cHSq(5, int(target_uid), key, iv, region)
                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', C)
                                    await asyncio.sleep(0.3)
                                    
                                    V = await SEnd_InV(5, int(target_uid), key, iv, region)
                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
                                    await asyncio.sleep(0.3)
                                    
                                    E = await ExiT(None, key, iv)
                                    await asyncio.sleep(2)
                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)
                                    
                                    # SUCCESS MESSAGE
                                    success_message = f"[B][C][00FF00]✅ SUCCESS! 5-Player Group invitation sent successfully to {target_uid}!\n"
                                    await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)
                                    
                                except Exception as e:
                                    error_msg = f"[B][C][FF0000]❌ ERROR sending invite: {str(e)}\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
# NEW /jevo COMMAND
# Usage: /jevo teamcode uid1 uid2 uid3 uid4 uid5 emoteNumber
                        if inPuTMsG.startswith('/jevo'):
                            try:
                                parts = inPuTMsG.split()

                                if len(parts) < 2:
                                    await safe_send_message(
                                        response.Data.chat_type,
                                        "[FF0000]Usage: /jevo teamcode [uids...] [emote(1-21)]",
                                        uid, chat_id, key, iv
                                    )
                                    continue

                                team_code = parts[1]
                                
                                # Defaults
                                emote_number = None
                                possible_uids = []
                                
                                # Check if last arg is emote number
                                if len(parts) >= 3 and parts[-1].isdigit():
                                    val = int(parts[-1])
                                    if 1 <= val <= 21:
                                        emote_number = val
                                        possible_uids = parts[2:-1]
                                    else:
                                        # Last digit not in range 1-21, treat as UID?
                                        # Or just strict? Let's treat it as UID and pick random emote
                                        possible_uids = parts[2:]
                                else:
                                    possible_uids = parts[2:]
                                
                                # If no emote specified, pick random
                                if emote_number is None:
                                    emote_number = random.randint(1, 21)

                                target_uids = []
                                for p in possible_uids:
                                    if p.isdigit():
                                        target_uids.append(p)
                                    if len(target_uids) >= 5:
                                        break

                                if not target_uids:
                                    target_uids = [str(uid)]

                                await safe_send_message(
                                    response.Data.chat_type,
                                    f"[1E90FF]JEVO processing (Emote {emote_number})...",
                                    uid, chat_id, key, iv
                                )

                                ok = await jevo_operation(
                                    team_code,
                                    target_uids,
                                    emote_number,
                                    key,
                                    iv,
                                    region
                                )

                                if ok:
                                    await safe_send_message(
                                        response.Data.chat_type,
                                        "[00FF00]JEVO done",
                                        uid, chat_id, key, iv
                                    )
                                else:
                                    await safe_send_message(
                                        response.Data.chat_type,
                                        "[FF0000]JEVO failed",
                                        uid, chat_id, key, iv
                                    )
                            except Exception as e:
                                print(f"JEVO ERROR: {e}")
                                await safe_send_message(
                                    response.Data.chat_type,
                                    f"[FF0000]JEVO Error: {str(e)}",
                                    uid, chat_id, key, iv
                                )
# NEW /jevor COMMAND
# Usage: /jevor teamcode uid1 uid2 uid3 uid4 uid5
                        if inPuTMsG.strip().startswith('/jrevo'):
                            try:
                                parts = inPuTMsG.strip().split()

                                if len(parts) < 2:
                                    await safe_send_message(
                                        response.Data.chat_type,
                                        "[FF0000]Usage:\n/jrevo teamcode [uid1] [uid2]...",
                                        uid, chat_id, key, iv
                                    )
                                    continue

                                team_code = parts[1]

        # collect up to 5 UIDs
                                target_uids = []
                                for p in parts[2:]:
                                    if p.isdigit():
                                        target_uids.append(p)
                                    if len(target_uids) >= 5:
                                        break

                                if not target_uids:
                                    target_uids = [str(uid)]

                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[1E90FF]JREVO processing ...",
                                    uid, chat_id, key, iv
                                )

                                ok = await jevor_operation(
                                    team_code,
                                    target_uids,
                                    key,
                                    iv,
                                    region
                                )

                                if ok:
                                    await safe_send_message(
                                        response.Data.chat_type,
                                        "[00FF00]JREVO completed successfully",
                                        uid, chat_id, key, iv
                                    )
                                else:
                                    await safe_send_message(
                                        response.Data.chat_type,
                                        "[FF0000]JREVO failed",
                                        uid, chat_id, key, iv
                                    )
                            except Exception as e:
                                print(f"JREVO ERROR: {e}")
                                await safe_send_message(
                                    response.Data.chat_type,
                                    f"[FF0000]JREVO Error: {str(e)}",
                                    uid, chat_id, key, iv
                                )

# NEW /jp COMMAND
# Usage: /jp teamcode uid1 uid2 uid3 uid4 uid5 number
# SAFE /jp — WILL NEVER FREEZE BOT
                        if inPuTMsG.strip().startswith('/jp'):
                            parts = inPuTMsG.strip().split()

                            # minimum args
                            if len(parts) < 3:
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[FF0000]Usage: /jp teamcode uid1 uid2 uid3 uid4 uid5 number(1-408)",
                                    uid, chat_id, key, iv
                                )
                                continue  # 🔥 VERY IMPORTANT

                            team_code = parts[1]

    # last argument = emote number
                            emote_number = parts[-1]

                            # 🔒 EMOTE NUMBER VALIDATION FIRST
                            if not emote_number.isdigit():
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[FF0000]Emote number must be numeric (1-408)",
                                    uid, chat_id, key, iv
                                )
                                continue

                            emote_number = int(emote_number)

                            # 🔥 HARD LIMIT (THIS FIXES FREEZE)
                            if emote_number < 1 or emote_number > 408:
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[FF0000]Emote must be between 1 and 408",
                                    uid, chat_id, key, iv
                                )
                                continue  # 🔥 DO NOT FALL THROUGH

                            # collect UIDs safely
                            uids = []
                            for p in parts[2:-1]:
                                if p.isdigit() and 6 <= len(p) <= 12:
                                    uids.append(p)
                                if len(uids) >= 5:
                                    break

                            if not uids:
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[FF0000]No valid UIDs provided",
                                    uid, chat_id, key, iv
                                )
                                continue

                            # safe execution
                            await safe_send_message(
                                response.Data.chat_type,
                                "[1E90FF]JP processing...",
                                uid, chat_id, key, iv
                            )

                            try:
                                ok = await jp_operation(team_code, uids, emote_number, key, iv, region)
                            except Exception as e:
                                logging.error(f"/jp runtime error: {e}")
                                ok = False

                            if ok:
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[00FF00]JP completed",
                                    uid, chat_id, key, iv
                                )
                            else:
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[FF0000]JP failed safely",
                                    uid, chat_id, key, iv
                                )

                        # NEW /new COMMAND
                        # NEW /new COMMAND
                        # Usage: /new uid1 [uid2...] number
                        if inPuTMsG.strip().startswith('/new'):
                            print('Processing /new command with multiple UIDs')
                            parts = inPuTMsG.strip().split()

                            if len(parts) < 3:
                                await safe_send_message(
                                    response.Data.chat_type,
                                    "[FF0000]Usage: /new [uid1] [uid2] ... [number]",
                                    uid, chat_id, key, iv
                                )
                            else:
                                emote_num = parts[-1]
                                target_uids = parts[1:-1] # Get all UIDs between command and number

                                if not emote_num.isdigit():
                                     await safe_send_message(
                                        response.Data.chat_type,
                                        "[FF0000]Last argument must be the emote number!",
                                        uid, chat_id, key, iv
                                    )
                                else:
                                    # Look up emote from NEW_EMOTES_MAP
                                    emote_id = NEW_EMOTES_MAP.get(str(emote_num))
                                    
                                    if not emote_id:
                                        max_emotes = len(NEW_EMOTES_MAP)
                                        await safe_send_message(
                                            response.Data.chat_type,
                                            f"[FF0000]Invalid Emote Number! Valid range: 1-{max_emotes}",
                                            uid, chat_id, key, iv
                                        )
                                    else:
                                        valid_uids = [u for u in target_uids if u.isdigit()]
                                        
                                        if not valid_uids:
                                            await safe_send_message(
                                                response.Data.chat_type,
                                                "[FF0000]No valid UIDs provided!",
                                                uid, chat_id, key, iv
                                            )
                                        else:
                                            await safe_send_message(
                                                response.Data.chat_type,
                                                f"[1E90FF]Sending New Emote {emote_num} to {len(valid_uids)} players...",
                                                uid, chat_id, key, iv
                                            )
                                            
                                            success_count = 0
                                            for target in valid_uids:
                                                try:
                                                    # Send emote packet directly
                                                    packet = await Emote_k(int(target), int(emote_id), key, iv, region)
                                                    if packet:
                                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', packet)
                                                        success_count += 1
                                                        # Small delay to prevent flooding if many UIDs
                                                        if len(valid_uids) > 1:
                                                            await asyncio.sleep(0.1) 
                                                except Exception as e:
                                                    print(f"/new error for {target}: {e}")

                                            if success_count > 0:
                                                await safe_send_message(
                                                    response.Data.chat_type,
                                                    f"[00FF00]Emote Sent to {success_count}/{len(valid_uids)} players!",
                                                    uid, chat_id, key, iv
                                                )
                                            else:
                                                await safe_send_message(
                                                    response.Data.chat_type,
                                                    "[FF0000]Failed to send emotes!",
                                                    uid, chat_id, key, iv
                                                )

                        # ================= /room COMMAND =================
                        if inPuTMsG.strip().startswith('/room'):
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                await safe_send_message(response.Data.chat_type, "[B][C][FF0000]❌ Usage: /room (uid)\n", uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
                                try:
                                    status_result, status_message = await check_player_status(target_uid, key, iv)
                                    packet = None
                                    player_status = None
                                    
                                    # LIVE or CACHE
                                    if not status_result:
                                        cached_data = load_from_cache(target_uid)
                                        if cached_data:
                                            packet = cached_data.get('packet')
                                            player_status = cached_data.get('status', 'UNKNOWN')
                                            print(f"⚠️ Using cached data for {target_uid}")
                                        else:
                                            await safe_send_message(response.Data.chat_type, f"""[B][C][FFFF00]
👤 Player: {fix_num(target_uid)}
❌ Not in custom room\n""", uid, chat_id, key, iv)
                                            continue
                                    else:
                                        packet = status_result.get('packet')
                                        player_status = get_player_status(packet)
                                    
                                    # Check if player is in room
                                    if not player_status or "IN ROOM" not in player_status:
                                        info_msg = f"""[B][C][FFFF00]
👤 Player: {fix_num(target_uid)}
❌ Not in custom room"""
                                        await safe_send_message(response.Data.chat_type, info_msg, uid, chat_id, key, iv)
                                    else:
                                        # In Room -> Get ID
                                        room_id = get_idroom_by_idplayer(packet) if packet else None
                                        
                                        if not room_id:
                                            await safe_send_message(response.Data.chat_type, "[B][C][FF0000]❌ Failed to extract room ID\n", uid, chat_id, key, iv)
                                        else:
                                            # SUCCESS - Send room info
                                            success_msg = f"""[B][C][00FF00]✅ ROOM FOUND!

👤 Player: {fix_num(target_uid)}
🏠 Room ID: {fix_num(room_id)}
📊 Status: {player_status}
"""
                                            await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                            
                                            # AUTO-SPAM - Start background worker
                                            # Using create_task so it doesn't block other commands
                                            asyncio.create_task(room_spam_worker(
                                                target_uid, 
                                                room_id, 
                                                key, 
                                                iv, 
                                                whisper_writer, 
                                                response.Data.chat_type, 
                                                uid, 
                                                chat_id
                                            ))
                                            
                                            spam_msg = f"[B][C][FF0000]✅ Room Spam Started\nType /sroom to stop."
                                            await safe_send_message(response.Data.chat_type, spam_msg, uid, chat_id, key, iv)
                                        
                                except Exception as e:
                                    print(f"❌ Room command error: {e}")
                                    await safe_send_message(response.Data.chat_type, f"[B][C][FF0000]❌ Error: {str(e)[:80]}\n", uid, chat_id, key, iv)


                        # ================= /status COMMAND =================
                        if inPuTMsG.strip().startswith('/status '):
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                await safe_send_message(response.Data.chat_type, "[B][C][FF0000]❌ Usage: /status (uid)\n", uid, chat_id, key, iv)
                            else:
                                target_uid = parts[1]
                                
                                # Clear old cache to force fresh check
                                clear_cache_entry(target_uid)
                                
                                await safe_send_message(response.Data.chat_type, f"[B][C][00FF00]🔍 Checking status of {fix_num(target_uid)}...\n", uid, chat_id, key, iv)
                                
                                try:
                                    # Send status request
                                    status_packet = await createpacketinfo(target_uid, key, iv)
                                    if status_packet:
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', status_packet)
                                        
                                        # Wait and poll cache
                                        found_status = False
                                        for _ in range(12): # 6 seconds timeout
                                            await asyncio.sleep(0.5)
                                            cache_data = load_from_cache(target_uid)
                                            if cache_data:
                                                status = cache_data.get('status', 'UNKNOWN')
                                                
                                                status_msg = f"""[B][C][FFFF00]📊 PLAYER STATUS
────────────────
👤 UID: {fix_num(target_uid)}
📊 Status: {status}
"""
                                                # Detailed info based on status
                                                if "IN ROOM" in status:
                                                    if 'room_id' in cache_data:
                                                        status_msg += f"🏠 Room ID: {fix_num(cache_data['room_id'])}\n"
                                                        # status_msg += f"💡 Use: /room {target_uid}\n"
                                                        # Send raw Room ID for quick copying check ff/main.py logic (lines 7991)
                                                        # room_id_msg = f"{fix_num(cache_data['room_id'])}"
                                                        # await safe_send_message(response.Data.chat_type, room_id_msg, uid, chat_id, key, iv)
                                                    else:
                                                        status_msg += "🏠 Room ID: Not available\n"
                                                
                                                elif "INSQUAD" in status:
                                                    if 'leader_id' in cache_data:
                                                        status_msg += f"👑 Leader: {fix_num(cache_data['leader_id'])}\n"
                                                    
                                                    # Try to get squad size
                                                    try:
                                                        if 'parsed_json' in cache_data:
                                                            parsed = cache_data['parsed_json']
                                                            # Access cached parsed_json structure
                                                            if '5' in parsed and 'data' in parsed['5']:
                                                                squad_data = parsed['5']['data']['1']['data']
                                                                if '9' in squad_data and 'data' in squad_data['9']:
                                                                    members = squad_data['9']['data']
                                                                    # Field 10 is typically max capacity, but let's confirm usage
                                                                    max_members = squad_data['10']['data'] + 1
                                                                    status_msg += f"👥 Squad: {members}/{max_members}\n"
                                                    except Exception:
                                                        pass

                                                elif "SOLO" in status:
                                                    status_msg += "👤 Player is solo\n"
                                                elif "OFFLINE" in status:
                                                    status_msg += "🔴 Player is offline\n"
                                                elif "INGAME" in status:
                                                    status_msg += "🎮 Player is in a match\n"
                                                    
                                                status_msg += "────────────────\n✅ Real-time data"
                                                
                                                await safe_send_message(response.Data.chat_type, status_msg, uid, chat_id, key, iv)
                                                found_status = True
                                                break
                                        
                                        if not found_status:
                                            error_msg = f"[B][C][FF0000]❌ STATUS CHECK FAILED\n"
                                            error_msg += f"────────────────\n"
                                            error_msg += f"👤 UID: {fix_num(target_uid)}\n"
                                            error_msg += f"📛 No response from server\n"
                                            error_msg += f"────────────────\n"
                                            error_msg += f"💡 Possible issues:\n"
                                            error_msg += f"• Player is offline\n"
                                            error_msg += f"• Server is busy\n"
                                            error_msg += f"• Try again in 10 seconds\n"
            
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)       
                                except Exception as e:
                                    print(f"/status error: {e}")
                                    await safe_send_message(response.Data.chat_type, f"[B][C][FF0000]❌ Error: {str(e)[:50]}\n", uid, chat_id, key, iv)


                                    await safe_send_message(response.Data.chat_type, f"[B][C][FF0000]❌ Error: {str(e)[:50]}\n", uid, chat_id, key, iv)


                        # ================= NEW COMMANDS =================
                        
                        # /sticker
                        if inPuTMsG.strip().startswith('/sticker'):
                             packet = await send_sticker(uid, chat_id, key, iv)
                             if packet and online_writer:
                                 await SEndPacKeT(whisper_writer, online_writer, 'ChaT', packet)
                                 
                        # /title - Background Sequence
                        if inPuTMsG.strip().startswith('/title'):
                            await handle_all_titles_command(inPuTMsG, uid, chat_id, key, iv, region, response.Data.chat_type, whisper_writer)
                            
                        # noob - Background Sequence (No Slash)
                        if inPuTMsG.strip().startswith('noob'):
                            await handle_alll_titles_command(inPuTMsG, uid, chat_id, key, iv, region, response.Data.chat_type, whisper_writer)

                        # /sroom Command - Stop Room Spam
                        if inPuTMsG.strip().startswith('/sroom'):
                            global room_spam_active
                            if room_spam_active:
                                room_spam_active = False
                                await safe_send_message(response.Data.chat_type, "[B][C][FFFF00]⚠️ Stopping room spam...", uid, chat_id, key, iv)
                            else:
                                await safe_send_message(response.Data.chat_type, "[B][C][FF0000]❌ No room spam is currently running.", uid, chat_id, key, iv)


                        # Individual command handlers for /s1 to /s8
                        # ================= REJECT SPAM =================
                        if inPuTMsG.strip().startswith('/rej '):
                            parts = inPuTMsG.strip().split()
                            if len(parts) >= 2:
                                t_uid = parts[1]
                                if reject_spam_task and not reject_spam_task.done(): reject_spam_task.cancel()
                                reject_spam_task = asyncio.create_task(reject_spam_loop(t_uid, key, iv, region))
                                await safe_send_message(response.Data.chat_type, f"[B][C][00FF00]✅ Reject Spam Active on {t_uid}\n", uid, chat_id, key, iv)

                        if inPuTMsG.strip() == '/srej':
                            if reject_spam_task and not reject_spam_task.done():
                                reject_spam_task.cancel()
                                await safe_send_message(response.Data.chat_type, "[B][C][00FF00]✅ Reject Spam Stopped\n", uid, chat_id, key, iv)

                        # ================= RANDOM LOOP COMMANDS =================
                        if inPuTMsG.strip().startswith('/rloop'):
                             # Random General Emote Loop
                             # Usage: /rloop [uids]
                             parts = inPuTMsG.strip().split()
                             rloop_uids = parts[1:] if len(parts) > 1 else [str(uid)]
                             
                             if fast_spam_task and not fast_spam_task.done(): fast_spam_task.cancel()
                             
                             # Pick random emote from general map
                             import random
                             if GENERAL_EMOTES_MAP:
                                 rand_idx = str(random.randint(1, len(GENERAL_EMOTES_MAP)))
                                 r_emote = GENERAL_EMOTES_MAP.get(rand_idx)
                                 if r_emote:
                                     fast_spam_task = asyncio.create_task(fast_emote_spam(rloop_uids, r_emote, key, iv, region))
                                     await safe_send_message(response.Data.chat_type, f"[B][C][00FF00]✅ Random Loop Started ({rand_idx})!\n", uid, chat_id, key, iv)

                        if inPuTMsG.strip().startswith('/rmax'):
                             # Random Max Evo Loop
                             if MAX_TASK and not MAX_TASK.done(): MAX_TASK.cancel()
                             
                             async def rmax_loop_worker():
                                 import random
                                 while True:
                                     try:
                                         ridx = random.randint(1, 21)
                                         eid = EMOTE_MAP.get(ridx)
                                         if eid:
                                             P = await Emote_k(int(uid), int(eid), key, iv, region)
                                             await SEndPacKeT(whisper_writer, online_writer, 'OnLine', P)
                                         await asyncio.sleep(0.15)
                                     except: await asyncio.sleep(1)
                             
                             MAX_TASK = asyncio.create_task(rmax_loop_worker())
                             await safe_send_message(response.Data.chat_type, "[B][C][00FF00]✅ Max Random Loop Started!\n", uid, chat_id, key, iv) 

                        # ================= JOIN-EMOTE VARIANTS =================
                        if inPuTMsG.strip().startswith('/jel '):
                            parts = inPuTMsG.strip().split()
                            if len(parts) >= 3:
                                tcode = parts[1]
                                em = parts[-1]
                                await safe_send_message(response.Data.chat_type, f"[B][C][00FF00]🚀 JEL {tcode}...\n", uid, chat_id, key, iv)
                                await run_one_time_start(tcode, uid, chat_id, response.Data.chat_type, key, iv)
                                await asyncio.sleep(2)
                                await custom_emote_spam(uid, em, 1, key, iv, region)
                                await asyncio.sleep(1)
                                await ExiT(None, key, iv)
                                await safe_send_message(response.Data.chat_type, f"[B][C][00FF00]✅ JEL Done\n", uid, chat_id, key, iv)

                        if inPuTMsG.strip().startswith('/jrevo '):
                            parts = inPuTMsG.strip().split()
                            if len(parts) >= 2:
                                tcode = parts[1]
                                await safe_send_message(response.Data.chat_type, f"[B][C][00FF00]🚀 J-Revo {tcode}...\n", uid, chat_id, key, iv)
                                await run_one_time_start(tcode, uid, chat_id, response.Data.chat_type, key, iv)
                                await asyncio.sleep(2)
                                
                                if MAX_TASK and not MAX_TASK.done(): MAX_TASK.cancel()
                                
                                async def jrevo_loop_worker():
                                    import random
                                    while True:
                                        try:
                                            ridx = random.randint(1, 21)
                                            eid = EMOTE_MAP.get(ridx)
                                            if eid:
                                                P = await Emote_k(int(uid), int(eid), key, iv, region)
                                                await SEndPacKeT(whisper_writer, online_writer, 'OnLine', P)
                                            await asyncio.sleep(0.15)
                                        except: await asyncio.sleep(1)
                                        
                                MAX_TASK = asyncio.create_task(jrevo_loop_worker()) 
                                await safe_send_message(response.Data.chat_type, "[B][C][00FF00]✅ J-Revo Loop Started (Use /smax to stop)\n", uid, chat_id, key, iv)

                        # ================= ATTACK / SPAM COMMANDS (FIXED) =================
                        # ================= ATTACK / SPAM COMMANDS (MATCHING FF FOLDER) =================
                        if inPuTMsG.strip().startswith('/sm '):
                             await handle_sm_command(inPuTMsG, uid, chat_id, key, iv, region, response.Data.chat_type)
                             
                        elif inPuTMsG.strip().startswith(('/s1', '/s2', '/s3', '/s4', '/s5')):
                             cmd_s = inPuTMsG.strip().split()[0].replace('/', '')
                             await handle_badge_command(cmd_s, inPuTMsG, uid, chat_id, key, iv, region, response.Data.chat_type)

                        if inPuTMsG.strip() == '/ssm':
                             if BADGE_SPAM_TASK and not BADGE_SPAM_TASK.done():
                                 BADGE_SPAM_STOP = True
                                 BADGE_SPAM_TASK.cancel()
                                 await safe_send_message(response.Data.chat_type, "[B][C][00FF00]✅ Badge Spam Stopped!\n", uid, chat_id, key, iv)
                             else:
                                 await safe_send_message(response.Data.chat_type, "[B][C][FF0000]❌ No badge spam active!\n", uid, chat_id, key, iv)



                        if inPuTMsG.startswith(("/6")):
                            # Process /6 command - Create 4 player group
                            parts = inPuTMsG.strip().split()
                            target_uid_val = uid
                            if len(parts) > 1 and parts[1].isdigit():
                                target_uid_val = int(parts[1])

                            initial_message = f" [C]{get_random_color()}\n\nCreating 6-Player Group...\n\n"
                            await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                            
                            # Fast squad creation and invite for 4 players
                            PAc = await OpEnSq(key, iv, region)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
                            
                            C = await cHSq(6, target_uid_val, key, iv, region)
                            await asyncio.sleep(0.3)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', C)
                            
                            V = await SEnd_InV(6, target_uid_val, key, iv, region)
                            await asyncio.sleep(0.3)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
                            
                            E = await ExiT(None, key, iv)
                            await asyncio.sleep(3.5)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)
                            
                            # SUCCESS MESSAGE
                            success_message = f" [C][00FF00]✅ SUCCESS! 6-Player Group invitation sent successfully!\n"
                            await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)

                        if inPuTMsG.startswith(("/3")):
                            # Process /3 command - Create 3 player group
                            parts = inPuTMsG.strip().split()
                            target_uid_val = uid
                            if len(parts) > 1 and parts[1].isdigit():
                                target_uid_val = int(parts[1])

                            initial_message = f" [C]{get_random_color()}\n\nCreating 3-Player Group...\n\n"
                            await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                            
                            # Fast squad creation and invite for 6 players
                            PAc = await OpEnSq(key, iv, region)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
                            
                            C = await cHSq(3, target_uid_val, key, iv, region)
                            await asyncio.sleep(0.3)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', C)
                            
                            V = await SEnd_InV(3, target_uid_val, key, iv, region)
                            await asyncio.sleep(0.3)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
                            
                            E = await ExiT(None, key, iv)
                            await asyncio.sleep(3.5)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)
                            
                            # SUCCESS MESSAGE
                            success_message = f" [C][00FF00]✅ SUCCESS! 6-Player Group invitation sent successfully!\n"
                            await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)

                        if inPuTMsG.startswith(("/5")):
                            # Process /5 command in any chat type
                            parts = inPuTMsG.strip().split()
                            target_uid_val = uid
                            if len(parts) > 1 and parts[1].isdigit():
                                target_uid_val = int(parts[1])

                            initial_message = f" [C]{get_random_color()}\n\nSending Group Invitation...\n\n"
                            await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                            
                            # Fast squad creation and invite
                            PAc = await OpEnSq(key, iv, region)
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', PAc)
                            
                            C = await cHSq(5, target_uid_val, key, iv, region)
                            await asyncio.sleep(0.3)  # Reduced delay
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', C)
                            
                            V = await SEnd_InV(5, target_uid_val, key, iv, region)
                            await asyncio.sleep(0.3)  # Reduced delay
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', V)
                            
                            E = await ExiT(None, key, iv)
                            await asyncio.sleep(3.5)  # Reduced from 3 seconds
                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', E)
                            
                            # SUCCESS MESSAGE
                            success_message = f" [C][00FF00]✅ SUCCESS! Group invitation sent successfully!\n"
                            await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)

                        if inPuTMsG.strip() == "/owner":
                            # Process /admin command in any chat type
                            admin_message = """
[C][B][FF0000]╔══════════╗
[FFFFFF]✨ folow on Instagram   
[FFFFFF]          ⚡ ig._tom_❤️  
[FFFFFF]                   thank for support 
[FF0000]╠══════════╣
[FFD700]⚡ OWNER : [FFFFFF]TOM   
[FFD700]⚡ TELEGRAM : [FFFFFF]@Muzammil_cp 
[FFD700]✨ Name on instagram : [FFFFFF]ig._tom_❤️  
[FF0000]╚══════════╝
[FFD700]✨ Developer —͟͞͞ </> TOM  ⚡
"""
                            await safe_send_message(response.Data.chat_type, admin_message, uid, chat_id, key, iv)
                        if inPuTMsG.strip() == "/admin":
                            # Process /admin command in any chat type
                            # Menu 3 - Advanced Commands
                            owner_message = '''[C] [FF0000]╔══════════╗
[C][B][00FF00] OWNER COMMANDS
[C][B][FFFF00]────────

[FFD700]⚡Add Admin
[fff5ee]⚡/🙃add [uid]
[FFD700]⚡Remove Admin
[fff5ee]⚡/🙃remove [uid]
[FFD700]⚡Show All Admin UID
[fff5ee]⚡/🙃admin list
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, owner_message, uid, chat_id, key, iv)
                            await asyncio.sleep(0.5)
                            admin_message = """[C][B][FF0000]╔══════════╗
[C][B][00FF00] ADMIN COMMANDS
[C][B][FFFF00]────────────
[FFD700]⚡BoT Guild Join 
[fff5ee]⚡/🙃gj [Guild ID]
[FFD700]⚡BoT Guild Leave
[fff5ee]⚡/🙃gl
[FFD700]⚡Ban Player
[fff5ee]⚡/🙃ban [uid]
[FFD700]⚡Unban Player
[fff5ee]⚡/🙃unban [uid]
[FFD700]⚡Unban All Player
[fff5ee]⚡/🙃unban all
[FFD700]⚡Show All Banned Player
[fff5ee]⚡/🙃ban list
[FFD700]⚡Mute All Player
[fff5ee]⚡/🙃mute [30s/1m/5m/1h]
[FFD700]⚡Unmute All Player
[fff5ee]⚡/🙃unmute
[FFD700]⚡Restart Bot
[fff5ee]⚡/🙃restart
[FFD700]⚡Stop Bot
[fff5ee]⚡/🙃stop
[FF0000]╚══════════╝
"""
                            await safe_send_message(response.Data.chat_type, admin_message, uid, chat_id, key, iv)
                        # FIXED JOIN COMMAND
                        if inPuTMsG.startswith('/join'):
                            # Process /join command in any chat type
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /join (team_code)\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                CodE = parts[1]
                                initial_message = f" [C]{get_random_color()}\nJoining squad with code: {CodE}...\n"
                                await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                
                                try:
                                    # Try using the regular join method first
                                    EM = await GenJoinSquadsPacket(CodE, key, iv)
                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', EM)
                                    
                                    # SUCCESS MESSAGE
                                    success_message = f" [C][00FF00]✅ SUCCESS! Joining squad with code: {CodE}!\n"
                                    await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)
                                    
                                except Exception as e:
                                    print(f"Regular join failed, trying ghost join: {e}")
                                    # If regular join fails, try ghost join
                                    try:
                                        # Get bot's UID from global context or login data
                                        bot_uid = LoGinDaTaUncRypTinG.AccountUID if hasattr(LoGinDaTaUncRypTinG, 'AccountUID') else TarGeT
                                        
                                        ghost_packet = await ghost_join_packet(bot_uid, CodE, key, iv)
                                        if ghost_packet:
                                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', ghost_packet)
                                            success_message = f" [C][00FF00]✅ SUCCESS! Ghost joining squad with code: {CodE}!\n"
                                            await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)
                                        else:
                                            error_msg = f" [C][FF0000]❌ ERROR! Failed to create ghost join packet.\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                            
                                    except Exception as ghost_error:
                                        print(f"Ghost join also failed: {ghost_error}")
                                        error_msg = f" [C][FF0000]❌ ERROR! Failed to join squad: {str(ghost_error)}\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # NEW GHOST COMMAND
                        if inPuTMsG.strip().startswith('/ghost'):
                            # Process /ghost command in any chat type
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /ghost (team_code)\nExample: /ghost ABC123\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                CodE = parts[1]
                                initial_message = f" [C]{get_random_color()}\nGhost joining squad with code: {CodE}...\n"
                                await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                
                                try:
                                    # Get bot's UID from global context or login data
                                    bot_uid = LoGinDaTaUncRypTinG.AccountUID if hasattr(LoGinDaTaUncRypTinG, 'AccountUID') else TarGeT
                                    
                                    ghost_packet = await ghost_join_packet(bot_uid, CodE, key, iv)
                                    if ghost_packet:
                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', ghost_packet)
                                        success_message = f" [C][00FF00]✅ SUCCESS! Ghost joined squad with code: {CodE}!\n"
                                        await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)
                                    else:
                                        error_msg = f" [C][FF0000]❌ ERROR! Failed to create ghost join packet.\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                        
                                except Exception as e:
                                    error_msg = f" [C][FF0000]❌ ERROR! Ghost join failed: {str(e)}\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # NEW LAG COMMAND
                        if inPuTMsG.strip().startswith('/lag '):
                            print('Processing lag command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /lag (team_code)\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                team_code = parts[1]
                                
                                # Stop any existing lag task
                                if lag_task and not lag_task.done():
                                    lag_running = False
                                    lag_task.cancel()
                                    await asyncio.sleep(0.1)
                                
                                # Start new lag task
                                lag_running = True
                                lag_task = asyncio.create_task(lag_team_loop(team_code, key, iv, region, max_cycles=1500))
                                # SUCCESS MESSAGE
                                success_msg = f" [C][00FF00]✅ SUCCESS! Lag attack started!\nTeam: {team_code}\n"
                                await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)

                        # STOP LAG COMMAND
                        if inPuTMsG.strip() == '/slag':
                            if lag_task and not lag_task.done():
                                lag_running = False
                                lag_task.cancel()
                                success_msg = f" [C][00FF00]✅ SUCCESS! Lag attack stopped successfully!\n"
                                await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                            else:
                                error_msg = f" [C][FF0000]❌ ERROR! No active lag attack to stop!\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        if inPuTMsG.startswith('/solo'):
                            # Process /exit command in any chat type
                            initial_message = f" [C]{get_random_color()}\nLeaving current squad...\n"
                            await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                            
                            leave = await ExiT(uid,key,iv)
                            await SEndPacKeT(whisper_writer , online_writer , 'OnLine' , leave)
                            
                            # SUCCESS MESSAGE
                            success_message = f" [C][00FF00]✅ SUCCESS! Left the squad successfully!\n"
                            await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)

                        if inPuTMsG.strip().startswith('/start'):
                            # Process /s command in any chat type
                            initial_message = f" [C]{get_random_color()}\nStarting match...\n"
                            await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                            
                            EM = await FS(key , iv)
                            await SEndPacKeT(whisper_writer , online_writer , 'OnLine' , EM)
                            
                            # SUCCESS MESSAGE
                            success_message = f" [C][00FF00]✅ SUCCESS! Match starting command sent!\n"
                            await safe_send_message(response.Data.chat_type, success_message, uid, chat_id, key, iv)

                        # NEW GENERAL EMOTE COMMAND - /p
                        if inPuTMsG.strip().startswith('/p '):
                            print('Processing general emote command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 3:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /p [uid1] [uid2] [uid3] [uid4] number(1-{len(GENERAL_EMOTES_MAP)})"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                # Parse uids and number
                                uids = []
                                number = None
                                
                                for part in parts[1:]:
                                    if part.isdigit():
                                        if len(part) <= 3:  # Number should be 1-409 (1-3 digits)
                                            number = part
                                        else:
                                            uids.append(part)
                                    else:
                                        break
                                
                                if not number and parts[-1].isdigit() and len(parts[-1]) <= 3:
                                    number = parts[-1]
                                
                                if not uids or not number:
                                    error_msg = f" [C][FF0000]❌ ERROR! Invalid format! Usage: /p uid1 [uid2] [uid3] [uid4] number(1-{len(GENERAL_EMOTES_MAP)})\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    try:
                                        number_str = str(number)
                                        if number_str not in GENERAL_EMOTES_MAP:
                                            error_msg = f" [C][FF0000]❌ ERROR! Number must be between 1-{len(GENERAL_EMOTES_MAP)} only!\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                        else:
                                            initial_message = f" [C][00FF00]p Processing!...\n"
                                            await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                            
                                            success, result_msg = await general_emote_spam(uids, number_str, key, iv, region)
                                            
                                            if success:
                                                emote_id = GENERAL_EMOTES_MAP[number_str]
                                                success_msg = f" [C][00FF00]✅ SUCCESS!\n"
                                                await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                            else:
                                                error_msg = f" [C][FF0000]❌ ERROR!\n"
                                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                            
                                    except ValueError:
                                        error_msg = f" [C][FF0000]❌ ERROR! Invalid number format! Use 1-{len(GENERAL_EMOTES_MAP)} only.\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # /e EMOTE COMMAND - Single and Multi-UID Support (first-code style)
                        if inPuTMsG.strip().startswith('/e '):
                            try:
                                parts = inPuTMsG.strip().split()

                                # Need at least: /e uid emote_id
                                if len(parts) >= 3:
                                    try:
                                        # SINGLE UID: /e {uid} {emote_id}
                                        if len(parts) == 3:
                                            target_uid = int(parts[1])
                                            emote_id = int(parts[2])

                                            # Processing message
                                            message = f"[B][C]e Processing!"
                                            await safe_send_message(
                                                response.Data.chat_type,
                                                message,
                                                uid,
                                                chat_id,
                                                key,
                                                iv
                                            )

                                            # Send emote once
                                            H = await Emote_k(target_uid, emote_id, key, iv, region)
                                            await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)

                                            confirm_msg = "[00FF00][B]✅ Emote Sent!"
                                            await safe_send_message(
                                                response.Data.chat_type,
                                                confirm_msg,
                                                uid,
                                                chat_id,
                                                key,
                                                iv
                                            )

                                        # MULTI UID: /e {uid1} {uid2} {...} {emote_id}
                                        elif len(parts) >= 4:
                                            uids = []
                                            emote_id = None

                                            # All parameters except last one are UIDs, last one is emote_id
                                            for i, part in enumerate(parts[1:], 1):
                                                if i < len(parts) - 1:  # all but last → UIDs
                                                    if part.isdigit():
                                                        uids.append(int(part))
                                                else:  # last one → emote id
                                                    if part.isdigit():
                                                        emote_id = int(part)

                                            if len(uids) >= 1 and emote_id is not None:
                                                # Processing message
                                                message = (
                                                    f"[B][C]{get_random_color()}\n"
                                                    f"e Processing!\n"
                                                )
                                                await safe_send_message(
                                                    response.Data.chat_type,
                                                    message,
                                                    uid,
                                                    chat_id,
                                                    key,
                                                    iv
                                                )

                                                # Send emote once to each UID
                                                success_count = 0
                                                for target_uid in uids:
                                                    try:
                                                        H = await Emote_k(target_uid, emote_id, key, iv, region)
                                                        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', H)
                                                        success_count += 1
                                                        # no delay – instant per id
                                                    except Exception as e:
                                                        print(f"/e error for {target_uid}: {e}")

                                                confirm_msg = f"[00FF00][B]✅ Multi-Emote Sent!"
                                                await safe_send_message(
                                                    response.Data.chat_type,
                                                    confirm_msg,
                                                    uid,
                                                    chat_id,
                                                    key,
                                                    iv
                                                )
                                            else:
                                                error_msg = (
                                                    "[FF0000]Invalid format. Use:\n"
                                                    "/e [UID] [EMOTE]\n"
                                                    "/e [UID1] [UID2] [UID3] [UID4] [EMOTE]"
                                                )
                                                await safe_send_message(
                                                    response.Data.chat_type,
                                                    error_msg,
                                                    uid,
                                                    chat_id,
                                                    key,
                                                    iv
                                                )
                                        else:
                                            error_msg = (
                                                "[FF0000]Usage: /e [UID] [EMOTE] or "
                                                "/e [UID1] [UID2] [UID3] [UID4] [EMOTE]"
                                            )
                                            await safe_send_message(
                                                response.Data.chat_type,
                                                error_msg,
                                                uid,
                                                chat_id,
                                                key,
                                                iv
                                            )

                                    except ValueError:
                                        error_msg = "[FF0000]Invalid UID or Emote ID. Use numbers only."
                                        await safe_send_message(
                                            response.Data.chat_type,
                                            error_msg,
                                            uid,
                                            chat_id,
                                            key,
                                            iv
                                        )
                                else:
                                    error_msg = (
                                        "[FF0000]Usage: /e [UID] [EMOTE] or "
                                        "/e [UID1] [UID2] [UID3] [UID4] [EMOTE]"
                                    )
                                    await safe_send_message(
                                        response.Data.chat_type,
                                        error_msg,
                                        uid,
                                        chat_id,
                                        key,
                                        iv
                                    )

                            except Exception as e:
                                print(f"Error in /e command: {e}")


                        # Fast emote spam command - works in all chat types
                        if inPuTMsG.strip().startswith('/fe '):
                            print('Processing fast emote spam in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 3:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /fe [uid1] [uid2] [uid3] [uid4] [emoteid]\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                # Parse uids and emoteid
                                uids = []
                                emote_id = None
                                
                                for part in parts[1:]:
                                    if part.isdigit():
                                        if len(part) > 3:  # Assuming UIDs are longer than 3 digits
                                            uids.append(part)
                                        else:
                                            emote_id = part
                                    else:
                                        break
                                
                                if not emote_id and parts[-1].isdigit():
                                    emote_id = parts[-1]
                                
                                if not uids or not emote_id:
                                    error_msg = f" [C][FF0000]❌ ERROR! Invalid format! Usage: /fe [uid1] [uid2] [uid3] [uid4] emoteid\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    # Stop any existing fast spam
                                    if fast_spam_task and not fast_spam_task.done():
                                        fast_spam_running = False
                                        fast_spam_task.cancel()
                                    
                                    # Start new fast spam
                                    fast_spam_running = True
                                    fast_spam_task = asyncio.create_task(fast_emote_spam(uids, emote_id, key, iv, region))
                                    
                                    # SUCCESS MESSAGE
                                    success_msg = f" [C][00FF00]✅ SUCCESS! Fast emote spam started!\n"
                                    await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)

                        # Custom emote spam command - works in all chat types
                        if inPuTMsG.strip().startswith('/fet '):
                            print('Processing custom emote spam in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 4:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /fet (uid) (emote_id) (times)"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                try:
                                    target_uid = parts[1]
                                    emote_id = parts[2]
                                    times = int(parts[3])
                                    
                                    if times <= 0:
                                        error_msg = f" [C][FF0000]❌ ERROR! Times must be greater than 0!\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    elif times > 100:
                                        error_msg = f" [C][FF0000]❌ ERROR! Maximum 100 times allowed for safety!\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    else:
                                        # Stop any existing custom spam
                                        if custom_spam_task and not custom_spam_task.done():
                                            custom_spam_running = False
                                            custom_spam_task.cancel()
                                            await asyncio.sleep(0.5)
                                        
                                        # Start new custom spam
                                        custom_spam_running = True
                                        custom_spam_task = asyncio.create_task(custom_emote_spam(target_uid, emote_id, times, key, iv, region))
                                        
                                        # SUCCESS MESSAGE
                                        success_msg = f" [C][00FF00]✅ SUCCESS! Custom emote spam started!\n"
                                        await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                        
                                except ValueError:
                                    error_msg = f" [C][FF0000]❌ ERROR! Invalid number format! Usage: /fet (uid) (emote_id) (times)\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                except Exception as e:
                                    error_msg = f" [C][FF0000]❌ ERROR!\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # FIXED Spam request command - works in all chat types
                        if inPuTMsG.strip().startswith('/spm'):
                            print('Processing spam request in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /spm (uid)\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                try:
                                    target_uid = parts[1]
                                    
                                    # Stop any existing spam request
                                    if spam_request_task and not spam_request_task.done():
                                        spam_request_running = False
                                        spam_request_task.cancel()
                                        await asyncio.sleep(0.5)
                                    
                                    # Start new spam request
                                    spam_request_running = True
                                    spam_request_task = asyncio.create_task(spam_request_loop(target_uid, key, iv, region))
                                    
                                    # SUCCESS MESSAGE
                                    success_msg = f" [C][00FF00]✅ SUCCESS! Spam request started = {fix_num(target_uid)} \n"
                                    await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                        
                                except Exception as e:
                                    error_msg = f" [C][FF0000]❌ ERROR!\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # Stop spam request command - works in all chat types
                        if inPuTMsG.strip() == '/sspm':
                            if spam_request_task and not spam_request_task.done():
                                spam_request_running = False
                                spam_request_task.cancel()
                                await asyncio.sleep(0.5)
                                success_msg = f" [C][00FF00]✅ SUCCESS! Spam request stopped successfully!\n"
                                await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                            else:
                                error_msg = f" [C][FF0000]❌ ERROR! No active spam request to stop!\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # NEW /evo Command - /evo uid1 uid2 uid3 uid4 uid5 emote_number
                        if inPuTMsG.strip().startswith('/evo '):
                            print('Processing /evo command with multiple IDs...')

                            parts = inPuTMsG.strip().split()

                            # Need at least: /evo uid emote_number
                            if len(parts) < 3:
                                error_msg = (
                                    "[C][B][FF0000]Usage: /evo [uid1] [uid2] [uid3] [uid4] [uid5] emote_number(1-21)"
                                )
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                # Last argument is emote number, previous are UIDs
                                raw_args = parts[1:]

                                emote_number_str = raw_args[-1]
                                uid_parts = raw_args[:-1]

                                target_ids = []
                                for p in uid_parts:
                                    if p.isdigit():
                                        target_ids.append(p)
                                    if len(target_ids) >= 5:
                                        break

                                # If no valid IDs given, default to sender
                                if not target_ids:
                                    target_ids = [str(uid)]

                                # Validate emote number
                                if not emote_number_str.isdigit():
                                    error_msg = "[C][B][FF0000]Emote number must be numeric (1-21)!"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    emote_choice = int(emote_number_str)

                                    # Mapping of EVOS choices to emote IDs
                                    evo_emotes = {
                                        1:  909000063,   # AK
                                        2:  909000068,   # SCAR
                                        3:  909000075,   # 1st MP40
                                        4:  909000081,   # 1st M1014
                                        5:  909000085,   # XM8
                                        6:  909000098,   # UMP
                                        7:  909000090,   # Famas
                                        8:  909033002,   # Mp5
                                        9:  909035007,   # M1887
                                        10: 909033001,   # M4A1
                                        11: 909037011,   # FIST
                                        12: 909035012,   # AN94
                                        13: 909038010,   # Thompson
                                        14: 909039011,   # 2nd M1014
                                        15: 909040010,   # 2nd MP40
                                        16: 909041005,   # Groza
                                        17: 909042008,   # Woodpecker
                                        18: 909045001,   # Parafal
                                        19: 909049010,   # P90
                                        20: 909038012,   # G18
                                        21: 909051003    # M60
                                    }

                                    emote_id = evo_emotes.get(emote_choice)

                                    if not emote_id:
                                        error_msg = "[C][B][FF0000]Emote number must be between 1 and 21!"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                    else:
                                        # Info message
                                        intro_msg = (
                                            "[C][B][1E90FF]evo Processing!\n"
                                        )
                                        await safe_send_message(response.Data.chat_type, intro_msg, uid, chat_id, key, iv)

                                        try:
                                            sent_count = 0

                                            # Send selected emote ONCE to each target id
                                            for target in target_ids:
                                                try:
                                                    emote_packet = await Emote_k(
                                                        int(target),
                                                        int(emote_id),
                                                        key,
                                                        iv,
                                                        region
                                                    )
                                                    await SEndPacKeT(whisper_writer, online_writer, 'OnLine', emote_packet)
                                                    sent_count += 1
                                                except Exception as e:
                                                    print(f"Error sending EVOS emote")

                                            done_msg = (
                                                f"[C][B][00FF00]complete!\n"
                                            )
                                            await safe_send_message(response.Data.chat_type, done_msg, uid, chat_id, key, iv)

                                        except Exception as e:
                                            err_msg = f"[C][B][FF0000]Error in /evo command: {str(e)}"
                                            await safe_send_message(response.Data.chat_type, err_msg, uid, chat_id, key, iv)


                        if inPuTMsG.strip().startswith('/sevo '):
                            print('Processing evo_fast command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 2:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /sevo [uid1] [uid2] [uid3] [uid4] number(1-21)"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                # Parse uids and number
                                uids = []
                                number = None
                                
                                for part in parts[1:]:
                                    if part.isdigit():
                                        if len(part) <= 2:  # Number should be 1-21 (1 or 2 digits)
                                            number = part
                                        else:
                                            uids.append(part)
                                    else:
                                        break
                                
                                if not number and parts[-1].isdigit() and len(parts[-1]) <= 2:
                                    number = parts[-1]
                                
                                if not uids or not number:
                                    error_msg = f" [C][FF0000]❌ ERROR! Invalid format! Usage: /sevo [uid1] [uid2] [uid3] [uid4] number(1-21)\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    try:
                                        number_int = int(number)
                                        if number_int not in EMOTE_MAP:
                                            error_msg = f" [C][FF0000]❌ ERROR! Number must be between 1-21 only!\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                        else:
                                            # Stop any existing evo_fast spam
                                            if evo_fast_spam_task and not evo_fast_spam_task.done():
                                                evo_fast_spam_running = False
                                                evo_fast_spam_task.cancel()
                                                await asyncio.sleep(0.5)
                                            
                                            # Start new evo_fast spam
                                            evo_fast_spam_running = True
                                            evo_fast_spam_task = asyncio.create_task(evo_fast_emote_spam(uids, number_int, key, iv, region))
                                            
                                            # SUCCESS MESSAGE
                                            emote_id = EMOTE_MAP[number_int]
                                            success_msg = f" [C][00FF00]✅ SUCCESS! Fast evolution emote spam started!\n"
                                            await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                            
                                    except ValueError:
                                        error_msg = f" [C][FF0000]❌ ERROR! Invalid number format! Use 1-21 only.\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # NEW EVO_CUSTOM COMMAND
                        if inPuTMsG.strip().startswith('/scevo '):
                            print('Processing scevo command in any chat type')
                            
                            parts = inPuTMsG.strip().split()
                            if len(parts) < 3:
                                error_msg = f" [C][FF0000]❌ ERROR! Usage: /scevo [uid1] [uid2] [uid3] [uid4] number(1-21) time(1-100)"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                            else:
                                # Parse uids, number, and time
                                uids = []
                                number = None
                                time_val = None
                                
                                for part in parts[1:]:
                                    if part.isdigit():
                                        if len(part) <= 2:  # Number or time should be 1-100 (1, 2, or 3 digits)
                                            if number is None:
                                                number = part
                                            elif time_val is None:
                                                time_val = part
                                            else:
                                                uids.append(part)
                                        else:
                                            uids.append(part)
                                    else:
                                        break
                                
                                # If we still don't have time_val, try to get it from the last part
                                if not time_val and len(parts) >= 3:
                                    last_part = parts[-1]
                                    if last_part.isdigit() and len(last_part) <= 3:
                                        time_val = last_part
                                        # Remove time_val from uids if it was added by mistake
                                        if time_val in uids:
                                            uids.remove(time_val)
                                
                                if not uids or not number or not time_val:
                                    error_msg = f" [C][FF0000]❌ ERROR! Invalid format! Usage: /scevo [uid1] [uid2] [uid3] [uid4] number(1-21) time(1-100)\n"
                                    await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                else:
                                    try:
                                        number_int = int(number)
                                        time_int = int(time_val)
                                        
                                        if number_int not in EMOTE_MAP:
                                            error_msg = f" [C][FF0000]❌ ERROR! Number must be between 1-21 only!\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                        elif time_int < 1 or time_int > 100:
                                            error_msg = f" [C][FF0000]❌ ERROR! Time must be between 1-100 only!\n"
                                            await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)
                                        else:
                                            # Stop any existing evo_custom spam
                                            if evo_custom_spam_task and not evo_custom_spam_task.done():
                                                evo_custom_spam_running = False
                                                evo_custom_spam_task.cancel()
                                                await asyncio.sleep(0.5)
                                            
                                            # Start new evo_custom spam
                                            evo_custom_spam_running = True
                                            evo_custom_spam_task = asyncio.create_task(evo_custom_emote_spam(uids, number_int, time_int, key, iv, region))
                                            
                                            # SUCCESS MESSAGE
                                            emote_id = EMOTE_MAP[number_int]
                                            success_msg = f" [C][00FF00]✅ SUCCESS! Custom evolution emote spam started!\n"
                                            await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                            
                                    except ValueError:
                                        error_msg = f" [C][FF0000]❌ ERROR! Invalid number/time format! Use numbers only.\n"
                                        await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # NEW: Manual group update command
                        if inPuTMsG.strip() == '/update_group':
                            try:
                                # Try to get group members from current squad data
                                # This is a fallback if automatic detection doesn't work
                                initial_message = f" [C]{get_random_color()}\nUpdating group members list...\n"
                                await safe_send_message(response.Data.chat_type, initial_message, uid, chat_id, key, iv)
                                
                                # Add current command sender to group members
                                if uid not in current_group_members:
                                    current_group_members.append(uid)
                                    
                                success_msg = f" [C][00FF00]✅ Group members updated! Current count\n"
                                await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                                
                            except Exception as e:
                                error_msg = f" [C][FF0000]❌ ERROR updating group\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # Stop evo_fast spam command
                        if inPuTMsG.strip() == '/sfe':
                            if evo_fast_spam_task and not evo_fast_spam_task.done():
                                evo_fast_spam_running = False
                                evo_fast_spam_task.cancel()
                                success_msg = f" [C][00FF00]✅ SUCCESS! Evolution fast spam stopped successfully!\n"
                                await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                            else:
                                error_msg = f" [C][FF0000]❌ ERROR! No active evolution fast spam to stop!\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # Stop evo_custom spam command
                        if inPuTMsG.strip() == '/stop evo_c':
                            if evo_custom_spam_task and not evo_custom_spam_task.done():
                                evo_custom_spam_running = False
                                evo_custom_spam_task.cancel()
                                success_msg = f" [C][00FF00]✅ SUCCESS! Evolution custom spam stopped successfully!\n"
                                await safe_send_message(response.Data.chat_type, success_msg, uid, chat_id, key, iv)
                            else:
                                error_msg = f" [C][FF0000]❌ ERROR! No active evolution custom spam to stop!\n"
                                await safe_send_message(response.Data.chat_type, error_msg, uid, chat_id, key, iv)

                        # FIXED HELP MENU SYSTEM - Now with updated dance command
                        if inPuTMsG.strip().lower() in ("/menu", "/help"):
                            print(f"Help command detected from UID: {uid} in chat type: {response.Data.chat_type}")
                            
                            # Menu 1 - Basic Commands
                            menu1 = f'''[C] [FF0000]╔══════════╗
[C][B][FF8800] GROUP COMMANDS 1
[C][B][FFFF00]────────────

[00FF00]/🙃3  -> [FFFFFF]3-Player Group
[00FF00]/🙃5  -> [FFFFFF]5-Player Group
[00FF00]/🙃6  -> [FFFFFF]6-Player Group
[FFFFFF]⚡Join Team via Code:
[00FFFF]⚡/🙃join [TeamCode]
[FFFFFF]⚡Leave Squad & Go Solo
[00FFFF]⚡/🙃solo
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu1, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)

                            menu111 = f'''[C] [FF0000]╔══════════╗
[C][B][FF8800] GROUP COMMANDS 2
[C][B][FFFF00]────────────

[FFFFFF]⚡Invite Player to Team:
[00FFFF]⚡/🙃inv [UID]
[FFFFFF]⚡Reject Spam:
[00FFFF]⚡/🙃rej [UID]
[FFFFFF]⚡Stop Reject Spam:
[00FFFF]⚡/🙃srej [UID]
[FFFFFF]⚡Get player bio by uid
[00FFFF]⚡/🙃bio [uid]
[FFFFFF]⚡Send custom spam message
[00FFFF]⚡/🙃ms <text>
[FFFFFF]⚡BoT Look Change
[00FFFF]⚡/🙃b1-/🙃b11
[FFFFFF]⚡Check Player Status
[00FFFF]⚡/🙃status [uid]
[FFFFFF]⚡send titile in team chat
[00FFFF]⚡/🙃title
[FFFFFF]⚡dont message noob in team chat
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu111, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)

                            menu7 = f'''[C] [FF0000]╔══════════╗
[C][B][DFFF00] LEVEL UP & START
[C][B][FFFF00]────────────

[FFF5EE]⚡Force start team:
[FF3131]⚡/🙃start [TeamCode]
[FBEC5D]⚠︎ Level up bot info 
╰┈➤Select lone wolf headshot 
ㅤㅤduel 1 vs 1 mode ✌︎︎
[FFF5EE]⚡level up auto force start 24/7:
[FF3131]⚡/🙃auto [TeamCode]
[FFF5EE]⚡Stop level up:
[FF3131]⚡/🙃sauto
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu7, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)

                            # Menu 2 - Advanced Commands
                            menu2 = '''[C] [FF0000]╔══════════╗
[C][B][FF8800] EMOTE COMMANDS 1
[C][B][FFFF00]────────
[C][B][FF8800] NORMAL EMOTE COMMANDS
[C][B][FFFF00]────────────

[FFFFFF]⚡Play emote without emote id 
[FFA500]⚡/🙃p [uid1] [uid2] [uid3] [uid4] [1-409]
[FFFFFF]⚡ Play Loops Emotes
[FFA500]⚡/🙃loop [uid1] [uid2] [uid3] [uid4] [1-43]
[FFFFFF]⚡Play emote with emote id 
[FFA500]⚡/🙃e [uid1] [uid2] [uid3] [uid4] [emote id]
[FFFFFF]⚡Spam Emote with count 1-100
[FFA500]⚡/🙃fet [uid1] [uid2] [uid3] [uid4] [emote id] [count]
[FFFFFF]⚡Each UID Get Random Emote
[FFA500]⚡/🙃dance [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ Each UID Get Random Loop Emote
[FFA500]⚡/🙃rloop [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ob52 new emotes 
[FFA500]⚡/🙃new [uid1] [uid2] [uid3] [uid4] [1-15]
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu2, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)
                            
                            # Menu 3 - Advanced Commands
                            menu3 = '''[C] [FF0000]╔══════════╗
[C][B][FF8800] EMOTE COMMANDS 2
[C][B][FFFF00]────────
[C][B][FF8800] EVO MAX EMOTE COMMANDS
[C][B][FFFF00]────────────

[FFFFFF]⚡ Play Max Evo Gun Emote
[FFA500]⚡/🙃evo [uid1] [uid2] [uid3] [uid4] [1-21]
[FFFFFF]⚡Spam Max Emote with count 1-100
[FFA500]⚡/🙃scevo [uid1] [uid2] [uid3] [uid4] [1-21] [count]
[FFFFFF]⚡ Play Max Evo Group 1 to 21 Emotes
[FFA500]⚡/🙃max [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ Stop Running Max Evo loop
[FFA500]⚡/🙃smax
[FFFFFF]⚡ Play Random Max Evo Group 21 Emotes
[FFA500]⚡/🙃rnd [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ Stop Running Random Max Evo
[FFA500]⚡/🙃srnd
[FFFFFF]⚡Each UID Get Random Max Emote
[FFA500]⚡/🙃rmax [uid1] [uid2] [uid3] [uid4]
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu3, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)
                            # Menu 4 - Advanced Commands
                            menu44 = '''[C] [FF0000]╔══════════╗
[C][B][FF8800] EMOTE COMMANDS 3
[C][B][FFFF00]────────
[C][B][FF8800] USE EMOTE WITHOUT BOT IN GROUP
[C][B][FFFF00]────────────

[FFFFFF]⚡ Play Emote with team code and leave bot
[FFA500]⚡/🙃jel [team code] [uid1] [uid2] [uid3] [uid4] [emote id]
[FFFFFF]⚡ Play emote without emote id
[FFA500]⚡/🙃jp [team code] [uid1] [uid2] [uid3] [uid4] [uid5] [1-408]
[FFFFFF]⚡ Play Max Evo Emote
[FFA500]⚡/🙃jevo [team code] [uid1] [uid2] [uid3] [uid4] [uid5] [1-21]
[FFFFFF]⚡ Each UID Get Random Max Emote
[FFA500]⚡/🙃jrevo [team code] [uid1] [uid2] [uid3] [uid4] [uid5]
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu44, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)
                            
                            # Menu 5 - Emote Commands
                            menu5 = f'''[C] [FF0000]╔══════════╗
[C][B][FF0000] ATTACK / LAG COMMANDS
[C][B][FFFF00]────────────

[FFFFFF]⚡Spam Join Request
[00FFFF]⚡/🙃sm [uid]
[FFFFFF]⚡Join Req Craftland Badge
[00FFFF]⚡/🙃s1 [uid]
[FFFFFF]⚡Join Req New V-Badge
[00FFFF]⚡/🙃s2 [uid]
[FFFFFF]⚡Join Req Moderator Badge
[00FFFF]⚡/🙃s3 [uid]
[FFFFFF]⚡Join Req Small V-Badge
[00FFFF]⚡/🙃s4 [uid]
[FFFFFF]⚡Join Req Pro Badge
[00FFFF]⚡/🙃s5 [uid]
[FFFFFF]⚡Stop Spam Request 
[00FFFF]⚡/🙃ssm
[FFFFFF]⚡Spam Invite 
[00FFFF]⚡/🙃spm [UID]
[FFFFFF]⚡Stop Spam Invite 
[00FFFF]⚡/🙃sspm
[FFFFFF]⚡Spam Join Request Room
[00FFFF]⚡/🙃room [uid]
[FFFFFF]⚡Stop Spam Join Request Room 
[00FFFF]⚡/🙃sroom
[FFFFFF]⚡Lag Any Team
[00FFFF]⚡/🙃lag [teamcode]
[FFFFFF]⚡Stop lag 
[00FFFF]⚡/🙃slag
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu5, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)
                            
                            # Menu 6 - Advanced Commands
                            menu6 = '''[C] [FF0000]╔══════════╗
[C][B][00CED1] GENERAL COMMANDS
[C][B][FFFF00]────────────

[00FF00]/🙃owner -> [FFFFFF]Know Bot's Owner 
[00FF00]/🙃admin -> [FFFFFF]Show Admin Menu
[ADEAEA]/🙃help -> [FFFFFF]Show Full Menu
[ADEAEA]/🙃group -> [FFFFFF]Show Group Menu
[ADEAEA]/🙃emote -> [FFFFFF]Show Emote Menu
[ADEAEA]/🙃attack -> [FFFFFF]Show Attack Menu
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu6, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)
                            

                        if inPuTMsG.strip() == "/emote":
                            menu22 = f'''[C] [FF0000]╔══════════╗
[C][B][FF8800] EMOTE COMMANDS 1
[C][B][FFFF00]────────
[C][B][FF8800] NORMAL EMOTE COMMANDS
[C][B][FFFF00]────────────

[FFFFFF]⚡Play emote without emote id 
[FFA500]⚡/🙃p [uid1] [uid2] [uid3] [uid4] [1-409]
[FFFFFF]⚡ Play Loops Emotes
[FFA500]⚡/🙃loop [uid1] [uid2] [uid3] [uid4] [1-43]
[FFFFFF]⚡Play emote with emote id 
[FFA500]⚡/🙃e [uid1] [uid2] [uid3] [uid4] [emote id]
[FFFFFF]⚡Spam Emote with count 1-100
[FFA500]⚡/🙃fet [uid1] [uid2] [uid3] [uid4] [emote id] [count]
[FFFFFF]⚡Each UID Get Random Emote
[FFA500]⚡/🙃dance [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ Each UID Get Random Loop Emote
[FFA500]⚡/🙃rloop [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ob52 new emotes 
[FFA500]⚡/🙃new [uid1] [uid2] [uid3] [uid4] [1-15]
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu22, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)
                            
                            # Menu 2 - Advanced Commands
                            menu33 = '''[C] [FF0000]╔══════════╗
[C][B][FF8800] EMOTE COMMANDS 2
[C][B][FFFF00]────────
[C][B][FF8800] EVO MAX EMOTE COMMANDS
[C][B][FFFF00]────────────

[FFFFFF]⚡ Play Max Evo Gun Emote
[FFA500]⚡/🙃evo [uid1] [uid2] [uid3] [uid4] [1-21]
[FFFFFF]⚡Spam Max Emote with count 1-100
[FFA500]⚡/🙃scevo [uid1] [uid2] [uid3] [uid4] [1-21] [count]
[FFFFFF]⚡ Play Max Evo Group 1 to 21
[FFA500]⚡/🙃max [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ Stop Running Max Evo loop
[FFA500]⚡/🙃smax
[FFFFFF]⚡ Play Random Max Evo Group
[FFA500]⚡/🙃rnd [uid1] [uid2] [uid3] [uid4]
[FFFFFF]⚡ Stop Running Random Max Evo
[FFA500]⚡/🙃srnd
[FFFFFF]⚡Each UID Get Random Max Emote
[FFA500]⚡/🙃rmax [uid1] [uid2] [uid3] [uid4]
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu33, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)

                            # Menu 3 - Advanced Commands
                            menu44 = '''[C] [FF0000]╔══════════╗
[C][B][FF8800] EMOTE COMMANDS 3
[C][B][FFFF00]────────
[C][B][FF8800] USE EMOTE WITHOUT BOT IN GROUP
[C][B][FFFF00]────────────

[FFFFFF]⚡ Play Emote with team code and leave bot
[FFA500]⚡/🙃jel [team code] [uid1] [uid2] [uid3] [uid4] [emote id]
[FFFFFF]⚡ Play emote without emote id
[FFA500]⚡/🙃jp [team code] [uid1] [uid2] [uid3] [uid4] [uid5] [1-408]
[FFFFFF]⚡ Play Max Evo Emote
[FFA500]⚡/🙃jevo [team code] [uid1] [uid2] [uid3] [uid4] [uid5] [1-21]
[FFFFFF]⚡ Each UID Get Random Max Emote
[FFA500]⚡/🙃jrevo [team code] [uid1] [uid2] [uid3] [uid4] [uid5]
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu44, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)

                        # ADDITIONAL MENU PAGES - Separate detection for menu2 and menu3
                        elif inPuTMsG.strip() == "/group":
                            menu11 = '''[C] [FF0000]╔══════════╗
[C][B][FF8800] GROUP COMMANDS 1
[C][B][FFFF00]────────────

[00FF00]/🙃3  -> [FFFFFF]3-Player Group
[00FF00]/🙃5  -> [FFFFFF]5-Player Group
[00FF00]/🙃6  -> [FFFFFF]6-Player Group
[FFFFFF]⚡Join Team via Code:
[00FFFF]⚡/🙃join [TeamCode]
[FFFFFF]⚡Leave Squad & Go Solo
[00FFFF]⚡/🙃solo
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu11, uid, chat_id, key, iv)

                            menu1111 = f'''[C] [FF0000]╔══════════╗
[C][B][FF8800] GROUP COMMANDS 2
[C][B][FFFF00]────────────

[FFFFFF]⚡Invite Player to Team:
[00FFFF]⚡/🙃inv [UID]
[FFFFFF]⚡Reject Spam:
[00FFFF]⚡/🙃rej [UID]
[FFFFFF]⚡Stop Reject Spam:
[00FFFF]⚡/🙃srej [UID]
[FFFFFF]⚡Get player bio by uid
[00FFFF]⚡/🙃bio [uid]
[FFFFFF]⚡Send custom spam message
[00FFFF]⚡/🙃ms <text>
[FFFFFF]⚡BoT Look Change
[00FFFF]⚡/🙃b1-/🙃b11
[FFFFFF]⚡Check Player Status
[00FFFF]⚡/🙃status [uid]
[FFFFFF]⚡send titile in team chat
[00FFFF]⚡/🙃title
[FFFFFF]⚡dont message noob in team chat
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu1111, uid, chat_id, key, iv)
                            
                            await asyncio.sleep(0.5)  

                        elif inPuTMsG.strip() == "/attack":
                            menu55 = f'''[C] [FF0000]╔══════════╗
[C][B][FF0000] ATTACK / LAG COMMANDS
[C][B][FFFF00]────────────

[FFFFFF]⚡Spam Join Request
[00FFFF]⚡/🙃sm [uid]
[FFFFFF]⚡Join Req Craftland Badge
[00FFFF]⚡/🙃s1 [uid]
[FFFFFF]⚡Join Req New V-Badge
[00FFFF]⚡/🙃s2 [uid]
[FFFFFF]⚡Join Req Moderator Badge
[00FFFF]⚡/🙃s3 [uid]
[FFFFFF]⚡Join Req Small V-Badge
[00FFFF]⚡/🙃s4 [uid]
[FFFFFF]⚡Join Req Pro Badge
[00FFFF]⚡/🙃s5 [uid]
[FFFFFF]⚡Stop Spam Request 
[00FFFF]⚡/🙃ssm
[FFFFFF]⚡Spam Invite
[00FFFF]⚡/🙃spm [UID]
[FFFFFF]⚡Stop Spam Invite 
[00FFFF]⚡/🙃sspm
[FFFFFF]⚡Spam Join Request Room
[00FFFF]⚡/🙃room [uid]
[FFFFFF]⚡Stop Spam Join Request Room 
[00FFFF]⚡/🙃sroom
[FFFFFF]⚡Lag Any Team
[00FFFF]⚡/🙃lag [teamcode]
[FFFFFF]⚡Stop lag 
[00FFFF]⚡/🙃slag
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu55, uid, chat_id, key, iv)

                            await asyncio.sleep(0.5)  

                        elif inPuTMsG.strip() == "/levelup":
                            menu77 = f'''[C] [FF0000]╔══════════╗
[C][B][DFFF00] LEVEL UP & START
[C][B][FFFF00]────────────

[FFF5EE]⚡Force start team:
[FF3131]⚡/🙃start [TeamCode]
[FBEC5D]⚠︎ Level up bot info 
╰┈➤Select lone wolf headshot 
ㅤㅤduel 1 vs 1 mode ✌︎︎
[FFF5EE]⚡level up auto force start 24/7:
[FF3131]⚡/🙃auto [TeamCode]
[FFF5EE]⚡Stop level up:
[FF3131]⚡/🙃sauto
[FF0000]╚══════════╝'''
                            
                            await safe_send_message(response.Data.chat_type, menu77, uid, chat_id, key, iv)

                        # BOT STATUS COMMAND
                        elif inPuTMsG.strip().lower() in ("status", "/status", "info", "/info", "bot", "/bot"):
                            bot_status = f"""
 [C][00FF00]🤖 BOT STATUS

[FFFFFF]🤖 Bot Name: [00FF00]{LoGinDaTaUncRypTinG.AccountName if hasattr(LoGinDaTaUncRypTinG, 'AccountName') else 'TOM Bot'}
[FFFFFF]🆔 Bot UID: [00FF00]{TOM}
[FFFFFF]🌍 Region: [00FF00]{region}
[FFFFFF]⚡ Status: [00FF00]ONLINE & WORKING
[FFFFFF]📊 Connection: [00FF00]STABLE
[FFFFFF]🎮 Features: [00FF00]ALL ACTIVE
[FFFFFF]😎 Emotes Available: [00FF00]{len(GENERAL_EMOTES_MAP)} emotes

[C] [FFB300]👑 Developed by: Tom 
[00FF00]━━━━━━━━━━━━"""
                            
                            await safe_send_message(response.Data.chat_type, bot_status, uid, chat_id, key, iv)
                        response = None
                            
            whisper_writer.close() ; await whisper_writer.wait_closed() ; whisper_writer = None
                    
                    	
                    	
        except Exception as e: print(f"ErroR {ip}:{port} - {e}") ; whisper_writer = None
        await asyncio.sleep(reconnect_delay)


def api_add_friend(guest_uid, guest_password, target_uid):
    try:
        url = f"https://kallu-add-friend.vercel.app/adding_friend?uid={guest_uid}&password={guest_password}&friend_uid={target_uid}"
        response = requests.get(url, timeout=15)
        return f"[B][C][00FF00]Friend Add Request:\n[FFFFFF]{response.text}"
    except Exception as e:
        return f"[B][C][FF0000]API Error: {str(e)}"

def api_remove_friend(guest_uid, guest_password, target_uid):
    try:
        url = f"https://kallu-add-friend.vercel.app/remove_friend?uid={guest_uid}&password={guest_password}&friend_uid={target_uid}"
        response = requests.get(url, timeout=15)
        return f"[B][C][00FF00]Friend Remove Request:\n[FFFFFF]{response.text}"
    except Exception as e:
        return f"[B][C][FF0000]API Error: {str(e)}"

def api_join_guild(guest_uid, guest_password, guild_id):
    try:
        url = f"https://guild-info-danger.vercel.app/join?guild_id={guild_id}&uid={guest_uid}&password={guest_password}"
        response = requests.get(url, timeout=15)
        return f"[B][C][00FF00]Guild Join Request:\n[FFFFFF]{response.text}"
    except Exception as e:
        return f"[B][C][FF0000]API Error: {str(e)}"

def api_leave_guild(guest_uid, guest_password, guild_id):
    try:
        url = f"https://guild-info-danger.vercel.app/leave?guild_id={guild_id}&uid={guest_uid}&password={guest_password}"
        response = requests.get(url, timeout=15)
        return f"[B][C][00FF00]Guild Leave Request:\n[FFFFFF]{response.text}"
    except Exception as e:
        return f"[B][C][FF0000]API Error: {str(e)}"

async def MaiiiinE(Uid, Pw, cmd_queue=None):
    # Uid , Pw = '4359921572','DBC9642B13EA00503EDA56EF854E50AEA4FB832D28DA3240A8D5A71789F3AC38'
    

    open_id , access_token = await GeNeRaTeAccEss(Uid , Pw)
    if not open_id or not access_token: print("ErroR - InvaLid AccounT") ; return None
    
    PyL = await EncRypTMajoRLoGin(open_id , access_token)
    MajoRLoGinResPonsE = await MajorLogin(PyL)
    if not MajoRLoGinResPonsE: print("TarGeT AccounT => BannEd / NoT ReGisTeReD ! ") ; return None
    
    MajoRLoGinauTh = await DecRypTMajoRLoGin(MajoRLoGinResPonsE)
    UrL = MajoRLoGinauTh.url
    # In the MaiiiinE function, find and comment out these print statements:
    print("🔄 Starting TCP Connections...")
    print("📡 Connecting to Free Fire servers...")
    print("🌐 Server connection established")

    region = MajoRLoGinauTh.region

    ToKen = MajoRLoGinauTh.token
    print("🔐 Authentication successful")
    TarGeT = MajoRLoGinauTh.account_uid
    global bot_uid
    bot_uid = TarGeT
    key = MajoRLoGinauTh.key
    iv = MajoRLoGinauTh.iv
    timestamp = MajoRLoGinauTh.timestamp
    
    LoGinDaTa = await GetLoginData(UrL , PyL , ToKen)
    if not LoGinDaTa: print("ErroR - GeTinG PorTs From LoGin DaTa !") ; return None
    LoGinDaTaUncRypTinG = await DecRypTLoGinDaTa(LoGinDaTa)
    OnLinePorTs = LoGinDaTaUncRypTinG.Online_IP_Port
    ChaTPorTs = LoGinDaTaUncRypTinG.AccountIP_Port
    OnLineiP , OnLineporT = OnLinePorTs.split(":")
    ChaTiP , ChaTporT = ChaTPorTs.split(":")
    acc_name = LoGinDaTaUncRypTinG.AccountName
    #print(acc_name)
    
    equie_emote(ToKen,UrL)
    AutHToKen = await xAuThSTarTuP(int(TarGeT) , ToKen , int(timestamp) , key , iv)
    ready_event = asyncio.Event()
    
    task1 = asyncio.create_task(TcPChaT(ChaTiP, ChaTporT , AutHToKen , key , iv , LoGinDaTaUncRypTinG , ready_event ,region, TarGeT, Pw, cmd_queue))
    task2 = asyncio.create_task(TcPOnLine(OnLineiP , OnLineporT , key , iv , AutHToKen, region, TarGeT))  

    print("Initializing Bot...")
    print("┌────────────────────────────────────┐")
    print("│ █████████████░░░░░░░░░░░░░░░░░░ │")
    print("└────────────────────────────────────┘")
    time.sleep(0.5)
    print("Connecting to Free Fire servers...")
    print("┌────────────────────────────────────┐")
    print("│ ██████████████████████░░░░░░░░░░░░ │")
    print("└────────────────────────────────────┘")
    time.sleep(0.5)

    print("🤖 BOT - ONLINE")
    print("┌────────────────────────────────────┐")
    print("│ ██████████████████████████████████ │")
    print("└────────────────────────────────────┘")
    print(f"🔹 UID: {TarGeT}")
    print(f"🔹 Name: {acc_name}")
    print(f"🔹 Status: 🟢 READY")
    print("")
    print("💡 Type /help for commands")
    await asyncio.gather(task1, task2)
    time.sleep(0.5)
    await ready_event.wait()
    await asyncio.sleep(1)

    print(render('TOM', colors=['white', 'green'], align='center'))
    print('')
    print("🤖 BOT - ONLINE")
    print(f"🔹 UID: {TarGeT}")
    print(f"🔹 Name: {acc_name}")
    print(f"🔹 Status: 🟢 READY")
    


def handle_keyboard_interrupt(signum, frame):
    """Clean handling for Ctrl+C"""
    print("\n\n🛑 Bot shutdown requested...")
    print("👋 Thanks for using CODEX")
    sys.exit(0)

# Register the signal handler
signal.signal(signal.SIGINT, handle_keyboard_interrupt)
    
async def StarTinG(Uid, Pw, cmd_queue=None):
    while True:
        try:
            await asyncio.wait_for(MaiiiinE(Uid, Pw, cmd_queue) , timeout = 7 * 60 * 60)
        except KeyboardInterrupt:
            print("\n\n🛑 Bot shutdown by user")
            print("👋 Thanks for using CODEX!")
            break
        except asyncio.TimeoutError: print("Token ExpiRed ! , ResTartinG")
        except Exception as e: print(f"ErroR TcP - {e} => ResTarTinG ...")

# ------------------------------------------------- TELEGRAM BOT CONFIGURATION -------------------------------------------------
# **IMPORTANT**: Replace these placeholders with your actual values
BOT_TOKEN = "8598370793:AAHx3xUAXPhPKkao9kftjIHk7f-vrlGNPco" # Use the token from Visit-Bot.py
YOUR_BOT_USERNAME = "@TCP_TOM_BOT"     # WITHOUT @ NAME, e.g., 'MyAwesomeBot'

DEVELOPER_NAME = "@THEROSHANCODEX07"
CREDIT = "@THEROSHANCODEX07"
OWNER_NAME = "@THEROSHANCODEX07"
OWNER_URL = "t.me/THEROSHANCODEX"

# GROUPS & CHANNEL (From Visit-Bot.py)
GROUP_1 = "PAIDSOUCRECODEX"
GROUP_2 = "theroshancodex07chatgroup"
CHANNEL = "theroshancodex"

# ------------------------------------------------- TELEGRAM BOT APIS ----------------------------------------------------------
ULTRA_API_URL = "https://checkregion-api.vercel.app/region?uid={uid}"
BANCHECK_API_URL = "https://ff.garena.com/api/antihack/check_banned?lang=en&uid={uid}"
API_VISIT_BASE = "https://spamxvisit-wotaxxdev-api.vercel.app/visits?uid={uid}&region=ind"
# This API is used for both /cklike and get command
API_INFO_URL = "http://danger-info-alpha.vercel.app/accinfo?uid={uid}&key=DANGERxINFO"
# -----------------------------------------------------------------------------------------------------------------

# INITIALIZE BOT
# Using Markdown as the primary parse mode for consistent style
bot = telebot.TeleBot(BOT_TOKEN, parse_mode="Markdown")
# logging.basicConfig(level=logging.INFO) # Disabled to avoid cluttering main logs
logger = logging.getLogger(__name__)

# ------------------------------------------------- TELEGRAM COMMAND LOGGING -------------------------------------------------
original_process_new_messages = bot.process_new_messages

def logging_middleware(messages):
    for message in messages:
        if message.text:
            # Print User ID and Command/Message to terminal
            print(f"User ID: {message.from_user.id} Command: {message.text}")
    original_process_new_messages(messages)

bot.process_new_messages = logging_middleware
# -----------------------------------------------------------------------------------------------------------------------------

def log_cmd(message):
    """Legacy logger helper - now handled by middleware but kept for compatibility"""
    pass

# Headers for Ban Check API
BANCHECK_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'authority': 'ff.garena.com',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'referer': 'https://ff.garena.com/en/support/',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'x-requested-with': 'B6FksShzIgjfrYImLpTsadjS86sddhFH',
}


# ------------------------------------------------- TELEGRAM BOT UTILITY FUNCTIONS ---------------------------------------------

def sanitize_markdown(text):
    """Removes Markdown special characters for safe message display."""
    if text is None:
        return "N/A"
    if not isinstance(text, str):
        text = str(text)
    # Escape characters used by Telegram Markdown V1
    return text.replace("*", "").replace("_", "").replace("[", "").replace("`", "").strip()

def is_valid_uid(uid: str) -> bool:
    """Checks if UID is a valid length of digits."""
    return uid.isdigit() and 8 <= len(uid) <= 11

# ======================================================================================================================
# LEVELUP / AUTO HELPER FUNCTIONS
# ======================================================================================================================

def load_levelup_accounts():
    """Loads accounts from levelup.json."""
    if not os.path.exists(LEVELUP_FILE):
        return {}
    try:
        with open(LEVELUP_FILE, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading levelup.json: {e}")
        return {}

def load_tembsave():
    """Loads state from tembsave.json."""
    if not os.path.exists(TEMBSAVE_FILE):
        return {}
    try:
        with open(TEMBSAVE_FILE, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading tembsave.json: {e}")
        return {}

def save_tembsave(data):
    """Saves state to tembsave.json."""
    try:
        with open(TEMBSAVE_FILE, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Error saving tembsave.json: {e}")

def get_available_account(user_id):
    """
    Finds an unused account from levelup.json.
    Returns (uid, password) or (None, None).
    """
    levelup_accs = load_levelup_accounts()
    temb_data = load_tembsave()
    
    # 1. Collect all UIDs currently in use
    used_uids = []
    for t_id, data in temb_data.items():
        if 'uid' in data:
            used_uids.append(data['uid'])
            
    # 2. Find pool of unused UIDs
    available_uids = [u for u in levelup_accs if u not in used_uids]
    
    if not available_uids:
        return None, None
        
    # 3. Pick random
    chosen_uid = random.choice(available_uids)
    return chosen_uid, levelup_accs[chosen_uid]



def convert_ban_period_to_status(period_value):
    """Converts the ban check period value to a formatted status string."""
    try:
        period = int(period_value)
    except:
        return "UNKNOWN"
    return "NOT BANNED ✅" if period == 0 else "BANNED ❌"

def convert_time(ts):
    """Converts a Unix timestamp to formatted date and time strings."""
    try:
        ts = int(ts)
        # Convert timestamp to a readable format
        dt = datetime.utcfromtimestamp(ts)
        # Custom format to match the original style
        return dt.strftime("%d %B %Y").upper(), dt.strftime("%H:%M:%S")
    except:
        return "N/A", "N/A"

def create_promo_markup(add_me_button=False):
    """Creates the inline keyboard with promotional and optional 'Add Me' links."""
    markup = types.InlineKeyboardMarkup()
    # First row: Join Groups
    markup.row(
        types.InlineKeyboardButton("JOIN GROUP", url=f"https://t.me/theroshancodex07chatgroup1"),
        types.InlineKeyboardButton("JOIN GROUP", url=f"https://t.me/theroshancodex07chatgroup1")
    )
    # Second row: Join Channel
    markup.row(types.InlineKeyboardButton("JOIN CHANNEL", url=f"https://t.me/THEROSHANCODEX"))
    
    # Optional 'Add Me' button (from BAN_CHECK_BY_YASH.py)
    if add_me_button:
        username = YOUR_BOT_USERNAME.replace("@", "")
        markup.row(
            types.InlineKeyboardButton(
                text="➕ ADD ME TO YOUR GROUP",
                url=f"http://t.me/{username}?startgroup=start"
            )
        )
        
    return markup


# ------------------------------------------------- TELEGRAM BOT HANDLERS ------------------------------------------------------

# 🧩 START & HELP COMMAND
# Legacy start_handler removed (Logic moved to new start_command)

# Helper to broadcast to dictionary values
def broadcast_to_all(command_tuple):
    if bot_queues:
        for q in bot_queues.values():
            q.put(command_tuple)

@bot.message_handler(commands=['join'])
def join_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
         bot.reply_to(message, "🔒 Bot has been locked by admin.")
         return
    # Syntax: /join all <teamcode> OR /join <teamcode> (random)
    args = message.text.split()
    sender_uid = message.from_user.id
    
    if len(args) == 3 and args[1].lower() == 'all':
        # JOIN ALL
        team_code = args[2]
        broadcast_to_all(('join', team_code, sender_uid))
        bot.reply_to(message, f"🚀 **All Bots Joining** team `{team_code}`", parse_mode="Markdown")
            

    elif len(args) == 2:
        team_code = args[1]
        
        # SESSION MANAGEMENT
        # 1. Check if user already has 2 bots
        if not check_user_limit(sender_uid):
             bot.reply_to(message, "⚠️ You have reached the maximum limit of 2 bots! Use /solo <uid> to free one.", parse_mode="Markdown")
             return

        # 2. Pick a bot
        valid_main_uids = [u for u in MAIN_ACCOUNT_UIDS if u in bot_queues]
        
        if valid_main_uids:
            # Check availability (naive approach: just random)
            # Better: Check which bots are NOT in tembsave (free)
            # If all taken, try to steal
            
            data = load_tembsave()
            assigned_bots = set()
            for inf in data.values():
                for b in inf.get("bots", []):
                    assigned_bots.add(b['uid'])

            free_uids = [u for u in valid_main_uids if u not in assigned_bots]
            
            chosen_uid = None
            
            if free_uids:
                chosen_uid = random.choice(free_uids)
            else:
                # Steal Logic
                stolen_from, stolen_bot = find_reclaimable_bot()
                if stolen_bot:
                    chosen_uid = stolen_bot
                    # Force stop previous usage
                    if stolen_bot in bot_queues:
                        bot_queues[stolen_bot].put(('solo',))
                    free_bot_from_user(stolen_from, stolen_bot)
                    bot.reply_to(message, f"♻️ Reclaiming bot {stolen_bot} for you...")
                else:
                    bot.reply_to(message, "⚠️ All bots are busy (Max capacity reached)!", parse_mode="Markdown")
                    return

            # Assign and Start
            assign_bot_to_user(sender_uid, chosen_uid, team_code)
            chosen_queue = bot_queues[chosen_uid]
            
            # Pass sender_uid for Dual Rings check
            chosen_queue.put(('join', team_code, sender_uid))
            bot.reply_to(message, f"🎲 **Main Bot ({chosen_uid}) Joining** team `{team_code}`", parse_mode="Markdown")
        else:
            bot.reply_to(message, "⚠️ No active Main Accounts (accounts.json) found!", parse_mode="Markdown")

    else:
        bot.reply_to(message, "⚠️ Usage: `/join all <teamcode>` OR `/join <teamcode>`", parse_mode="Markdown")


# ----------------------------------------------------------------------------------------------------------------------
# 🎮 GAME COMMAND HANDLERS (SEND TO WORKER QUEUE)
# ----------------------------------------------------------------------------------------------------------------------

@bot.message_handler(commands=['auto'])
def auto_command(message):
    log_cmd(message)
    user_id = str(message.from_user.id)
    args = message.text.split()
    
    if len(args) < 2:
        bot.reply_to(message, "⚠️ Usage: `/auto <teamcode>`", parse_mode="Markdown")
        return
        
    team_code = args[1]
    
    # 1. Load Current Allocations
    temb_data = load_tembsave()
    user_allocations = temb_data.get(user_id, [])
    
    # MIGRATION FIX: If existing data is a dict (legacy), wrap it in list
    if isinstance(user_allocations, dict):
        user_allocations = [user_allocations]
        temb_data[user_id] = user_allocations
        # save_tembsave(temb_data) # Safe to save later or now
    
    # 2. Check for Duplicate Team Code for SAME User
    for alloc in user_allocations:
        if alloc.get('team_code') == team_code:
            bot.reply_to(message, f"⚠️ You are already running an auto-bot for team `{team_code}` (UID: `{alloc.get('uid')}`).", parse_mode="Markdown")
            return

    # 3. Identify Available Bots
    # Pool = All UIDs in levelup.json
    # Busy = All UIDs currently in tembsave.json
    
    levelup_accs = load_levelup_accounts()
    all_busy_uids = []
    
    # Pre-scan and Migrate Data
    for u_id, allocs in list(temb_data.items()): # Use list to allow modification
        if isinstance(allocs, dict): # Lazy Migration
            allocs = [allocs]
            temb_data[u_id] = allocs
            
        for a in allocs:
            if 'uid' in a:
                all_busy_uids.append(a['uid'])
                
    free_uids = [u for u in levelup_accs if u not in all_busy_uids]
    
    chosen_uid = None
    
    if free_uids:
        # Scenario A: Free Bot Available
        chosen_uid = random.choice(free_uids)
        
    else:
        # Scenario B: No Free Bots -> Steal from Heavy User
        # Find user with MOST > 3 bots
        heavy_users = [] 
        for u_id, allocs in temb_data.items():
            if u_id == user_id: continue # Skip self
            
            if len(allocs) > 3:
                heavy_users.append((u_id, allocs))
        
        if not heavy_users:
            bot.reply_to(message, "⚠️ All level bot are running now pls wite some time", parse_mode="Markdown")
            return
            
        # Sort by count descending
        heavy_users.sort(key=lambda x: len(x[1]), reverse=True)
        victim_id, victim_allocs = heavy_users[0]
        
        # Sort victim's allocs by start_time (Oldest first)
        victim_allocs.sort(key=lambda x: x.get('start_time', 0))
        stolen_alloc = victim_allocs[0]
        stolen_uid = stolen_alloc['uid']
        
        # STOP the stolen bot
        if stolen_uid in bot_queues:
            bot_queues[stolen_uid].put(('sauto', None))
            
        # Update Victim Data
        victim_allocs.pop(0)
        temb_data[victim_id] = victim_allocs
        save_tembsave(temb_data)
        
        # Notify Victim (Optional/Polite)
        try:
            bot.send_message(victim_id, f"⚠️ **Fair Usage Policy**: Bot `{stolen_uid}` was reclaimed for another user because you have >3 active bots.", parse_mode="Markdown")
        except: pass
        
        chosen_uid = stolen_uid
        # Wait a moment for it to stop? It stops current task but process remains alive in our new "startup" architecture
        time.sleep(1)

    # 4. Assign Bot to New User
    if chosen_uid:
        # In new architecture, mapped queues are in bot_queues[uid]
        if chosen_uid in bot_queues:
            q = bot_queues[chosen_uid]
            q.put(('auto', team_code))
            
            # Save Allocation
            new_alloc = {
                "uid": chosen_uid,
                "team_code": team_code,
                "start_time": time.time()
            }
            if user_id not in temb_data:
                temb_data[user_id] = []
            temb_data[user_id].append(new_alloc)
            save_tembsave(temb_data)
            
            bot.reply_to(message, f"✅ **Auto Started!**\n🤖 Bot UID: `{chosen_uid}`\n🛡️ Team: `{team_code}`\n📊 You have {len(temb_data[user_id])} active bots.\n\nUse `/sauto` to stop.", parse_mode="Markdown")
        else:
             bot.reply_to(message, f"❌ Error: Bot `{chosen_uid}` is tracked but not connected! Restart main script?", parse_mode="Markdown")

@bot.message_handler(commands=['sauto'])
def sauto_command(message):
    log_cmd(message)
    user_id = str(message.from_user.id)
    
    temb_data = load_tembsave()
    if user_id not in temb_data or not temb_data[user_id]:
        bot.reply_to(message, "⚠️ You don't have any active auto bots.", parse_mode="Markdown")
        return
        
    user_allocs = temb_data[user_id]
    
    # MIGRATION FIX
    if isinstance(user_allocs, dict):
        user_allocs = [user_allocs]
    
    # Check if specific team code provided? User said "Stop Process" generally.
    # Let's stop ALL for now or last one? 
    # User Request: "alocate that account to that new user who use /auto" (Stealing part)
    # User Request for sauto: "stop prosses clear that player data"
    
    count = len(user_allocs)
    for alloc in user_allocs:
        uid = alloc['uid']
        if uid in bot_queues:
            bot_queues[uid].put(('sauto', None))
            
    del temb_data[user_id]
    save_tembsave(temb_data)
    
    bot.reply_to(message, f"🛑 **Stopped {count} active bots**.", parse_mode="Markdown")





@bot.message_handler(commands=['restart'])
def restart_command(message):
    log_cmd(message)
    broadcast_to_all(('restart', None))
    bot.reply_to(message, "🔄 **Restarting** all bots...", parse_mode="Markdown")




@bot.message_handler(commands=['inv'])
def inv_command(message):
    log_cmd(message)
    args = message.text.split()
    if len(args) < 2:
         bot.reply_to(message, "⚠️ Usage: `/inv <uid>`", parse_mode="Markdown")
         return
    if bot_queues:
        for q in bot_queues.values():
            q.put(('inv', args[1]))

        bot.reply_to(message, f"📩 **Invite** sent to `{args[1]}`", parse_mode="Markdown")

@bot.message_handler(commands=['gj'])
def gj_command(message):
    log_cmd(message)
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!", parse_mode="Markdown")
        return

    args = message.text.split()
    if len(args) < 2:
        bot.reply_to(message, "⚠️ Usage: `/gj <guild_id>`", parse_mode="Markdown")
        return
    if bot_queues:
        for q in bot_queues.values():
            q.put(('gj', args[1]))

    bot.reply_to(message, f"🛡️ Joining Guild `{args[1]}`...", parse_mode="Markdown")

@bot.message_handler(commands=['gl'])
def gl_command(message):
    log_cmd(message)
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!", parse_mode="Markdown")
        return

    args = message.text.split()
    target_gid = 'current'
    if len(args) > 1:
        target_gid = args[1]
    
    if bot_queues:
        for q in bot_queues.values():
             q.put(('gl', target_gid))

    
    if target_gid == 'current':
        bot.reply_to(message, f"🛡️ Leaving Current Guild...")
    else:
        bot.reply_to(message, f"🛡️ Leaving Guild `{target_gid}`...")

@bot.message_handler(commands=['add'])
@bot.message_handler(commands=['add'])
def add_command(message):
    log_cmd(message)
    # Owner Only Check
    if str(message.from_user.id) not in OWNER_UIDS:
        bot.reply_to(message, "⛔ **Access Denied**: Owner only command!", parse_mode="Markdown")
        return

    parts = message.text.split()
    if len(parts) < 2:
        bot.reply_to(message, "⚠️ Usage: `/add <uid>`", parse_mode="Markdown")
        return
    
    target_uid = parts[1]
    if add_admin(target_uid):
        bot.reply_to(message, f"✅ User `{target_uid}` added to Admins!", parse_mode="Markdown")
    else:
        bot.reply_to(message, f"⚠️ User `{target_uid}` is already an Admin.", parse_mode="Markdown")

@bot.message_handler(commands=['remove'])
def remove_command(message):
    log_cmd(message)
    # Owner Only Check
    if str(message.from_user.id) not in OWNER_UIDS:
        bot.reply_to(message, "⛔ **Access Denied**: Owner only command!", parse_mode="Markdown")
        return

    parts = message.text.split()
    if len(parts) < 2:
        bot.reply_to(message, "⚠️ Usage: `/remove <uid>`", parse_mode="Markdown")
        return
    
    target_uid = parts[1]
    if remove_admin(target_uid):
        bot.reply_to(message, f"✅ User `{target_uid}` removed from Admins!", parse_mode="Markdown")
    else:
        bot.reply_to(message, f"⚠️ User `{target_uid}` is not an Admin.", parse_mode="Markdown")

@bot.message_handler(commands=['restart'])
def restart_command(message):
    log_cmd(message)
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!", parse_mode="Markdown")
        return
    bot.reply_to(message, "🔄 Restarting all bots (internal)...", parse_mode="Markdown")
    try:
        # Create flag for main loop
        with open("restart_flag", "w") as f:
            f.write("1")
        # Stop current workers so main loop can cycle
        if bot_queues:
            for q in bot_queues.values():
                q.put(('stop',))
    except Exception as e:
        bot.reply_to(message, f"❌ Restart failed: {e}")

@bot.message_handler(commands=['stop'])
def stop_command(message):
    log_cmd(message)
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!", parse_mode="Markdown")
        return
    bot.reply_to(message, "🛑 Stopping TCP Bot...", parse_mode="Markdown")
    if bot_queues:
        for q in bot_queues.values(): q.put(('stop',))


@bot.message_handler(commands=['mute'])
def mute_command(message):
    log_cmd(message)
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!", parse_mode="Markdown")
        return

    parts = message.text.split()
    if len(parts) < 2:
        bot.reply_to(message, "⚠️ Usage: `/mute <duration>` (e.g. 30s, 5m, 1h)", parse_mode="Markdown")
        return
    
    time_str = parts[1]
    try:
        duration = 0
        if time_str.endswith('s'):
            duration = int(time_str[:-1])
        elif time_str.endswith('m'):
            duration = int(time_str[:-1]) * 60
        elif time_str.endswith('h'):
            duration = int(time_str[:-1]) * 3600
        else:
             duration = int(time_str) * 60 # Default to minutes
        
        if bot_queues:
            for q in bot_queues.values(): q.put(('mute', duration))

        
        bot.reply_to(message, f"🔇 Bot muted for `{time_str}`.", parse_mode="Markdown")
    except ValueError:
        bot.reply_to(message, "❌ Invalid format! Use 30s, 5m, 1h.", parse_mode="Markdown")

@bot.message_handler(commands=['unmute'])
def unmute_command(message):
    log_cmd(message)
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!", parse_mode="Markdown")
        return
    
    
    if bot_queues:
        for q in bot_queues.values(): q.put(('unmute',))

    bot.reply_to(message, "🔊 Bot unmuted.", parse_mode="Markdown")

@bot.message_handler(commands=['start', 'help'])
def start_command(message):
    log_cmd(message)
    user_id = message.from_user.id
    if is_bot_locked_for_user(user_id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    
    # Check args for Force Start
    args = message.text.split()
    if len(args) > 1 and args[0].lower() == '/start':
        team_code = args[1]
        try:
             # Logic from old start_handler: pick random bot
             if bot_queues:
                q = random.choice(list(bot_queues.values()))
                q.put(('start', team_code))
                bot.reply_to(message, f"🚀 **Force Start** triggered for team `{team_code}` (Random Bot)", parse_mode="Markdown")
             else:
                bot.reply_to(message, "⚠️ No bots connected.")
        except Exception as e:
            bot.reply_to(message, f"❌ Error: {e}")
        return

    user_name = message.from_user.first_name
    user_username = message.from_user.username
    
    # Status Check
    user_status = "🪪 User"
    if str(user_id) in OWNER_UIDS: user_status = "👑 Owner"
    elif is_admin(user_id): user_status = "🛡️ Admin"
    
    # Welcome Text (Matches XHOST style)
    welcome_text = (f"〽️ Welcome, {user_name}!\n\n"
                    f"🆔 Your User ID: `{user_id}`\n"
                    f"✳️ Username: `@{user_username or 'Not set'}`\n"
                    f"🔰 Your Status: {user_status}\n\n"
                    f"👇 Use buttons or type commands.")

    # Select Layout
    layout = COMMAND_BUTTONS_LAYOUT_USER_SPEC
    if str(user_id) in OWNER_UIDS or is_admin(user_id):
         layout = ADMIN_COMMAND_BUTTONS_LAYOUT_USER_SPEC
    
    # Create Markup
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    for row in layout:
         markup.add(*[types.KeyboardButton(text) for text in row])
         
    bot.reply_to(message, welcome_text, reply_markup=markup, parse_mode='Markdown')

@bot.message_handler(commands=['play'])
def play_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    args = message.text.split()
    if len(args) < 2:
         bot.reply_to(message, "Usage: `/play <TeamCode>`", parse_mode="Markdown")
         return
    
    # Load LevelUp UIDs
    try:
        with open(LEVELUP_FILE, "r") as f: 
            lvl_data = json.load(f)
            levelup_uids = list(lvl_data.keys())
    except: levelup_uids = []
    
    # Get Busy Bots
    busy_bots = set()
    try:
        data = load_tembsave()
        for bots in data.values():
            if isinstance(bots, list): busy_bots.update(bots)
    except: pass
    
    # Find Available LevelUp Bots
    candidates = [
        uid for uid in levelup_uids 
        if uid in bot_queues and uid not in busy_bots
    ]
    
    if not candidates:
        bot.reply_to(message, "⚠️ No available (idle) LevelUp bots found.")
        return

    target_uid = random.choice(candidates)
    if target_uid in bot_queues:
         bot_queues[target_uid].put(('start', args[1]))
         bot.reply_to(message, f"🎮 Force Starting Team `{args[1]}` using bot `{target_uid}`...")

@bot.message_handler(commands=['menu', 'commands'])
def game_menu_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    # Menu Content (Cleaned for Telegram)
    
    menu1 = '''╔══════════╗
🔥 *GROUP COMMANDS 1*
────────────
/3 [uid]  -> 3-Player Group
/5 [uid]  -> 5-Player Group
/6 [uid]  -> 6-Player Group
⚡ *Join Team via Code:*
/join [TeamCode]
⚡ *Leave Squad & Go Solo:*
/solo
╚══════════╝'''
    bot.reply_to(message, menu1, parse_mode="Markdown")

    menu111 = '''╔══════════╗
🔥 *GROUP COMMANDS 2*
────────────
⚡ *Invite Player to Team:*
/inv [UID]
⚡ *Check Player Status:*
/status [uid]
╚══════════╝'''
    bot.send_message(message.chat.id, menu111, parse_mode="Markdown")

    menu7 = '''╔══════════╗
🔥 *LEVEL UP & START*
────────────
⚡ *Force start team:*
/play [TeamCode]
⚠︎ Level up bot info 
╰┈➤Select lone wolf headshot 
ㅤㅤduel 1 vs 1 mode ✌︎︎
⚡ *Level up auto force start 24/7:*
/auto [TeamCode]
⚡ *Stop level up:*
/sauto
╚══════════╝'''
    bot.send_message(message.chat.id, menu7, parse_mode="Markdown")

#     menu44 = '''╔══════════╗
# 🔥 *EMOTE COMMANDS 3*
# ────────
# 🔥 *USE EMOTE WITHOUT BOT IN GROUP*
# ────────────
# ⚡ *Play Emote with team code and leave bot*
# /jel [team] [uids] [emote]
# ⚡ *Play emote without emote id*
# /jp [team] [uids] [1-408]
# ⚡ *Play Max Evo Emote*
# /jevo [team] [uids] [1-21]
# ⚡ *Each UID Get Random Max Emote*
# /jrevo [team] [uids]
# ╚══════════╝'''
#     bot.send_message(message.chat.id, menu44, parse_mode="Markdown")

    menu5 = '''╔══════════╗
🔥 *ATTACK / LAG COMMANDS*
────────────
⚡ *Spam Join Request*
/sm [uid]
⚡ *Join Req Craftland Badge*
/s1 [uid]
⚡ *Join Req New V-Badge*
/s2 [uid]
⚡ *Join Req Moderator Badge*
/s3 [uid]
⚡ *Join Req Small V-Badge*
/s4 [uid]
⚡ *Join Req Pro Badge*
/s5 [uid]
⚡ *Stop Spam Request*
/ssm
⚡ *Spam Invite*
/spm [UID]
⚡ *Stop Spam Invite*
/sspm
⚡ *Spam Join Request Room*
/room [uid]
⚡ *Stop Spam Join Request Room*
/sroom
⚡ *Lag Any Team*
/lag [teamcode]
⚡ *Stop lag*
/slag
╚══════════╝'''
    bot.send_message(message.chat.id, menu5, parse_mode="Markdown")

    menu6 = '''╔══════════╗
🔥 *GENERAL COMMANDS*
────────────
/owner -> Know Bot's Owner 
/admin -> Show Admin Menu
/menu -> Show Full Menu
/group -> Show Group Menu
/attack -> Show Attack Menu
/levelup -> Show Level Up Menu
╚══════════╝'''
    bot.send_message(message.chat.id, menu6, parse_mode="Markdown")


@bot.message_handler(commands=['owner'])
def owner_commands(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
        
    # Social Media Buttons
    markup = types.InlineKeyboardMarkup(row_width=1)
    btn_ig = types.InlineKeyboardButton("📸 Instagram", url="https://instagram.com/ig._tom_")
    btn_tg = types.InlineKeyboardButton("✈️ Telegram", url="https://t.me/Muzammil_cp")
    btn_yt = types.InlineKeyboardButton("▶️ YouTube", url="https://youtube.com/@trivoxgaming?si=60pVfzNNTpwpdxEz")
    markup.add(btn_ig, btn_tg, btn_yt)
    
    bot.reply_to(message, "📞 **Contact Owner**\nClick below to connect:", reply_markup=markup, parse_mode='Markdown')

@bot.message_handler(commands=['admin'])
def admin_menu_command(message):
    log_cmd(message)
    # Owner Commands (Shown in Admin Menu context)
    owner_message = r'''╔══════════╗
🔥 *OWNER COMMANDS*
────────
⚡ *Add Admin*
/add [uid]
⚡ *Remove Admin*
/remove [uid]
⚡ *Show All Admin UID*
/admin\_list
╚══════════╝'''
    bot.send_message(message.chat.id, owner_message, parse_mode="Markdown")
    
    admin_message = r"""╔══════════╗
🔥 *ADMIN COMMANDS*
────────────
⚡ *BoT Guild Join* 
/gj [Guild ID]
⚡ *BoT Guild Leave*
/gl
⚡ *Ban Player*
/ban [uid]
⚡ *Unban Player*
/unban [uid]
⚡ *Unban All Player*
/unban\_all
⚡ *Show All Banned Player*
/ban\_list
⚡ *Mute All Player*
/mute [30s/1m/5m/1h]
⚡ *Unmute All Player*
/unmute
⚡ *Restart Bot*
/restart
⚡ *Stop Bot*
/stop
╚══════════╝"""
    bot.send_message(message.chat.id, admin_message, parse_mode="Markdown")

@bot.message_handler(commands=['group'])
def group_menu_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    menu11 = '''╔══════════╗
🔥 *GROUP COMMANDS 1*
────────────
/3 [uid]  -> 3-Player Group
/5 [uid]  -> 5-Player Group
/6 [uid]  -> 6-Player Group
⚡ *Join Team via Code:*
/join [TeamCode]
⚡ *Leave Squad & Go Solo*
/solo
╚══════════╝'''
    bot.send_message(message.chat.id, menu11, parse_mode="Markdown")

    menu1111 = '''╔══════════╗
🔥 *GROUP COMMANDS 2*
────────────
⚡ *Invite Player to Team:*
/inv [UID]
⚡ *BoT Look Change*
/b1 - /b11
⚡ *Check Player Status*
/status [uid]

╚══════════╝'''
    bot.send_message(message.chat.id, menu1111, parse_mode="Markdown")

@bot.message_handler(commands=['levelup'])
def levelup_menu_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    menu7 = '''╔══════════╗
🔥 *LEVEL UP & START*
────────────
⚡ *Force start team:*
/play [TeamCode]
⚠︎ Level up bot info 
╰┈➤Select lone wolf headshot 
ㅤㅤduel 1 vs 1 mode ✌︎︎
⚡ *Level up auto force start 24/7:*
/auto [TeamCode]
⚡ *Stop level up:*
/sauto
╚══════════╝'''
    bot.send_message(message.chat.id, menu7, parse_mode="Markdown")

@bot.message_handler(commands=['emote'])
def emote_menu_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    menu44 = '''╔══════════╗
🔥 *EMOTE COMMANDS 3*
────────
🔥 *USE EMOTE WITHOUT BOT IN GROUP*
────────────
⚡ *Play Emote with team code and leave bot*
/jel [team code] [uids] [emote id]
⚡ *Play emote without emote id*
/jp [team code] [uids] [1-408]
⚡ *Play Max Evo Emote*
/jevo [team code] [uids] [1-21]
⚡ *Each UID Get Random Max Emote*
/jrevo [team code] [uids]
╚══════════╝'''
    bot.send_message(message.chat.id, menu44, parse_mode="Markdown")

@bot.message_handler(commands=['attack'])
def attack_menu_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    menu55 = '''╔══════════╗
🔥 *ATTACK / LAG COMMANDS*
────────────
⚡ *Spam Join Request*
/sm [uid]
⚡ *Join Req Craftland Badge*
/s1 [uid]
⚡ *Join Req New V-Badge*
/s2 [uid]
⚡ *Join Req Moderator Badge*
/s3 [uid]
⚡ *Join Req Small V-Badge*
/s4 [uid]
⚡ *Join Req Pro Badge*
/s5 [uid]
⚡ *Stop Spam Request* 
/ssm
⚡ *Spam Invite*
/spm [UID]
⚡ *Stop Spam Invite* 
/sspm
⚡ *Spam Join Request Room*
/room [uid]
⚡ *Stop Spam Join Request Room*
/sroom
⚡ *Lag Any Team*
/lag [teamcode]
⚡ *Stop lag*
/slag
╚══════════╝'''
    bot.send_message(message.chat.id, menu55, parse_mode="Markdown")




@bot.message_handler(regexp=r'^/b\d+$')
def bundle_shortcut_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    # Shortcuts /b1 to /b11
    cmd = message.text.split()[0][1:] # remove /
    if bot_queues:
        for q in bot_queues.values(): q.put(('bundle_short', cmd))

@bot.message_handler(commands=[f'b{i}' for i in range(1, 12)])
def bot_look_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    cmd = message.text.split()[0][1:] # b1, b2...
    if bot_queues:
        for q in bot_queues.values(): q.put(('look', cmd))
    bot.reply_to(message, f"👕 Bot Look changed to `{cmd}`!")


    bot.reply_to(message, "🤬 Sending 'noob' to Team Chat!")

@bot.message_handler(commands=['dance'])
def dance_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    # Usage: /dance <uids> (or empty for self/all)
    # Since we broadcast to all bots, we just trigger the function.
    # Logic in listener/TcPChaT handles targets.
    args = message.text.split()
    targets = args[1:] if len(args) > 1 else None
    if bot_queues:
        for q in bot_queues.values(): q.put(('dance', targets))
    bot.reply_to(message, "💃 Dance initiated!")

@bot.message_handler(commands=['rnd'])
def rnd_command(message):
    log_cmd(message)
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    targets = message.text.split()[1:]
    if bot_queues:
        for q in bot_queues.values(): q.put(('rnd', targets))
    bot.reply_to(message, "🕺 Random dance party started!")

@bot.message_handler(commands=['srnd'])
def srnd_command(message):
    if bot_queues:
        for q in bot_queues.values(): q.put(('srnd', None))
    bot.reply_to(message, "🛑 Dance party stopped.")

@bot.message_handler(commands=['max'])
def max_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    args = message.text.split()
    targets = args[1:] if len(args) > 1 else None
    if bot_queues:
        for q in bot_queues.values(): q.put(('max', targets))
    bot.reply_to(message, "🔥 Max Evo initiated!")

@bot.message_handler(commands=['smax'])
def smax_command(message):
    if bot_queues:
        for q in bot_queues.values(): q.put(('smax', None))
    bot.reply_to(message, "🛑 Max Evo stopped.")

@bot.message_handler(commands=['ban', 'ban_list'])
def ban_user_command(message):
    log_cmd(message)
    # Lock Check (Even though it says admin only, lock might override or be same)
    # Admin is exempt in is_bot_locked_for_user, so this is safe.
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!")
        return

    args = message.text.split()
    cmd_name = args[0].lower().replace('/', '')
    
    # Check if list requested via alias or argument
    is_list_request = (cmd_name == 'ban_list') or (len(args) > 1 and args[1].lower() == 'list')
    
    if is_list_request:
        try:
            # Use global BANNED_FILE if defined, else fallback
            fname = getattr(sys.modules[__name__], 'BANNED_FILE', 'banned_players.json')
            with open(fname, "r") as f: ban_list = json.load(f)
        except: ban_list = []
        
        if not ban_list:
             bot.reply_to(message, "🟢 No banned players.")
        else:
             msg = "🚫 *Banned Players:*\n" + "\n".join([f"`{u}`" for u in ban_list])
             bot.reply_to(message, msg, parse_mode="Markdown")
        return

    if len(args) < 2: 
        bot.reply_to(message, "Usage: `/ban <uid>` or `/ban list`")
        return

    target = args[1]
    
    # 💾 Save to File
    fname = getattr(sys.modules[__name__], 'BANNED_FILE', 'banned_players.json')
    try:
        with open(fname, "r") as f: ban_list = json.load(f)
    except: ban_list = []
    
    if target not in ban_list:
        ban_list.append(target)
        try:
            with open(fname, "w") as f: json.dump(ban_list, f)
        except Exception as e: print(f"Error saving ban: {e}")

    if bot_queues:
        for q in bot_queues.values(): q.put(('ban', target))
    bot.reply_to(message, f"🚫 Banning UID `{target}` from bot commands.")

@bot.message_handler(commands=['unban', 'unban_all'])
def unban_user_command(message):
    log_cmd(message)
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "⛔ **Access Denied**: Admin only command!")
        return

    args = message.text.split()
    cmd_name = args[0].lower().replace('/', '')
    
    # Handle alias
    if cmd_name == 'unban_all':
        target = 'all'
    elif len(args) > 1:
        target = args[1]
    else:
        # Invalid usage
        return
    
    # 💾 Update File
    fname = getattr(sys.modules[__name__], 'BANNED_FILE', 'banned_players.json')
    try:
        with open(fname, "r") as f: ban_list = json.load(f)
    except: ban_list = []
    
    saved = False
    if target == 'all':
        ban_list = []
        saved = True
    elif target in ban_list:
        ban_list.remove(target)
        saved = True
        
    if saved:
        try:
             with open(fname, "w") as f: json.dump(ban_list, f)
        except Exception as e: print(f"Error saving unban: {e}")

    if bot_queues:
        for q in bot_queues.values(): q.put(('unban', target))
    
    if target == 'all':
        bot.reply_to(message, "✅ Unbanning **ALL** players.")
    else:
        bot.reply_to(message, f"✅ Unbanning UID `{target}`.")

@bot.message_handler(commands=['mute'])
def mute_bot_command(message):
    args = message.text.split()
    if len(args) < 2: return
    if bot_queues:
        for q in bot_queues.values(): q.put(('mute', args[1]))
    bot.reply_to(message, f"🔇 Bot muted for `{args[1]}`.")

@bot.message_handler(commands=['unmute'])
def unmute_bot_command(message):
    if bot_queues:
        for q in bot_queues.values(): q.put(('unmute', None))
    bot.reply_to(message, "🔊 Bot unmuted.")

@bot.message_handler(commands=['bio'])
def bio_command(message):
    args = message.text.split()
    if len(args) < 2: return
    if bot_queues:
        for q in bot_queues.values(): q.put(('bio', args[1]))
    bot.reply_to(message, f"📝 Fetching bio for `{args[1]}`...")

@bot.message_handler(commands=['evo_c'])
def evo_c_command(message):
    args = message.text.split()
    if len(args) < 4:
         bot.reply_to(message, "Usage: /evo_c <uids> <num> <time>")
         return
    
    cmd_tuple = tuple(['evo_c'] + args[1:])
    if bot_queues:
        for q in bot_queues.values(): q.put(cmd_tuple)
    bot.reply_to(message, f"🔥 Custom Evo Spam started!")

@bot.message_handler(commands=['loop'])
def loop_command(message):
    args = message.text.split()
    if len(args) < 3: 
         bot.reply_to(message, "Usage: /loop <uids> <emote>")
         return
    
    cmd_tuple = tuple(['loop'] + args[1:])
    if bot_queues:
        for q in bot_queues.values(): q.put(cmd_tuple)
    bot.reply_to(message, f"🔁 Emote Loop started!")

@bot.message_handler(commands=['jevo'])
def jevo_command(message):
    args = message.text.split()
    if len(args) < 4: 
        bot.reply_to(message, "Usage: /jevo <team> <uids...> <emote>")
        return
    
    # args: ['/jevo', 'team', 'u1', 'u2', ..., 'emote']
    # We want to push: ('jevo', 'team', 'u1', 'u2', ..., 'emote')
    
    cmd_tuple = tuple(['jevo'] + args[1:])
    
    if bot_queues:
         # User requested Random 1 Account for jevo
         target_q = random.choice(list(bot_queues.values()))
         target_q.put(cmd_tuple)
    bot.reply_to(message, f"🎮 Joining {args[1]} & Emoting (Random Bot)!")

@bot.message_handler(commands=['jel'])
def jel_command(message):
    args = message.text.split()
    if len(args) < 4: 
        bot.reply_to(message, "Usage: /jel <team> <uids...> <emote>")
        return
    
    cmd_tuple = tuple(['jel'] + args[1:])
    
    if bot_queues:
         q = random.choice(list(bot_queues.values()))
         q.put(cmd_tuple)
    bot.reply_to(message, f"🎮 J-EL Started on {args[1]} (Random Bot)!")

@bot.message_handler(commands=['jp'])
def jp_command(message):
    args = message.text.split()
    if len(args) < 4: 
        bot.reply_to(message, "Usage: /jp <team> <uids...> <emote>")
        return
    
    cmd_tuple = tuple(['jp'] + args[1:])
    
    if bot_queues:
         q = random.choice(list(bot_queues.values()))
         q.put(cmd_tuple)
    bot.reply_to(message, f"🎮 J-P Started on {args[1]} (Random Bot)!")

@bot.message_handler(commands=['jrevo'])
def jrevo_command(message):
    args = message.text.split()
    if len(args) < 3: 
        bot.reply_to(message, "Usage: /jrevo <team> <uids...>")
        return
    
    cmd_tuple = tuple(['jrevo'] + args[1:])
    
    if bot_queues:
         q = random.choice(list(bot_queues.values()))
         q.put(cmd_tuple)
    bot.reply_to(message, f"🎮 J-REvo Started on {args[1]} (Random Bot)!")

@bot.message_handler(commands=['admin', 'admin_list'])
def admin_list_command(message):
     # Since this is "List Admins", likely fetching from local file, not bot process
     # But if we want bots to report, that's complex
     # Assuming reading local file
     try:
          with open(ADMIN_FILE, 'r') as f:
               admins = json.load(f)
          bot.reply_to(message, f"👮 Admins: {', '.join(admins)}")
     except:
          bot.reply_to(message, "No admins found.")


@bot.message_handler(commands=['likes'])
def likes_command(message):
    args = message.text.split()
    if len(args) < 2: return
    if bot_queues:
        for q in bot_queues.values(): q.put(('likes', args[1]))
    bot.reply_to(message, f"❤️ Sending likes to `{args[1]}`...")



# ---------------- COMMANDS FROM HELP MENU ----------------

# GROUP COMMANDS
@bot.message_handler(commands=['3', '4', '5', '6'])
def slots_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    parts = message.text.split()
    cmd_name = parts[0][1:] # '3', '4', '5', '6'
    
    uid_arg = 0
    if len(parts) > 1 and parts[1].isdigit():
         uid_arg = parts[1]
    
    # Filter for MAIN ACCOUNTS only (accounts.json)
    valid_main_uids = [u for u in MAIN_ACCOUNT_UIDS if u in bot_queues]
    
    if valid_main_uids:
        # Pushing to ONE random main bot as requested
        chosen_uid = random.choice(valid_main_uids)
        target_q = bot_queues[chosen_uid]
        
        target_q.put(('slots', cmd_name, uid_arg))
        
        if uid_arg:
             bot.reply_to(message, f"👥 **{cmd_name}-Player Glitch** started on `{uid_arg}` using **{chosen_uid}**!", parse_mode="Markdown")
        else:
             bot.reply_to(message, f"👥 **{cmd_name}-Player Glitch** started using **{chosen_uid}** (No Invite)!", parse_mode="Markdown")
    else:
        bot.reply_to(message, "⚠️ No active Main Accounts (accounts.json) found!", parse_mode="Markdown")





@bot.message_handler(commands=['status'])
def status_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    args = message.text.split()
    if len(args) < 2: return
    target = args[1]
    # Status requires API fetch or in-game check. 
    # For now, trigger listener to check if implemented or just reply.
    # The user code has check_player_status logic.
    if bot_queues:
        # Use random bot to check status (single request)
        target_q = random.choice(list(bot_queues.values()))
        target_q.put(('status', target, message.chat.id))
    bot.reply_to(message, f"🔍 Checking status for `{target}`...")







# ATTACK / LAG COMMANDS
@bot.message_handler(commands=['sm', 's1', 's2', 's3', 's4', 's5'])
def spam_req_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    args = message.text.split()
    cmd = args[0][1:] # sm, s1...
    if len(args) < 2: return
    uid = args[1]
    
    if bot_queues:
        # Assign bots, potentially kicking oldest
        picked, kicked_bots = assign_bots_to_user(message.from_user.id, 3)
        
        if not picked:
             bot.reply_to(message, "⚠️ System Overload: All bots busy & active recently. Try again later.", parse_mode="Markdown")
             return
             
        # Stop kicked bots
        if kicked_bots:
             for k_uid in kicked_bots:
                 if k_uid in bot_queues:
                     bot_queues[k_uid].put(('ssm', None)) # Generic stop for spam
             bot.reply_to(message, "⚠️ Displaced inactive user to free up bots.", parse_mode="Markdown")
        
        # Start new bots
        for p_uid in picked:
             if p_uid in bot_queues:
                bot_queues[p_uid].put(('spam_req', cmd, uid))
             
        bot.reply_to(message, f"📨 Spamming Requests ({cmd}) to `{uid}` using your assigned bots...")

@bot.message_handler(commands=['ssm'])
def stop_spam_req_command(message):
    if bot_queues:
        stopped_bots = release_user_bots(message.from_user.id)
        
        if not stopped_bots:
             bot.reply_to(message, "not running any spam for you", parse_mode="Markdown")
             return
             
        for u in stopped_bots:
             if u in bot_queues:
                  bot_queues[u].put(('ssm', None))
        
        bot.reply_to(message, "🛑 Spam Request stopped .")

@bot.message_handler(commands=['spm'])
def spm_command(message):
    log_cmd(message)
    args = message.text.split()
    if len(args) < 2: return
    uid = args[1]
    
    if bot_queues:
        picked, kicked_bots = assign_bots_to_user(message.from_user.id, 3)
        
        if not picked:
             bot.reply_to(message, "⚠️ System Overload: All bots busy & active recently. Try again later.", parse_mode="Markdown")
             return
             
        if kicked_bots:
             for k_uid in kicked_bots:
                 if k_uid in bot_queues:
                     bot_queues[k_uid].put(('sspm', None)) # Stop invite spam
             bot.reply_to(message, "⚠️ Displaced inactive user to free up bots.", parse_mode="Markdown")
        
        for p_uid in picked:
             if p_uid in bot_queues:
                bot_queues[p_uid].put(('spm', uid))
             
    bot.reply_to(message, f"📨 Spamming Invites to `{uid}` using your assigned bots...")

@bot.message_handler(commands=['sspm'])
def sspm_command(message):
    if bot_queues:
        stopped_bots = release_user_bots(message.from_user.id)
        
        if not stopped_bots:
             bot.reply_to(message, "not running any spam for you", parse_mode="Markdown")
             return

        for u in stopped_bots:
             if u in bot_queues:
                  bot_queues[u].put(('sspm', None))
                  
    bot.reply_to(message, "🛑 Spam Invites stopped.")

@bot.message_handler(commands=['solo'])
def solo_command(message):
    # Syntax: /solo or /solo <uid>
    args = message.text.split()
    sender_uid = message.from_user.id
    
    bots_to_solo = []
    
    # 1. Determine targets
    if len(args) == 2:
        target_uid = args[1]
        # Verify ownership
        owner = get_bot_owner(target_uid)
        if owner and str(owner) != str(sender_uid):
             bot.reply_to(message, f"⚠️ Bot {target_uid} is assigned to another user!", parse_mode="Markdown")
             return
        bots_to_solo.append(target_uid)
    else:
        # Solo ALL bots assigned to user
        data = load_tembsave()
        user_info = data.get(str(sender_uid), {})
        bots = user_info.get("bots", [])
        if not bots:
             bot.reply_to(message, "⚠️ You have no assigned bots to solo.", parse_mode="Markdown")
             return
        bots_to_solo = [b['uid'] for b in bots]

    # 2. Execute Solo
    count = 0
    for uid in bots_to_solo:
        if uid in bot_queues:
            bot_queues[uid].put(('solo',))
            # Clean from session immediately
            free_bot_from_user(sender_uid, uid)
            count += 1
            
    bot.reply_to(message, f"✅ Released **{count}** bots from your session.", parse_mode="Markdown")
        
@bot.message_handler(commands=['room'])
def room_command(message):
    args = message.text.split()
    if len(args) < 2: return
    uid = args[1]
    
    if bot_queues:
        picked, kicked_bots = assign_bots_to_user(message.from_user.id, 3)
        
        if not picked:
             bot.reply_to(message, "⚠️ System Overload: All bots busy & active recently. Try again later.", parse_mode="Markdown")
             return

        if kicked_bots:
             for k_uid in kicked_bots:
                 if k_uid in bot_queues:
                     bot_queues[k_uid].put(('sroom', None)) 
             bot.reply_to(message, "⚠️ Displaced inactive user to free up bots.", parse_mode="Markdown")
        
        first_bot = True
        for p_uid in picked:
             if p_uid in bot_queues:
                # Pass message.chat.id ONLY to the first bot so we get 1 reply, not 3.
                cid = message.chat.id if first_bot else None
                bot_queues[p_uid].put(('room', uid, cid))
                first_bot = False
             
    # Commented out as per user request to remove generic ack
    # bot.reply_to(message, f"🚪 Room Spam to `{uid}` using your assigned bots...")

@bot.message_handler(commands=['sroom'])
def sroom_command(message):
    if bot_queues:
        stopped_bots = release_user_bots(message.from_user.id)
        
        if not stopped_bots:
             bot.reply_to(message, "not running any spam for you", parse_mode="Markdown")
             return

        for u in stopped_bots:
             if u in bot_queues:
                  bot_queues[u].put(('sroom', None))

    bot.reply_to(message, "🛑 Room Spam stopped.")

@bot.message_handler(commands=['lag'])
def lag_command(message):
    args = message.text.split()
    if len(args) < 2: return
    team = args[1]
    if bot_queues:
        # Select 1 random account as requested
        target_q = random.choice(list(bot_queues.values()))
        target_q.put(('lag', team))
    bot.reply_to(message, f"⚠️ Lag Attack on Team `{team}` started (Random 1 Account)...")

@bot.message_handler(commands=['slag'])
def slag_command(message):
    if bot_queues:
        for q in bot_queues.values(): q.put(('slag', None))
    bot.reply_to(message, "🛑 Lag Attack stopped.")
    
# 🧭 /VISIT COMMAND (UPDATED FOR NEW API RESPONSE)
@bot.message_handler(commands=['visit'])
def visit_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    chat_id = message.chat.id
    args = message.text.split()[1:]
    final_markup = create_promo_markup()

    # Usage check
    if len(args) < 2:
        bot.reply_to(message, "⚠️ **ᴜꜱᴀɢᴇ:** `/visit <region> <uid>`", parse_mode="Markdown")
        return

    region, uid = args[0], args[1]

    processing = bot.reply_to(
        message,
        f"⏳ ᴘʀᴏᴄᴇꜱꜱɪɴɢ ᴠɪꜱɪᴛ ꜰᴏʀ `{uid}`...",
        parse_mode="Markdown"
    )

    try:
        # API CALL
        res = requests.get(f"{API_VISIT_BASE}/{region}/{uid}", timeout=10)

        if res.status_code != 200:
            bot.edit_message_text(
                f"❌ ᴀᴘɪ ꜰᴀɪʟᴇᴅ ({res.status_code})",
                chat_id,
                processing.message_id,
                reply_markup=final_markup
            )
            return

        data = res.json()

        # EXTRACT DATA FROM NEW API RESPONSE
        nickname = sanitize_markdown(data.get("nickname", "N/A"))
        fetched_uid = data.get("uid", "N/A")
        success = data.get("success", 0)
        fail = data.get("fail", 0)
        level = data.get("level", "N/A")
        likes = data.get("likes", 0)
        total = success + fail  # Calculate total visits

        # Format large numbers with commas
        formatted_likes = "{:,}".format(likes) if likes != "N/A" else "N/A"

        # Final message with new data
        msg = (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "        ᴠɪꜱɪᴛ ʀᴇꜱᴜʟᴛ\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 ɴᴀᴍᴇ: **{nickname}**\n"
            f"🆔 ᴜɪᴅ: `{fetched_uid}`\n"
            f"🎯 ʟᴇᴠᴇʟ: **{level}**\n"
            f"❤️ ʟɪᴋᴇꜱ: **{formatted_likes}**\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "        ᴠɪꜱɪᴛ ᴅᴀᴛᴀ\n"
            "━━━━━━━━━━━━━━━━━━━━\n"       
            f"✅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟ ᴠɪꜱɪᴛꜱ: **{success}**\n"
            f"❌ ꜰᴀɪʟᴇᴅ ᴠɪꜱɪᴛꜱ: **{fail}**\n"
            f"📊 ᴛᴏᴛᴀʟ ᴠɪꜱɪᴛꜱ: **{total}**\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ: **{DEVELOPER_NAME}**\n"
            f"❤️ ᴄʀᴇᴅɪᴛ: {CREDIT}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
        )

        bot.edit_message_text(
            msg,
            chat_id,
            processing.message_id,
            reply_markup=final_markup,
            parse_mode="Markdown"
        )

    except requests.exceptions.RequestException as e:
        bot.edit_message_text(
            f"❌ ɴᴇᴛᴡᴏʀᴋ/ᴛɪᴍᴇᴏᴜᴛ ᴇʀʀᴏʀ:\n`{sanitize_markdown(str(e))}`",
            chat_id,
            processing.message_id,
            reply_markup=final_markup,
            parse_mode="Markdown"
        )

    except Exception as e:
        bot.edit_message_text(
            f"❌ ᴜɴᴇxᴘᴇᴄᴛᴇᴅ ᴇʀʀᴏʀ:\n`{sanitize_markdown(str(e))}`",
            chat_id,
            processing.message_id,
            reply_markup=final_markup,
            parse_mode="Markdown"
        )
        
# 🔒 /BANCHECK COMMAND (Combined from BAN_CHECK_BY_YASH.py and Visit-Bot.py design)
@bot.message_handler(commands=['bancheck'])
def bancheck_handler(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    chat_id = message.chat.id
    final_markup = create_promo_markup(add_me_button=True)

    try:
        parts = message.text.strip().split()
        if len(parts) < 2:
            bot.reply_to(message, "⚠️ ᴜꜱᴀɢᴇ: `/bancheck <UID>`\nᴇxᴀᴍᴘʟᴇ: `/bancheck 2919267964`")
            return

        uid = parts[1].strip()
        if not is_valid_uid(uid):
            bot.reply_to(message, "❌ ɪɴᴠᴀʟɪᴅ ᴜɪᴅ (8-11 ᴅɪɢɪᴛꜱ)!")
            return

        processing = bot.reply_to(message, f"⏳ ᴄʜᴇᴄᴋɪɴɢ ʙᴀɴ ꜱᴛᴀᴛᴜꜱ ꜰᴏʀ ᴜɪᴅ: `{uid}`", parse_mode="Markdown")

        nickname, region = "ɴ/ᴀ", "ɴ/ᴀ"
        try:
            # 1. Fetch Nickname and Region
            resp = requests.get(ULTRA_API_URL.format(uid=uid), timeout=10)
            if resp.status_code == 200:
                j = resp.json()
                nickname = sanitize_markdown(j.get("nickname") or j.get("name"))
                region = sanitize_markdown(j.get("region") or j.get("server"))
        except Exception as e:
            logger.warning(f"Region API failed for {uid}: {e}")

        ban_status_text = "ᴇʀʀᴏʀ"
        try:
            # 2. Fetch Ban Status
            ban_resp = requests.get(BANCHECK_API_URL.format(uid=uid), headers=BANCHECK_HEADERS, timeout=10)
            if ban_resp.status_code == 200:
                data = ban_resp.json().get("data", {})
                period = data.get("period", None)
                ban_status_text = convert_ban_period_to_status(period)
            else:
                ban_status_text = f"ᴀᴘɪ ᴇʀʀᴏʀ ({ban_resp.status_code})"
        except Exception as e:
            logger.error(f"Ban Check API failed for {uid}: {e}")
            ban_status_text = "ʀᴇǫᴜᴇꜱᴛ ꜰᴀɪʟᴇᴅ"

        # 3. Format Final Message
        msg = (
            "━━━━━━━━━━━━━━━━━━━━\n"
            "        ʙᴀɴ ᴄʜᴇᴄᴋ ʀᴇꜱᴜʟᴛ\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 ɴᴀᴍᴇ: **{nickname}**\n"
            f"🆔 ᴜɪᴅ: `{uid}`\n"
            f"🌍 ʀᴇɢɪᴏɴ: **{region}**\n"
            f"🛡️ ꜱᴛᴀᴛᴜꜱ: **{ban_status_text}**\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ: **{DEVELOPER_NAME}**\n"
            f"❤️ ᴄʀᴇᴅɪᴛ: {CREDIT}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
        )

        bot.edit_message_text(msg, chat_id=processing.chat.id, message_id=processing.message_id,
                              reply_markup=final_markup)

    except Exception as e:
        logger.error(f"General error in bancheck: {e}")
        bot.reply_to(message, f"❌ ᴜɴᴇxᴘᴇᴄᴛᴇᴅ ᴇʀʀᴏʀ: `{sanitize_markdown(str(e))}`", reply_markup=final_markup)

# ❤️ /CKLIKE COMMAND (New command to check 'liked' count)
@bot.message_handler(commands=['cklike'])
def cklike_command(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    chat_id = message.chat.id
    final_markup = create_promo_markup()

    try:
        args = message.text.split()[1:]

        if len(args) != 2:
            bot.reply_to(
                message,
                "⚠️ ᴜꜱᴀɢᴇ: `/cklike <REGION> <UID>`\nᴇxᴀᴍᴘʟᴇ: `/cklike ind 2314978683`"
            )
            return

        region, uid = args[0], args[1]
        
        processing = bot.reply_to(
            message,
            f"⏳ ꜰᴇᴛᴄʜɪɴɢ ʟɪᴋᴇ ᴄᴏᴜɴᴛ ꜰᴏʀ `{uid}` ɪɴ `{region}`...",
            parse_mode="Markdown"
        )
        
        # API FETCH using the already defined API_INFO_URL
        res = requests.get(API_INFO_URL.format(uid=uid, region=region), timeout=10)
        
        if res.status_code != 200:
            bot.edit_message_text(
                f"❌ ᴀᴘɪ ꜰᴀɪʟᴇᴅ ({res.status_code})", 
                chat_id, 
                processing.message_id, 
                reply_markup=final_markup
            )
            return
            
        data = res.json()
        
        # Check if basicInfo is missing (API error or invalid ID/region)
        if "basicInfo" not in data:
            error_msg = data.get("error", "ɪɴᴠᴀʟɪᴅ ᴜɪᴅ ᴏʀ ʀᴇɢɪᴏɴ")
            bot.edit_message_text(
                f"❌ ᴇʀʀᴏʀ: `{sanitize_markdown(error_msg)}`", 
                chat_id, 
                processing.message_id,
                reply_markup=final_markup
            )
            return

        basic_info = data["basicInfo"]
        s = sanitize_markdown # Alias for convenience

        nickname = s(basic_info.get("nickname"))
        region_ = s(basic_info.get("region"))
        level = s(basic_info.get("level"))
        liked = s(basic_info.get("liked"))

        # FINAL RESULT
        final = f"""
━━━━━━━━━━━━━━━━━━━━
        ʟɪᴋᴇ ᴄᴏᴜɴᴛ ʀᴇꜱᴜʟᴛ
━━━━━━━━━━━━━━━━━━━━

👤 ɴɪᴄᴋɴᴀᴍᴇ: **{nickname}**
🌍 ʀᴇɢɪᴏɴ: **{region_}**
🔰 ʟᴇᴠᴇʟ: **{level}**
❤️ ʟɪᴋᴇꜱ: **{liked}**

━━━━━━━━━━━━━━━━━━━━
👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ: **{DEVELOPER_NAME}**
❤️ ᴄʀᴇᴅɪᴛ: {CREDIT}
━━━━━━━━━━━━━━━━━━━━
"""

        bot.edit_message_text(
            final, 
            chat_id, 
            processing.message_id,
            reply_markup=final_markup,
            parse_mode="Markdown"
        )

    except requests.exceptions.RequestException as e:
        bot.edit_message_text(
            f"❌ ɴᴇᴛᴡᴏʀᴋ/ᴛɪᴍᴇᴏᴜᴛ ᴇʀʀᴏʀ: `{sanitize_markdown(str(e))}`", 
            chat_id, 
            processing.message_id, 
            reply_markup=final_markup
        )
    except Exception as e:
        logger.error(f"General error in cklike_command: {e}")
        bot.edit_message_text(f"❌ ᴜɴᴇxᴘᴇᴄᴛᴇᴅ ᴇʀʀᴏʀ: `{sanitize_markdown(str(e))}`", chat_id, processing.message_id, reply_markup=final_markup)

# ----------------------------------------------------------------------------
# GET COMMANDS
# 1) get <REGION> <UID>  -> searches the given region
# 2) get <UID>          -> auto-locked to IND
# ----------------------------------------------------------------------------

# Handler for: get <REGION> <UID>
@bot.message_handler(regexp=r'^[gG][eE][tT]\s+([a-zA-Z]{2,4})\s+(\d+)$')
def get_info_with_region(message):
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return
    chat_id = message.chat.id
    final_markup = create_promo_markup()
    
    try:
        match = re.search(r'^[gG][eE][tT]\s+([a-zA-Z]{2,4})\s+(\d+)$', message.text.strip())
        if not match:
            bot.reply_to(message, "⚠️ ᴜꜱᴀɢᴇ: `get <REGION> <UID>`\nᴇxᴀᴍᴘʟᴇ: `get ind 2314978683`")
            return

        region = match.group(1).upper()
        uid = match.group(2)

        processing = bot.reply_to(message, f"🔍 ꜱᴇᴀʀᴄʜɪɴɢ `{uid}` ɪɴ `{region}`...", parse_mode="Markdown")

        res = requests.get(API_INFO_URL.format(uid=uid, region=region), timeout=15)
        if res.status_code != 200:
            bot.edit_message_text(f"❌ ᴀᴘɪ ꜰᴀɪʟᴇᴅ ({res.status_code})", chat_id, processing.message_id, reply_markup=final_markup)
            return

        data = res.json()
        if "basicInfo" not in data:
            bot.edit_message_text(
                "❌ ɪɴᴠᴀʟɪᴅ ᴜɪᴅ ᴏʀ ʀᴇɢɪᴏɴ",
                chat_id,
                processing.message_id,
                reply_markup=final_markup
            )
            return

        basic = data["basicInfo"]
        profile = data.get("profileInfo", {})
        clan = data.get("clanBasicInfo", {})
        captain = data.get("captainBasicInfo", {})
        pet = data.get("petInfo", {})
        social = data.get("socialInfo", {})
        
        s = sanitize_markdown 
        
        # Convert timestamps
        created_date, created_time = convert_time(basic.get("createAt", 0))
        last_login_date, last_login_time = convert_time(basic.get("lastLoginAt", 0))
        leader_join_date, leader_join_time = convert_time(captain.get("createAt", 0))
        leader_last_login_date, leader_last_login_time = convert_time(captain.get("lastLoginAt", 0))

        msg = f"""
━━━━━━━━━━━━━━━━━━━━
        ᴀᴄᴄᴏᴜɴᴛ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ
━━━━━━━━━━━━━━━━━━━━

👤 **ʙᴀꜱɪᴄ ɪɴꜰᴏ**
├─ ɴᴀᴍᴇ: {s(basic.get("nickname"))}
├─ ᴜɪᴅ: {s(basic.get("accountId"))}
├─ ʟᴇᴠᴇʟ: {s(basic.get("level"))}
├─ ᴇxᴘ: {s(basic.get("exp"))}
├─ ʀᴇɢɪᴏɴ: {s(basic.get("region"))}
├─ ʟɪᴋᴇꜱ: {s(basic.get("liked"))}
├─ ʜᴏɴᴏʀ ꜱᴄᴏʀᴇ: {s(data.get("creditScoreInfo",{}).get("creditScore"))}
├─ ᴛɪᴛʟᴇ: {s(basic.get("title"))}
└─ ꜱɪɢɴᴀᴛᴜʀᴇ: {s(social.get("signature"))}

🏆 **ᴀᴄᴄᴏᴜɴᴛ ꜱᴛᴀᴛɪꜱᴛɪᴄꜱ**
├─ ɢᴀᴍᴇ ᴠᴇʀꜱɪᴏɴ: {s(basic.get("releaseVersion"))}
├─ ʙʀ ʀᴀɴᴋ: {s(basic.get("rank"))}
├─ ʙʀ ᴍᴀx ʀᴀɴᴋ: {s(basic.get("maxRank"))}
├─ ᴄꜱ ʀᴀɴᴋ: {s(basic.get("csRank"))}
├─ ᴄꜱ ᴍᴀx ʀᴀɴᴋ: {s(basic.get("csMaxRank"))}
├─ ᴄʀᴇᴀᴛᴇᴅ ᴅᴀᴛᴇ: {created_date}
├─ ᴛɪᴍᴇ: {created_time}
├─ ʟᴀꜱᴛ ʟᴏɢɪɴ: {last_login_date}
└─ ᴛɪᴍᴇ: {last_login_time}

👕 **ᴄʜᴀʀᴀᴄᴛᴇʀ ᴀᴘᴘᴇᴀʀᴀɴᴄᴇ**
├─ ᴀᴠᴀᴛᴀʀ ɪᴅ: {s(profile.get("avatarId"))}
├─ ʙᴀɴɴᴇʀ ɪᴅ: {s(basic.get("bannerId"))}
└─ ʙᴀᴅɢᴇ ɪᴅ: {s(basic.get("badgeId"))}

🐾 **ᴘᴇᴛ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ**
├─ ᴘᴇᴛ ʟᴇᴠᴇʟ: {s(pet.get("level"))}
├─ ᴘᴇᴛ ᴇxᴘ: {s(pet.get("exp"))}
└─ ᴘᴇᴛ ɪᴅ: {s(pet.get("id"))}

🏰 **ɢᴜɪʟᴅ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ**
├─ ɢᴜɪʟᴅ ɴᴀᴍᴇ: {s(clan.get("clanName", "None"))}
├─ ɢᴜɪʟᴅ ɪᴅ: {s(clan.get("clanId"))}
├─ ɢᴜɪʟᴅ ʟᴇᴠᴇʟ: {s(clan.get("clanLevel"))}
└─ ᴍᴇᴍʙᴇʀꜱ: {s(clan.get("memberNum"))}

🧑‍✈️ **ʟᴇᴀᴅᴇʀ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ**
├─ ɴᴀᴍᴇ: {s(captain.get("nickname"))}
├─ ᴜɪᴅ: {s(captain.get("accountId"))}
├─ ʟᴇᴠᴇʟ: {s(captain.get("level"))}
├─ ᴇxᴘ: {s(captain.get("exp"))}
├─ ᴄʀᴇᴀᴛᴇᴅ ᴅᴀᴛᴇ: {leader_join_date}
├─ ᴛɪᴍᴇ: {leader_join_time}
├─ ʟᴀꜱᴛ ʟᴏɢɪɴ: {leader_last_login_date}
├─ ᴛɪᴍᴇ: {leader_last_login_time}
├─ ᴛɪᴛʟᴇ: {s(captain.get("title"))}
├─ ʙʀ ᴘᴏɪɴᴛꜱ: {s(captain.get("rankingPoints"))}
└─ ᴄꜱ ᴘᴏɪɴᴛꜱ: {s(captain.get("csRankingPoints"))}

🗺️ **ᴘᴜʙʟɪᴄ ᴄʀᴀꜰᴛʟᴀɴᴅ ᴍᴀᴘꜱ**: Not Found

━━━━━━━━━━━━━━━━━━━━
👨‍💻 ᴅᴇᴠᴇʟᴏᴘᴇʀ: **{DEVELOPER_NAME}**
❤️ ᴄʀᴇᴅɪᴛ: {CREDIT}
━━━━━━━━━━━━━━━━━━━━
"""
        bot.edit_message_text(msg, chat_id, processing.message_id, reply_markup=final_markup)

    except Exception as e:
        bot.edit_message_text(
            f"❌ ᴜɴᴇxᴘᴇᴄᴛᴇᴅ ᴇʀʀᴏʀ: `{sanitize_markdown(str(e))}`",
            chat_id,
            processing.message_id,
            reply_markup=final_markup
        )


def run_worker(uid, pw, cmd_queue):
    """Wrapper to run the async loop in a separate process"""
    try:
        asyncio.run(StarTinG(uid, pw, cmd_queue))
    except KeyboardInterrupt:
        pass


# ------------------------------------------#
# 🛠️ Helper Functions & Logic for New Buttons
# ------------------------------------------#

def create_admin_panel():
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.row(
        types.InlineKeyboardButton('➕ Add Admin', callback_data='add_admin'),
        types.InlineKeyboardButton('➖ Remove Admin', callback_data='remove_admin')
    )
    markup.row(types.InlineKeyboardButton('📋 List Admins', callback_data='list_admins'))
    return markup

def _logic_bot_speed(message):
    chat_id = message.chat.id
    start_time_ping = time.time()
    wait_msg = bot.reply_to(message, "🏃 Testing speed...")
    try:
        bot.send_chat_action(chat_id, 'typing')
        response_time = round((time.time() - start_time_ping) * 1000, 2)
        status = "🔓 Unlocked" if not bot_locked else "🔒 Locked"
        # Simple level check
        user_id = message.from_user.id
        if str(user_id) in OWNER_UIDS: user_level = "👑 Owner"
        elif is_admin(user_id): user_level = "🛡️ Admin"
        else: user_level = "🆓 Free User"
        
        speed_msg = (f"⚡ Bot Speed & Status:\n\n⏱️ API Response Time: {response_time} ms\n"
                     f"🚦 Bot Status: {status}\n"
                     f"👤 Your Level: {user_level}")
        bot.edit_message_text(speed_msg, chat_id, wait_msg.message_id)
    except Exception as e:
        bot.edit_message_text("❌ Error during speed test.", chat_id, wait_msg.message_id)

def _logic_statistics(message):
    user_id = message.from_user.id
    
    # 🕵️ DEBUG: Force-save the current user to ensure DB is working
    try:
        add_active_user(user_id)
    except Exception as e:
        print(f"❌ DEBUG: Could not save user in stats: {e}")

    # 🛡️ Force DB Count for Accuracy
    try:
        conn = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM active_users')
        total_active_targets = c.fetchone()[0]
        conn.close()
    except Exception as e:
        print(f"❌ DEBUG: Stats DB Read Error: {e}")
        total_active_targets = len(active_users) # Fallback
    
    # Count connected bots
    connected_bots = len(bot_queues)
    
    # Assignments count
    total_assignments = 0
    my_bots_count = 0
    try:
        data = load_tembsave()
        for uid, record in data.items():
            count = 0
            if isinstance(record, list): count = len(record)
            elif isinstance(record, dict): count = len(record.get('bots', []))
            
            total_assignments += count
            if str(user_id) == str(uid):
                my_bots_count = count
    except: pass

    stats_msg_base = (f"📊 Bot Statistics:\n\n"
                      f"👥 Total Users: {total_active_targets}\n"
                      f"🟢 Connected Bots: {connected_bots}\n"
                      f"🤖 Running Bots: {total_assignments}\n")

    # Add Admin Status + User Bots
    ext_info = f"🤖 Your Running Bots: {my_bots_count}"
    
    if is_admin(user_id) or str(user_id) in OWNER_UIDS:
        stats_msg_admin = (f"🔒 Bot Status: {'🔴 Locked' if bot_locked else '🟢 Unlocked'}\n"
                           f"{ext_info}")
        stats_msg = stats_msg_base + stats_msg_admin
    else:
        stats_msg = stats_msg_base + ext_info

    bot.reply_to(message, stats_msg)

def _logic_broadcast_init(message):
    if not (is_admin(message.from_user.id) or str(message.from_user.id) in OWNER_UIDS):
        bot.reply_to(message, "⚠️ Admin permissions required.")
        return
    msg = bot.reply_to(message, "📢 Send message to broadcast to all tracked active users.\n/cancel to abort.")
    bot.register_next_step_handler(msg, process_broadcast_message)

# Global to store pending broadcasts {admin_id: text}
pending_broadcasts = {}

def process_broadcast_message(message):
    user_id = message.from_user.id
    if not (is_admin(user_id) or str(user_id) in OWNER_UIDS): return
    if message.text and message.text.lower() == '/cancel': bot.reply_to(message, "Broadcast cancelled."); return

    broadcast_content = message.text
    if not broadcast_content:
         bot.reply_to(message, "⚠️ Text only supported for now. Send text or /cancel.")
         return

    target_count = len(active_users)
    markup = types.InlineKeyboardMarkup()
    markup.row(types.InlineKeyboardButton("✅ Confirm", callback_data=f"confirm_broadcast_{message.message_id}"),
               types.InlineKeyboardButton("❌ Cancel", callback_data="cancel_broadcast"))

    # Save content to memory instead of parsing UI
    pending_broadcasts[user_id] = broadcast_content

    preview_text = broadcast_content[:1000].strip()
    bot.reply_to(message, f"⚠️ Confirm Broadcast:\n\n{preview_text}\n\n" 
                          f"To **{target_count}** users. Sure?", reply_markup=markup, parse_mode='Markdown')

def _logic_toggle_lock_bot(message):
    if not (is_admin(message.from_user.id) or str(message.from_user.id) in OWNER_UIDS):
        bot.reply_to(message, "⚠️ Admin permissions required.")
        return
    global bot_locked
    bot_locked = not bot_locked
    status = "locked" if bot_locked else "unlocked"
    bot.reply_to(message, f"🔒 Bot has been {status}.")

def _logic_admin_panel(message):
    if not (is_admin(message.from_user.id) or str(message.from_user.id) in OWNER_UIDS):
        bot.reply_to(message, "⚠️ Admin permissions required.")
        return
    bot.reply_to(message, "👑 Admin Panel\nManage admins.", reply_markup=create_admin_panel())

# --- Callbacks ---
@bot.callback_query_handler(func=lambda call: call.data in ['add_admin', 'remove_admin', 'list_admins'])
def handle_admin_panel_callbacks(call):
    uid = call.from_user.id
    save_tg_user(uid)
    if not (is_admin(uid) or str(uid) in OWNER_UIDS): return
    
    if call.data == 'list_admins':
        try:
            admins = []
            if os.path.exists(ADMIN_FILE):
                with open(ADMIN_FILE, 'r') as f: admins = json.load(f)
            
            list_str = "\n".join([f"`{a}`" for a in admins])
            bot.edit_message_text(f"👑 Admins:\n{list_str}\n\n(Owners: {OWNER_UIDS})", 
                                  call.message.chat.id, call.message.message_id, reply_markup=create_admin_panel(), parse_mode='Markdown')
        except: pass
        
    elif call.data == 'add_admin':
        if str(uid) not in OWNER_UIDS:
            bot.answer_callback_query(call.id, "⚠️ Owner only.", show_alert=True)
            return
        msg = bot.send_message(call.message.chat.id, "👑 Enter User ID to add:")
        bot.register_next_step_handler(msg, process_add_admin)
        
    elif call.data == 'remove_admin':
        if str(uid) not in OWNER_UIDS:
            bot.answer_callback_query(call.id, "⚠️ Owner only.", show_alert=True)
            return
        msg = bot.send_message(call.message.chat.id, "👑 Enter User ID to remove:")
        bot.register_next_step_handler(msg, process_remove_admin)

def process_add_admin(message):
    try:
        new_uid = message.text.strip()
        admins = []
        if os.path.exists(ADMIN_FILE):
            with open(ADMIN_FILE, 'r') as f: admins = json.load(f)
        if new_uid not in admins:
            admins.append(new_uid)
            with open(ADMIN_FILE, 'w') as f: json.dump(admins, f)
            bot.reply_to(message, f"✅ Added {new_uid} as Admin.")
        else:
             bot.reply_to(message, "⚠️ Already admin.")
    except: pass

def process_remove_admin(message):
    try:
        target = message.text.strip()
        admins = []
        if os.path.exists(ADMIN_FILE):
             with open(ADMIN_FILE, 'r') as f: admins = json.load(f)
        if target in admins:
            admins.remove(target)
            with open(ADMIN_FILE, 'w') as f: json.dump(admins, f)
            bot.reply_to(message, f"✅ Removed {target}.")
        else:
            bot.reply_to(message, "⚠️ Not found.")
    except: pass

@bot.callback_query_handler(func=lambda c: c.data.startswith('confirm_broadcast_') or c.data == 'cancel_broadcast')
def handle_broadcast_cb(call):
    save_tg_user(call.from_user.id)
    if call.data == 'cancel_broadcast':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        return
    
    # Confirm
    try:
        user_id = call.from_user.id
        text_to_send = pending_broadcasts.get(user_id)
        
        if not text_to_send:
            # Fallback to old split method if memory lost (restart)
            try:
                text_to_send = call.message.text.split("Confirm Broadcast:\n\n")[1].split("\n\nTo **")[0]
            except:
                bot.answer_callback_query(call.id, "❌ Session expired. Please recreate broadcast.")
                return

        count = 0
        blocked = 0
        for target in list(active_users):
            try:
                bot.send_message(target, text_to_send)
                count += 1
            except Exception as e:
                # print(f"Failed to send to {target}: {e}") # Optional debug
                blocked += 1
        
        bot.edit_message_text(f"✅ Broadcast sent to {count} users.\n❌ Failed/Blocked: {blocked}", call.message.chat.id, call.message.message_id)
        
        # Cleanup
        if user_id in pending_broadcasts: del pending_broadcasts[user_id]
        
    except Exception as e:
        bot.edit_message_text(f"❌ Error broadcasting: {e}", call.message.chat.id, call.message.message_id)
        print(f"Broadcast Error: {e}")

# --- Button Logic Dispatcher ---

def _logic_owner_contact(message):
    owner_commands(message)

BUTTON_TEXT_TO_LOGIC = {
    "📊 Statistics": _logic_statistics,
    "📢 Broadcast": _logic_broadcast_init,
    "🔒 Lock Bot": _logic_toggle_lock_bot,
    "👑 Admin Panel": _logic_admin_panel,
    "⚡ Bot Speed": _logic_bot_speed,
    "📞 Contact Owner": _logic_owner_contact,
    "🛠 Full Menu": lambda m: game_menu_command(m),
    "👫 Group Menu": lambda m: group_menu_command(m),
    "⚠️ Attack Menu": lambda m: attack_menu_command(m),
    "📈 Levelup Menu": lambda m: levelup_menu_command(m),
    "⚜️ Admin Menu": lambda m: admin_menu_command(m),
    "🔄 Restart": lambda m: restart_command(m)
}

@bot.message_handler(func=lambda message: message.text in BUTTON_TEXT_TO_LOGIC)
def handle_button_text(message):
    log_cmd(message)
    # Check lock
    if is_bot_locked_for_user(message.from_user.id):
        bot.reply_to(message, "🔒 Bot has been locked by admin.")
        return

    logic_func = BUTTON_TEXT_TO_LOGIC.get(message.text)
    if logic_func: logic_func(message)



if __name__ == '__main__':
    # Clear tembsave.json on restart as requested
    if os.path.exists(TEMBSAVE_FILE):
        with open(TEMBSAVE_FILE, 'w') as f:
            json.dump({}, f)
        print("🧹 Cleared tembsave.json data.")

    # Start Session Cleanup Monitor
    threading.Thread(target=cleanup_monitor, daemon=True).start()
    print("♻️ Session Cleanup Monitor Started.")

    # ------------------------------------------------- START BOT THREAD ----------------------------------------------
    def run_telebot():
        try:
            print("🤖 ᴍᴇʀɢᴇᴅ ʙᴏᴛ ꜱᴛᴀʀᴛɪɴɢ...")
            bot.infinity_polling()
        except Exception as e:
            print(f"❌ Telegram Bot Error: {e}")

    # Start Telegram Bot in a separate daemon thread
    t_bot_thread = threading.Thread(target=run_telebot, daemon=True)
    t_bot_thread.start()
    # -----------------------------------------------------------------------------------------------------------------

    # Load accounts
    if os.path.exists("accounts.json"):
        with open("accounts.json", "r") as f:
            accounts = json.load(f)
            # Capture main accounts specifically for /join
            MAIN_ACCOUNT_UIDS = list(accounts.keys())  
            print(f"✅ Loaded {len(accounts)} main accounts")
    else:
        accounts = {}
        print("⚠️ accounts.json not found!")

    # Load spam accounts
    if os.path.exists(SPAM_FILE):
        try:
            with open(SPAM_FILE, "r") as f:
                spam_accs = json.load(f)
                SPAM_ACCOUNT_UIDS = list(spam_accs.keys())
                accounts.update(spam_accs)
                print(f"✅ Loaded {len(spam_accs)} spam accounts from spam.json")
        except Exception as e:
            print(f"❌ Error loading spam.json: {e}")


    # Load levelup accounts to run automatically
    if os.path.exists(LEVELUP_FILE):
        try:
            with open(LEVELUP_FILE, "r") as f:
                levelup_accs = json.load(f)
                # Merge levelup accounts into main accounts dict
                # Note: This means duplicates will be overwritten by levelup.json version if any
                accounts.update(levelup_accs)
                print(f"✅ Loaded {len(levelup_accs)} accounts from levelup.json")
        except Exception as e:
            print(f"❌ Error loading levelup.json: {e}")
            
    if not accounts:
        print("❌ No accounts found in accounts.json or levelup.json!")
        sys.exit(1)

    # Create global command queue for IPC
    # global cmd_queue -- REPLACED BY bot_queues list
    # cmd_queue = multiprocessing.Queue()

    while True:
        processes = []
        # Clear old queues on restart to prevent stale commands? 
        # Or just append new ones. Best to clear list if logic allows, but run_telebot is running in thread.
        # Ideally, we should clear it if we are restarting ALL processes.
        bot_queues.clear() 

        print(f"🚀 Starting {len(accounts)} accounts...")

        for uid, token_or_pw in accounts.items():
            # Create a queue for this specific process
            q = multiprocessing.Queue()
            bot_queues[uid] = q  # Changed to Dict Assignment

            # Assuming value is password/token based on original code usage
            p = Process(target=run_worker, args=(uid, token_or_pw, q))
            p.start()
            processes.append(p)
            print(f"✅ Started process for UID: {uid}")


        try:
            for p in processes:
                p.join()
        except KeyboardInterrupt:
            print("\n🛑 Stopping all accounts...")
            for p in processes:
                p.terminate()
            break
        
        # Check if we should restart
        if os.path.exists("restart_flag"):
            print("\n🔄 Restarting all bots...")
            try:
                os.remove("restart_flag")
            except:
                pass
            time.sleep(2) # Give a moment for cleanup
            continue # Loop again to restart processes
        else:
            # Normal exit or crash without restart flag
            print("👋 All processes finished.")
            break
