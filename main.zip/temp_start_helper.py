async def run_one_time_start(team_code, uid, chat_id, chat_type, key, iv):
    """
    Helper for /start command: Joins, spams start for 18s, then leaves.
    """
    try:
        # Join team
        if whisper_writer and online_writer:
             join_pkt = await GenJoinSquadsPacket(team_code, key, iv)
             await SEndPacKeT(whisper_writer, online_writer, 'OnLine', join_pkt)
             await asyncio.sleep(2)
        
        # Spam Start Packet
        start_pkt = await GenLevelStartPacket(key, iv)
        end_time = time.time() + 18 # START_SPAM_DURATION
        
        while time.time() < end_time:
             if whisper_writer and online_writer:
                  # Use 'OnLine' type for game packets usually, but let's check level_loop_task
                  # level_loop_task uses socket_client.send in the original app.py
                  # usage here: await SEndPacKeT(whisper_writer, online_writer, 'OnLine', start_pkt)
                  await SEndPacKeT(whisper_writer, online_writer, 'OnLine', start_pkt)
             await asyncio.sleep(0.2) # START_SPAM_DELAY
        
        msg = f"[B][C][00FF00]Force start complete for team {team_code}.\nLeaving team now.\n{PROMO_TEXT}"
        await safe_send_message(chat_type, msg, uid, chat_id, key, iv)
        
        # Leave team
        if whisper_writer and online_writer:
             leave_pkt = await GenLevelLeavePacket(key, iv)
             await SEndPacKeT(whisper_writer, online_writer, 'OnLine', leave_pkt)

    except Exception as e:
        print(f"Error in run_one_time_start: {e}")
