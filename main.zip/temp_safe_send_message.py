async def safe_send_message(chat_type, msg, uid, chat_id, key, iv):
    """
    Safely send a message to the chat using xSEndMsg from xC4.py.
    """
    try:
        # Ensure writers are available
        if not whisper_writer or not online_writer:
            print("Writers not available for safe_send_message")
            return

        # Use xSEndMsg to generate the packet
        # Tp=1 (Type 1), Tp2=2 (Type 2) - Standard for Team/Group chat
        # Target ID is chat_id (e.g., Team ID) or uid if private. 
        # Usually chat_id covers both if correctly populated.
        target = int(chat_id) if chat_id else int(uid)
        
        # Generate packet
        pkt = await xSEndMsg(msg, 1, 2, target, key, iv)
        
        # Send packet
        await SEndPacKeT(whisper_writer, online_writer, 'OnLine', pkt)
        print(f"✅ Sent message to {target}: {msg[:20]}...")
        
    except Exception as e:
        print(f"❌ Error in safe_send_message: {e}")
