from flask import Flask, request, jsonify
import requests
from Crypto.Cipher import AES

app = Flask(__name__)

# Region URLs mapping
REGION_URLS = {
    "IND": "https://client.ind.freefiremobile.com/GetClanMainPageInfo",
    "ID": "https://clientbp.ggblueshark.com/GetClanMainPageInfo",
    "BR": "https://client.us.freefiremobile.com/GetClanMainPageInfo",
    "ME": "https://clientbp.common.ggbluefox.com/GetClanMainPageInfo",
    "VN": "https://clientbp.ggblueshark.com/GetClanMainPageInfo",
    "TH": "https://clientbp.common.ggbluefox.com/GetClanMainPageInfo",
    "CIS": "https://clientbp.common.ggbluefox.com/GetClanMainPageInfo",
    "BD": "https://clientbp.ggblueshark.com/GetClanMainPageInfo",
    "PK": "https://clientbp.ggblueshark.com/GetClanMainPageInfo",
    "SG": "https://clientbp.ggblueshark.com/GetClanMainPageInfo",
    "NA": "https://client.us.freefiremobile.com/GetClanMainPageInfo",
    "SAC": "https://client.us.freefiremobile.com/GetClanMainPageInfo",
    "EU": "https://clientbp.ggblueshark.com/GetClanMainPageInfo",
    "TW": "https://clientbp.ggblueshark.com/GetClanMainPageInfo"
}

def encode_varint(n: int) -> bytes:
    out = bytearray()
    while True:
        to_write = n & 0x7F
        n >>= 7
        if n:
            out.append(to_write | 0x80)
        else:
            out.append(to_write)
            break
    return bytes(out)

FIELD1_TAG = 0x08
FIELD2_TAG = 0x10

def build_packet(guildid: int, flag: int = 1, repeat_value: int = 8, repeat_count: int = 4):
    data = bytearray()

    data.append(FIELD1_TAG)
    data.extend(encode_varint(guildid))

    data.append(FIELD2_TAG)
    data.extend(encode_varint(flag))

    for _ in range(repeat_count):
        data.append(FIELD1_TAG)
        data.extend(encode_varint(repeat_value))

    return bytes(data)

def encrypt_packet(packet: bytes):
    key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
    iv  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

    cipher = AES.new(key, AES.MODE_CBC, iv)
    return cipher.encrypt(packet)

def decode_varint(data: bytes, index: int):
    result = 0
    shift = 0
    start = index
    while True:
        if index >= len(data):
            raise ValueError("Truncated varint")
        b = data[index]
        index += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, index, start

def zigzag_decode(n: int) -> int:
    return (n >> 1) ^ -(n & 1)

def parse_message(buf: bytes, stop_at: int = None):
    if stop_at is None:
        stop_at = len(buf)

    i = 0
    fields = []

    while i < stop_at:
        field_start = i
        tag, i, _ = decode_varint(buf, i)
        field_number = tag >> 3
        wire_type = tag & 0x07

        entry = {
            "start": field_start,
            "end": None,
            "field": field_number,
            "wire": wire_type,
            "type": None,
            "uint": None,
            "int32": None,
            "sint": None,
            "raw": None,
            "text": None,
            "sub": None,
        }

        if wire_type == 0:
            v, i, _ = decode_varint(buf, i)
            entry["type"] = "varint"
            entry["uint"] = v
            entry["int32"] = v - 0x100000000 if v & 0x80000000 else v
            entry["sint"] = zigzag_decode(v)
            entry["end"] = i

        elif wire_type == 1:
            if i + 8 > stop_at:
                raise ValueError("Truncated 64-bit field")
            v_bytes = buf[i:i+8]
            v = int.from_bytes(v_bytes, "little")
            entry["type"] = "fixed64"
            entry["raw"] = v_bytes
            entry["uint"] = v
            entry["end"] = i + 8
            i += 8

        elif wire_type == 2:
            length, i, _ = decode_varint(buf, i)
            if i + length > stop_at:
                raise ValueError("Truncated length-delimited field")
            val_start = i
            val_end = i + length
            chunk = buf[val_start:val_end]
            i = val_end

            entry["type"] = "length-delimited"
            entry["raw"] = chunk
            entry["end"] = val_end

            sub_fields = None
            try:
                sub_fields, consumed = parse_message(chunk, stop_at=len(chunk))
                if consumed == len(chunk) and sub_fields:
                    entry["sub"] = sub_fields
                else:
                    sub_fields = None
            except Exception:
                sub_fields = None

            if sub_fields is None:
                try:
                    text = chunk.decode("utf-8")
                    entry["text"] = text
                except UnicodeDecodeError:
                    entry["text"] = None

        elif wire_type == 5:
            if i + 4 > stop_at:
                raise ValueError("Truncated 32-bit field")
            v_bytes = buf[i:i+4]
            v = int.from_bytes(v_bytes, "little")
            entry["type"] = "fixed32"
            entry["raw"] = v_bytes
            entry["uint"] = v
            entry["end"] = i + 4
            i += 4

        else:
            raise ValueError(f"Unknown wire type {wire_type} at offset {field_start}")

        fields.append(entry)

    return fields, i

def get_first_uint(fields, field_no):
    for f in fields:
        if f["field"] == field_no and f["type"] == "varint":
            return f["uint"]
    return None

def get_first_text(fields, field_no):
    for f in fields:
        if f["field"] == field_no and f["type"] == "length-delimited" and f["text"] is not None:
            return f["text"]
    return None

def get_first_sub(fields, field_no):
    for f in fields:
        if f["field"] == field_no and f["type"] == "length-delimited" and f["sub"] is not None:
            return f["sub"]
    return None

def extract_guild_and_members(root_fields):
    result = {"guild": {}, "members": []}

    guild_entry = None
    for f in root_fields:
        if f["field"] == 1 and f["type"] == "length-delimited" and f["sub"] is not None:
            guild_entry = f
            break

    if guild_entry is not None:
        gsub = guild_entry["sub"]
        guild = {
            "id":            get_first_uint(gsub, 1),
            "name":          get_first_text(gsub, 2),
            "tagline":       get_first_text(gsub, 12),
            "region":        get_first_text(gsub, 13),
            "glory":         get_first_uint(gsub, 20),
            "level":         get_first_uint(gsub, 5),
            "member_count":  get_first_uint(gsub, 7),
        }
        result["guild"] = guild

    for f in root_fields:
        if f["field"] != 2 or f["type"] != "length-delimited" or f["sub"] is None:
            continue

        wrapper_sub = f["sub"]
        member_sub = get_first_sub(wrapper_sub, 1)
        if member_sub is None:
            continue

        member = {
            "uid":   get_first_uint(member_sub, 1),
            "name":  get_first_text(member_sub, 3),
            "region": get_first_text(member_sub, 5),
            "glory":   get_first_uint(wrapper_sub, 10),
            "level":   get_first_uint(member_sub, 6),
            "tagline_id":  get_first_uint(member_sub, 12),
            "tagjson_id":  get_first_uint(member_sub, 14),
            "br_rank": get_first_uint(member_sub, 15),
            "cs_rank": get_first_uint(member_sub, 31),
        }

        result["members"].append(member)

    return result

@app.route('/guild-data', methods=['GET'])
def get_guild_data():
    # Get query parameters
    region = request.args.get('region', 'IND').upper()
    guild_id = request.args.get('guild_id')
    jwt_token = request.args.get('jwt')
    
    # Validate required parameters
    if not guild_id:
        return jsonify({"error": "guild_id is required"}), 400
    
    if not jwt_token:
        return jsonify({"error": "jwt token is required"}), 400
    
    # Validate region
    if region not in REGION_URLS:
        return jsonify({"error": f"Invalid region. Available regions: {', '.join(REGION_URLS.keys())}"}), 400
    
    try:
        guild_id = int(guild_id)
    except ValueError:
        return jsonify({"error": "guild_id must be a valid integer"}), 400
    
    try:
        # Build and encrypt packet
        packet = build_packet(guild_id)
        encrypted = encrypt_packet(packet)
        
        # Prepare headers
        headers = {
            "Accept": "*/*",
            "Accept-Encoding": "deflate, gzip",
            "Authorization": f"Bearer {jwt_token}",
            "Content-Type": "application/x-www-form-urlencoded",
            "Content-Length": str(len(encrypted)),
            "Host": REGION_URLS[region].split('/')[2],
            "ReleaseVersion": "OB52",
            "User-Agent": "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
            "X-GA": "v1 1",
            "X-Unity-Version": "2022.3.47f1",
        }
        
        # Make request
        response = requests.post(REGION_URLS[region], data=encrypted, headers=headers)
        
        # Parse response
        fields, consumed = parse_message(response.content)
        data = extract_guild_and_members(fields)
        
        # Prepare response in the same format as original code
        result = {
            "status_code": response.status_code,
            "guild_info": data.get("guild", {}),
            "total_members": len(data.get("members", [])),
            "members": data.get("members", [])
        }
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/regions', methods=['GET'])
def get_regions():
    """Endpoint to get available regions"""
    return jsonify({"available_regions": list(REGION_URLS.keys())})

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "message": "API is running"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=2011)